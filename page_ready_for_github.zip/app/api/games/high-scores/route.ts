
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'
import { NextRequest } from 'next/server'

export const dynamic = 'force-dynamic'

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user) {
      return new Response(JSON.stringify({ error: 'No autorizado' }), {
        status: 401,
      })
    }

    const { searchParams } = new URL(request.url)
    const gameType = searchParams.get('gameType')

    if (!gameType) {
      return new Response(JSON.stringify({ error: 'Tipo de juego requerido' }), {
        status: 400,
      })
    }

    // Validate game type
    const validGameTypes = ['snake', 'tetris', 'pong', 'memory', '2048']
    if (!validGameTypes.includes(gameType)) {
      return new Response(JSON.stringify({ error: 'Tipo de juego inválido' }), {
        status: 400,
      })
    }

    // Get top scores for this game type
    const topScores = await prisma.gameScore.findMany({
      where: {
        gameType: gameType
      },
      orderBy: {
        score: 'desc'
      },
      take: 50, // Top 50 scores
      include: {
        user: {
          select: {
            name: true
          }
        }
      }
    })

    // Get user's personal best for this game
    const personalBest = await prisma.gameScore.findFirst({
      where: {
        userId: session.user.id,
        gameType: gameType
      },
      orderBy: {
        score: 'desc'
      }
    })

    // Format the scores
    const formattedScores = topScores.map(score => ({
      id: score.id,
      score: score.score,
      level: score.level,
      duration: score.duration,
      userName: score.user.name || 'Usuario Anónimo',
      playedAt: score.playedAt.toISOString()
    }))

    return new Response(JSON.stringify({
      scores: formattedScores,
      personalBest: personalBest?.score || 0,
      total: formattedScores.length
    }), {
      status: 200,
      headers: {
        'Content-Type': 'application/json',
      },
    })

  } catch (error) {
    console.error('High scores API error:', error)
    return new Response(JSON.stringify({ 
      error: 'Error interno del servidor' 
    }), {
      status: 500,
    })
  }
}
