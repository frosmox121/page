
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'

export const dynamic = 'force-dynamic'

export async function GET() {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user) {
      return new Response(JSON.stringify({ error: 'No autorizado' }), {
        status: 401,
      })
    }

    // Get current user data
    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
      select: {
        totalPoints: true,
        level: true,
        practicePoints: true
      }
    })

    if (!user) {
      return new Response(JSON.stringify({ error: 'Usuario no encontrado' }), {
        status: 404,
      })
    }

    // Count solved exercises
    const solvedExercises = await prisma.submission.count({
      where: {
        userId: session.user.id,
        status: 'passed'
      }
    })

    // Calculate user ranking
    const usersWithMorePoints = await prisma.user.count({
      where: {
        totalPoints: {
          gt: user.totalPoints
        }
      }
    })
    const rank = usersWithMorePoints + 1

    // Calculate streak (simplified - consecutive days with submissions)
    const recentSubmissions = await prisma.submission.findMany({
      where: {
        userId: session.user.id,
        status: 'passed'
      },
      orderBy: {
        submittedAt: 'desc'
      },
      take: 30, // Last 30 submissions
      select: {
        submittedAt: true
      }
    })

    // Calculate streak
    let streak = 0
    if (recentSubmissions.length > 0) {
      const today = new Date()
      const dayInMs = 24 * 60 * 60 * 1000
      
      // Check if there's a submission today
      const latestSubmission = recentSubmissions[0].submittedAt
      const daysSinceLatest = Math.floor((today.getTime() - latestSubmission.getTime()) / dayInMs)
      
      if (daysSinceLatest <= 1) {
        streak = 1 // At least 1 day streak
        
        // Count consecutive days
        const submissionsByDay = new Set(
          recentSubmissions.map(sub => 
            new Date(sub.submittedAt).toDateString()
          )
        )
        
        for (let i = 1; i < 30; i++) {
          const checkDate = new Date(today.getTime() - (i * dayInMs))
          if (submissionsByDay.has(checkDate.toDateString())) {
            streak = i + 1
          } else {
            break
          }
        }
      }
    }

    const stats = {
      totalPoints: user.totalPoints,
      level: user.level,
      solvedExercises,
      rank,
      streak
    }

    return new Response(JSON.stringify({
      stats
    }), {
      status: 200,
      headers: {
        'Content-Type': 'application/json',
      },
    })

  } catch (error) {
    console.error('Stats API error:', error)
    return new Response(JSON.stringify({ 
      error: 'Error interno del servidor' 
    }), {
      status: 500,
    })
  }
}
