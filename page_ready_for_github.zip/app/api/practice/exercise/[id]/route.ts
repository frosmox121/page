
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'
import { NextRequest } from 'next/server'

export const dynamic = 'force-dynamic'

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user) {
      return new Response(JSON.stringify({ error: 'No autorizado' }), {
        status: 401,
      })
    }

    const exerciseId = params.id

    // Get exercise details
    const exercise = await prisma.exercise.findUnique({
      where: {
        id: exerciseId,
        isActive: true
      }
    })

    if (!exercise) {
      return new Response(JSON.stringify({ error: 'Ejercicio no encontrado' }), {
        status: 404,
      })
    }

    // Get user's previous submissions for this exercise
    const userSubmissions = await prisma.submission.findMany({
      where: {
        userId: session.user.id,
        exerciseId: exerciseId
      },
      orderBy: {
        submittedAt: 'desc'
      },
      take: 10 // Last 10 attempts
    })

    // Get best submission
    const bestSubmission = await prisma.submission.findFirst({
      where: {
        userId: session.user.id,
        exerciseId: exerciseId,
        status: 'passed'
      },
      orderBy: {
        score: 'desc'
      }
    })

    return new Response(JSON.stringify({
      exercise: {
        id: exercise.id,
        title: exercise.title,
        description: exercise.description,
        language: exercise.language,
        difficulty: exercise.difficulty,
        points: exercise.points,
        category: exercise.category,
        testCases: exercise.testCases,
        starterCode: exercise.starterCode
      },
      userSubmissions: userSubmissions.map(sub => ({
        id: sub.id,
        status: sub.status,
        score: sub.score,
        submittedAt: sub.submittedAt,
        executionTime: sub.executionTime
      })),
      bestScore: bestSubmission?.score || 0,
      isCompleted: !!bestSubmission
    }), {
      status: 200,
      headers: {
        'Content-Type': 'application/json',
      },
    })

  } catch (error) {
    console.error('Exercise detail API error:', error)
    return new Response(JSON.stringify({ 
      error: 'Error interno del servidor' 
    }), {
      status: 500,
    })
  }
}
