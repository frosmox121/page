
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'

export const dynamic = 'force-dynamic'

export async function GET() {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user) {
      return new Response(JSON.stringify({ error: 'Not authenticated' }), {
        status: 401,
      })
    }

    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
    })

    if (!user) {
      return new Response(JSON.stringify({ error: 'User not found' }), {
        status: 404,
      })
    }

    // Calculate user ranking
    const usersWithMorePoints = await prisma.user.count({
      where: {
        totalPoints: {
          gt: user.totalPoints
        }
      }
    })
    const rank = usersWithMorePoints + 1

    return new Response(JSON.stringify({
      level: user.level,
      totalPoints: user.totalPoints,
      practicePoints: user.practicePoints,
      country: user.country || 'Argentina',
      rank: rank
    }), {
      status: 200,
      headers: {
        'Content-Type': 'application/json',
      },
    })

  } catch (error) {
    console.error('User stats API error:', error)
    return new Response(JSON.stringify({ 
      error: 'Internal server error' 
    }), {
      status: 500,
    })
  }
}
