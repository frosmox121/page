
import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'

export const dynamic = 'force-dynamic'

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'No autorizado' },
        { status: 401 }
      )
    }

    const { message, userId } = await request.json()

    if (!message || typeof message !== 'string') {
      return NextResponse.json(
        { error: 'Mensaje requerido' },
        { status: 400 }
      )
    }

    // Create system message for DevTools context
    const systemMessage = `Eres un asistente especializado en programación y desarrollo de software para la plataforma DevTools. 

DevTools es una plataforma educativa argentina que ofrece:
- Herramientas de desarrollo (ejecutor de código Python/C#/C++, analizador IP, utilidades)
- Sistema de práctica con ejercicios de programación y gamificación
- Cursos gratuitos de programación
- Juegos arcade (Snake, Tetris, Pong)
- Chat con IA (que eres tú)

Tu función es:
- Ayudar con preguntas sobre programación en Python, C#, C++
- Explicar conceptos de programación de forma clara
- Ayudar a resolver ejercicios y problemas de código
- Dar consejos sobre mejores prácticas
- Responder preguntas sobre la plataforma DevTools
- Ser amigable, útil y educativo

Responde siempre en español y mantén un tono profesional pero amigable. Si te preguntan sobre funcionalidades específicas de DevTools, explica lo que está disponible.`

    const messages = [
      { role: 'system', content: systemMessage },
      { role: 'user', content: message }
    ]

    const response = await fetch('https://apps.abacus.ai/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.ABACUSAI_API_KEY}`
      },
      body: JSON.stringify({
        model: 'gpt-4.1-mini',
        messages: messages,
        stream: true,
        max_tokens: 1500,
        temperature: 0.7
      }),
    })

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`)
    }

    const encoder = new TextEncoder()
    const readable = new ReadableStream({
      async start(controller) {
        try {
          const reader = response.body?.getReader()
          if (!reader) throw new Error('No reader available')

          while (true) {
            const { done, value } = await reader.read()
            if (done) break

            const chunk = new TextDecoder().decode(value)
            const lines = chunk.split('\n')

            for (const line of lines) {
              if (line.startsWith('data: ')) {
                const data = line.slice(6)
                if (data === '[DONE]') {
                  controller.enqueue(encoder.encode('data: [DONE]\n\n'))
                  continue
                }
                try {
                  const parsed = JSON.parse(data)
                  const content = parsed.choices?.[0]?.delta?.content || ''
                  if (content) {
                    controller.enqueue(encoder.encode(`data: ${JSON.stringify({content})}\n\n`))
                  }
                } catch (e) {
                  // Skip invalid JSON
                }
              }
            }
          }
          
          controller.close()
        } catch (error) {
          console.error('Streaming error:', error)
          controller.error(error)
        }
      }
    })

    // Save chat message to database (fire and forget)
    const assistantResponse = '' // We'll update this in a real implementation
    prisma.chatMessage.create({
      data: {
        userId: session.user.id,
        message,
        response: assistantResponse
      }
    }).catch(console.error)

    return new Response(readable, {
      headers: {
        'Content-Type': 'text/plain; charset=utf-8',
        'Cache-Control': 'no-cache',
      },
    })
  } catch (error) {
    console.error('Chat API error:', error)
    return NextResponse.json(
      { error: 'Error interno del servidor' },
      { status: 500 }
    )
  }
}
