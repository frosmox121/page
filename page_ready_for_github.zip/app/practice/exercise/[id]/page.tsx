
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { redirect } from 'next/navigation'
import { ExerciseSolver } from '@/components/practice/exercise-solver'

interface ExercisePageProps {
  params: {
    id: string
  }
}

export default async function ExercisePage({ params }: ExercisePageProps) {
  const session = await getServerSession(authOptions)

  if (!session?.user) {
    redirect('/auth/login')
  }

  return <ExerciseSolver exerciseId={params.id} />
}
