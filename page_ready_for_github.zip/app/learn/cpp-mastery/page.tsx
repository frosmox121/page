
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { redirect } from 'next/navigation'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { BookOpen, ArrowLeft } from 'lucide-react'
import Link from 'next/link'

export default async function CppMasteryPage() {
  const session = await getServerSession(authOptions)

  if (!session?.user) {
    redirect('/auth/login')
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-6">
        <Button variant="outline" asChild>
          <Link href="/learn">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Volver a Aprender
          </Link>
        </Button>
      </div>
      
      <Card className="max-w-2xl mx-auto">
        <CardHeader className="text-center">
          <div className="mx-auto h-16 w-16 rounded-lg bg-blue-500 flex items-center justify-center mb-4">
            <BookOpen className="h-8 w-8 text-white" />
          </div>
          <CardTitle className="text-2xl">🔥 C++ Mastery</CardTitle>
          <CardDescription>
            Aprende C++ desde lo básico hasta conceptos avanzados
          </CardDescription>
        </CardHeader>
        <CardContent className="text-center">
          <div className="bg-muted/50 rounded-lg p-8 mb-6">
            <h3 className="text-lg font-semibold mb-2">🚧 Próximamente</h3>
            <p className="text-muted-foreground">
              Este curso está en desarrollo y estará disponible pronto.
            </p>
          </div>
          <Button asChild>
            <Link href="/learn">
              Ver Otros Cursos
            </Link>
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}
