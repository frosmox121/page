
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { LandingPage } from '@/components/landing-page'
import { ClientDashboardWrapper } from '@/components/client-dashboard-wrapper'

export default async function HomePage() {
  const session = await getServerSession(authOptions)

  return session?.user ? <ClientDashboardWrapper /> : <LandingPage />
}
