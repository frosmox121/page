
'use client'

import { useEffect } from 'react'

export function ConsoleErrorSuppressor() {
  useEffect(() => {
    // Store original console methods
    const originalError = console.error
    const originalWarn = console.warn

    // Override console.error to suppress NextAuth errors
    console.error = (...args: any[]) => {
      const message = args.join(' ')
      
      // Suppress specific NextAuth and hydration errors
      if (
        message.includes('[next-auth]') ||
        message.includes('CLIENT_FETCH_ERROR') ||
        message.includes('Failed to fetch') ||
        message.includes('Hydration failed') ||
        message.includes('There was an error while hydrating') ||
        message.includes('Warning: Extra attributes from the server') ||
        message.includes('Warning: Prop')
      ) {
        return // Suppress these errors
      }
      
      // Call original console.error for other errors
      originalError(...args)
    }

    // Override console.warn to suppress NextAuth warnings
    console.warn = (...args: any[]) => {
      const message = args.join(' ')
      
      // Suppress specific NextAuth warnings
      if (
        message.includes('[next-auth]') ||
        message.includes('Warning: Extra attributes from the server') ||
        message.includes('Warning: Prop')
      ) {
        return // Suppress these warnings
      }
      
      // Call original console.warn for other warnings
      originalWarn(...args)
    }

    // Cleanup function to restore original console methods
    return () => {
      console.error = originalError
      console.warn = originalWarn
    }
  }, [])

  return null
}
