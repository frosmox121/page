
'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { 
  BookOpen, 
  Play, 
  CheckCircle, 
  Star,
  Clock,
  TrendingUp,
  Users,
  Award,
  Zap,
  Code2,
  Trophy,
  Target
} from 'lucide-react'
import { motion } from 'framer-motion'
import Link from 'next/link'

interface Course {
  id: string
  title: string
  description: string
  language: string
  difficulty: string
  imageUrl?: string
  orderIndex: number
  isActive: boolean
  modules: number
  progress?: number
  isEnrolled?: boolean
}

interface LearningStats {
  totalCourses: number
  enrolledCourses: number
  completedCourses: number
  totalHours: number
  certificates: number
  rank: number
}

export function LearnDashboard() {
  const { data: session } = useSession()
  const [courses, setCourses] = useState<Course[]>([])
  const [learningStats, setLearningStats] = useState<LearningStats | null>(null)
  const [selectedLanguage, setSelectedLanguage] = useState('all')
  const [selectedDifficulty, setSelectedDifficulty] = useState('all')
  const [isLoading, setIsLoading] = useState(true)

  const languages = [
    { value: 'all', label: 'Todos los lenguajes' },
    { value: 'python', label: 'Python' },
    { value: 'csharp', label: 'C#' },
    { value: 'cpp', label: 'C++' },
    { value: 'general', label: 'General' }
  ]

  const difficulties = [
    { value: 'all', label: 'Todas las dificultades' },
    { value: 'beginner', label: 'Principiante' },
    { value: 'intermediate', label: 'Intermedio' },
    { value: 'advanced', label: 'Avanzado' }
  ]

  useEffect(() => {
    fetchData()
  }, [])

  const fetchData = async () => {
    try {
      setIsLoading(true)
      
      // Fetch courses
      const coursesResponse = await fetch('/api/learn/courses')
      if (coursesResponse.ok) {
        const coursesData = await coursesResponse.json()
        setCourses(coursesData.courses || [])
      }

      // Fetch learning stats
      const statsResponse = await fetch('/api/learn/stats')
      if (statsResponse.ok) {
        const statsData = await statsResponse.json()
        setLearningStats(statsData.stats || null)
      }
    } catch (error) {
      console.error('Error fetching data:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const filteredCourses = courses.filter(course => {
    const languageMatch = selectedLanguage === 'all' || course.language === selectedLanguage
    const difficultyMatch = selectedDifficulty === 'all' || course.difficulty === selectedDifficulty
    
    return languageMatch && difficultyMatch && course.isActive
  })

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'beginner': return 'bg-green-500'
      case 'intermediate': return 'bg-yellow-500'
      case 'advanced': return 'bg-red-500'
      default: return 'bg-gray-500'
    }
  }

  const getDifficultyLabel = (difficulty: string) => {
    switch (difficulty) {
      case 'beginner': return 'Principiante'
      case 'intermediate': return 'Intermedio'
      case 'advanced': return 'Avanzado'
      default: return difficulty
    }
  }

  const getLanguageIcon = (language: string) => {
    switch (language) {
      case 'python': return Code2
      case 'csharp': return Zap
      case 'cpp': return Trophy
      default: return BookOpen
    }
  }

  const getLanguageColor = (language: string) => {
    switch (language) {
      case 'python': return 'bg-blue-500'
      case 'csharp': return 'bg-purple-500'
      case 'cpp': return 'bg-red-500'
      default: return 'bg-gray-500'
    }
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-7xl">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <div className="h-16 w-16 rounded-2xl bg-green-500 flex items-center justify-center">
              <BookOpen className="h-8 w-8 text-white" />
            </div>
          </div>
          <h1 className="text-3xl font-bold tracking-tight mb-4">
            Centro de Aprendizaje
          </h1>
          <p className="text-lg text-muted-foreground">
            Cursos estructurados para dominar la programación paso a paso
          </p>
        </div>

        {/* Learning Stats */}
        {learningStats && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1, duration: 0.6 }}
            className="mb-8"
          >
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-4">
              <Card>
                <CardContent className="p-6 text-center">
                  <div className="flex items-center justify-center mb-2">
                    <BookOpen className="h-6 w-6 text-blue-500" />
                  </div>
                  <div className="text-2xl font-bold">{learningStats.totalCourses}</div>
                  <div className="text-sm text-muted-foreground">Cursos</div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6 text-center">
                  <div className="flex items-center justify-center mb-2">
                    <Users className="h-6 w-6 text-green-500" />
                  </div>
                  <div className="text-2xl font-bold">{learningStats.enrolledCourses}</div>
                  <div className="text-sm text-muted-foreground">Inscritos</div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6 text-center">
                  <div className="flex items-center justify-center mb-2">
                    <CheckCircle className="h-6 w-6 text-green-500" />
                  </div>
                  <div className="text-2xl font-bold">{learningStats.completedCourses}</div>
                  <div className="text-sm text-muted-foreground">Completados</div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6 text-center">
                  <div className="flex items-center justify-center mb-2">
                    <Clock className="h-6 w-6 text-purple-500" />
                  </div>
                  <div className="text-2xl font-bold">{learningStats.totalHours}h</div>
                  <div className="text-sm text-muted-foreground">Estudiadas</div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6 text-center">
                  <div className="flex items-center justify-center mb-2">
                    <Award className="h-6 w-6 text-yellow-500" />
                  </div>
                  <div className="text-2xl font-bold">{learningStats.certificates}</div>
                  <div className="text-sm text-muted-foreground">Certificados</div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6 text-center">
                  <div className="flex items-center justify-center mb-2">
                    <TrendingUp className="h-6 w-6 text-indigo-500" />
                  </div>
                  <div className="text-2xl font-bold">#{learningStats.rank}</div>
                  <div className="text-sm text-muted-foreground">Ranking</div>
                </CardContent>
              </Card>
            </div>
          </motion.div>
        )}

        {/* Filters */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2, duration: 0.6 }}
          className="mb-8"
        >
          <Card>
            <CardHeader>
              <CardTitle>Filtros</CardTitle>
              <CardDescription>
                Encuentra cursos específicos según tus intereses
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Lenguaje</label>
                  <Select value={selectedLanguage} onValueChange={setSelectedLanguage}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {languages.map(lang => (
                        <SelectItem key={lang.value} value={lang.value}>
                          {lang.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium">Dificultad</label>
                  <Select value={selectedDifficulty} onValueChange={setSelectedDifficulty}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {difficulties.map(diff => (
                        <SelectItem key={diff.value} value={diff.value}>
                          {diff.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Course List */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.6 }}
        >
          {filteredCourses.length === 0 ? (
            <Card>
              <CardContent className="text-center py-12">
                <BookOpen className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                <h3 className="text-lg font-semibold mb-2">No hay cursos</h3>
                <p className="text-muted-foreground">
                  No se encontraron cursos con los filtros seleccionados
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredCourses.map((course, index) => {
                const LanguageIcon = getLanguageIcon(course.language)
                return (
                  <motion.div
                    key={course.id}
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: index * 0.05, duration: 0.3 }}
                    whileHover={{ y: -5, transition: { duration: 0.2 } }}
                  >
                    <Card className="h-full hover:shadow-lg transition-all duration-300">
                      <CardHeader>
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-3">
                              <div className={`h-10 w-10 rounded-lg ${getLanguageColor(course.language)} flex items-center justify-center`}>
                                <LanguageIcon className="h-5 w-5 text-white" />
                              </div>
                              <div>
                                <CardTitle className="text-lg line-clamp-2">
                                  {course.title}
                                </CardTitle>
                              </div>
                            </div>
                            <div className="flex items-center gap-2 mb-2">
                              <Badge className={`${getDifficultyColor(course.difficulty)} text-white text-xs`}>
                                {getDifficultyLabel(course.difficulty)}
                              </Badge>
                              <Badge variant="outline" className="text-xs">
                                {course.modules} módulos
                              </Badge>
                            </div>
                          </div>
                          {course.isEnrolled && (
                            <CheckCircle className="h-6 w-6 text-green-500 flex-shrink-0" />
                          )}
                        </div>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-muted-foreground mb-4 line-clamp-3">
                          {course.description}
                        </p>
                        
                        {course.progress !== undefined ? (
                          <div className="space-y-2 mb-4">
                            <div className="flex justify-between text-sm">
                              <span>Progreso</span>
                              <span>{course.progress}%</span>
                            </div>
                            <Progress value={course.progress} className="h-2" />
                          </div>
                        ) : null}
                        
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2 text-sm text-muted-foreground">
                            <Clock className="h-4 w-4" />
                            <span>~2h total</span>
                          </div>
                          <Button asChild size="sm">
                            <Link href={`/learn/course/${course.id}`}>
                              <Play className="mr-2 h-4 w-4" />
                              {course.isEnrolled ? 'Continuar' : 'Comenzar'}
                            </Link>
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                )
              })}
            </div>
          )}
        </motion.div>

        {/* Learning Path Suggestions */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.6 }}
          className="mt-12"
        >
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="h-5 w-5" />
                Rutas de Aprendizaje Recomendadas
              </CardTitle>
              <CardDescription>
                Secuencias de cursos diseñadas para maximizar tu aprendizaje
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="p-4 border rounded-lg">
                  <h4 className="font-semibold mb-2">Principiante en Programación</h4>
                  <p className="text-sm text-muted-foreground mb-3">
                    Comienza tu journey desde cero
                  </p>
                  <div className="space-y-2">
                    <div className="text-sm">1. Python Fundamentals</div>
                    <div className="text-sm">2. Algoritmos Básicos</div>
                    <div className="text-sm">3. Estructuras de Datos</div>
                  </div>
                </div>
                
                <div className="p-4 border rounded-lg">
                  <h4 className="font-semibold mb-2">Desarrollo Web</h4>
                  <p className="text-sm text-muted-foreground mb-3">
                    Especialízate en desarrollo web
                  </p>
                  <div className="space-y-2">
                    <div className="text-sm">1. Python Fundamentals</div>
                    <div className="text-sm">2. C# Essentials</div>
                    <div className="text-sm">3. Algoritmos Avanzados</div>
                  </div>
                </div>
                
                <div className="p-4 border rounded-lg">
                  <h4 className="font-semibold mb-2">Programación de Sistemas</h4>
                  <p className="text-sm text-muted-foreground mb-3">
                    Domina la programación de bajo nivel
                  </p>
                  <div className="space-y-2">
                    <div className="text-sm">1. C++ Mastery</div>
                    <div className="text-sm">2. Estructuras de Datos</div>
                    <div className="text-sm">3. Algoritmos Avanzados</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </motion.div>
    </div>
  )
}
