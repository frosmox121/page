

'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Textarea } from '@/components/ui/textarea'
import { Copy, RotateCcw, Type } from 'lucide-react'
import { motion } from 'framer-motion'
import { useToast } from '@/hooks/use-toast'

const LOREM_WORDS = [
  'lorem', 'ipsum', 'dolor', 'sit', 'amet', 'consectetur', 'adipiscing', 'elit', 'sed', 'do',
  'eiusmod', 'tempor', 'incididunt', 'ut', 'labore', 'et', 'dolore', 'magna', 'aliqua',
  'enim', 'ad', 'minim', 'veniam', 'quis', 'nostrud', 'exercitation', 'ullamco', 'laboris',
  'nisi', 'aliquip', 'ex', 'ea', 'commodo', 'consequat', 'duis', 'aute', 'irure', 'in',
  'reprehenderit', 'voluptate', 'velit', 'esse', 'cillum', 'fugiat', 'nulla', 'pariatur',
  'excepteur', 'sint', 'occaecat', 'cupidatat', 'non', 'proident', 'sunt', 'culpa', 'qui',
  'officia', 'deserunt', 'mollit', 'anim', 'id', 'est', 'laborum'
]

export function LoremGenerator() {
  const { toast } = useToast()
  const [type, setType] = useState<'words' | 'sentences' | 'paragraphs'>('paragraphs')
  const [count, setCount] = useState(3)
  const [output, setOutput] = useState('')
  const [startWithLorem, setStartWithLorem] = useState(true)

  const generateWords = (num: number): string => {
    const words = []
    for (let i = 0; i < num; i++) {
      words.push(LOREM_WORDS[Math.floor(Math.random() * LOREM_WORDS.length)])
    }
    return words.join(' ')
  }

  const generateSentence = (minWords = 5, maxWords = 15): string => {
    const wordCount = Math.floor(Math.random() * (maxWords - minWords + 1)) + minWords
    const sentence = generateWords(wordCount)
    return sentence.charAt(0).toUpperCase() + sentence.slice(1) + '.'
  }

  const generateParagraph = (minSentences = 3, maxSentences = 7): string => {
    const sentenceCount = Math.floor(Math.random() * (maxSentences - minSentences + 1)) + minSentences
    const sentences = []
    for (let i = 0; i < sentenceCount; i++) {
      sentences.push(generateSentence())
    }
    return sentences.join(' ')
  }

  const generateLorem = () => {
    let result = ''

    switch (type) {
      case 'words':
        if (startWithLorem && count >= 2) {
          result = 'Lorem ipsum ' + generateWords(count - 2)
        } else {
          result = generateWords(count)
        }
        break

      case 'sentences':
        for (let i = 0; i < count; i++) {
          if (i === 0 && startWithLorem) {
            result += 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. '
          } else {
            result += generateSentence() + ' '
          }
        }
        break

      case 'paragraphs':
        for (let i = 0; i < count; i++) {
          if (i === 0 && startWithLorem) {
            result += 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. '
            result += generateParagraph(2, 6).slice('Lorem ipsum'.length)
          } else {
            result += generateParagraph()
          }
          if (i < count - 1) result += '\n\n'
        }
        break
    }

    setOutput(result.trim())
  }

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(output)
      toast({
        title: "¡Copiado!",
        description: "El texto Lorem Ipsum ha sido copiado al portapapeles.",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "No se pudo copiar al portapapeles.",
        variant: "destructive",
      })
    }
  }

  const reset = () => {
    setOutput('')
    setCount(3)
    setType('paragraphs')
    setStartWithLorem(true)
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <div className="h-16 w-16 rounded-2xl bg-indigo-500 flex items-center justify-center">
              <Type className="h-8 w-8 text-white" />
            </div>
          </div>
          <h1 className="text-3xl font-bold tracking-tight mb-4">
            📝 Generador Lorem Ipsum
          </h1>
          <p className="text-lg text-muted-foreground">
            Genera texto de relleno Lorem Ipsum para tus diseños y mockups
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Controls */}
          <Card>
            <CardHeader>
              <CardTitle>Configuración</CardTitle>
              <CardDescription>
                Configura el tipo y cantidad de texto a generar
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Type Selection */}
              <div className="space-y-2">
                <Label htmlFor="type">Tipo de contenido</Label>
                <Select value={type} onValueChange={(value: 'words' | 'sentences' | 'paragraphs') => setType(value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="words">Palabras</SelectItem>
                    <SelectItem value="sentences">Oraciones</SelectItem>
                    <SelectItem value="paragraphs">Párrafos</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Count Input */}
              <div className="space-y-2">
                <Label htmlFor="count">
                  Cantidad de {type === 'words' ? 'palabras' : type === 'sentences' ? 'oraciones' : 'párrafos'}
                </Label>
                <Input
                  id="count"
                  type="number"
                  min="1"
                  max={type === 'words' ? 500 : type === 'sentences' ? 50 : 20}
                  value={count}
                  onChange={(e) => setCount(parseInt(e.target.value) || 1)}
                />
              </div>

              {/* Start with Lorem */}
              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="startWithLorem"
                  checked={startWithLorem}
                  onChange={(e) => setStartWithLorem(e.target.checked)}
                  className="rounded"
                />
                <Label htmlFor="startWithLorem">
                  Comenzar con "Lorem ipsum"
                </Label>
              </div>

              {/* Actions */}
              <div className="flex gap-2">
                <Button onClick={generateLorem} className="flex-1">
                  <Type className="mr-2 h-4 w-4" />
                  Generar
                </Button>
                <Button onClick={reset} variant="outline">
                  <RotateCcw className="h-4 w-4" />
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Output */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Resultado</CardTitle>
                  <CardDescription>
                    Tu texto Lorem Ipsum generado
                  </CardDescription>
                </div>
                {output && (
                  <Button onClick={copyToClipboard} size="sm">
                    <Copy className="mr-2 h-4 w-4" />
                    Copiar
                  </Button>
                )}
              </div>
            </CardHeader>
            <CardContent>
              {output ? (
                <Textarea
                  value={output}
                  readOnly
                  rows={15}
                  className="resize-none font-mono text-sm"
                />
              ) : (
                <div className="flex items-center justify-center h-64 border-2 border-dashed border-muted-foreground/25 rounded-lg">
                  <div className="text-center">
                    <Type className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                    <p className="text-muted-foreground">
                      Haz clic en "Generar" para crear tu texto Lorem Ipsum
                    </p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Info */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>¿Qué es Lorem Ipsum?</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">
              Lorem Ipsum es simplemente texto de relleno de las imprentas y archivos de texto. 
              Lorem Ipsum ha sido el texto de relleno estándar de las industrias desde el año 1500, 
              cuando un impresor desconocido usó una galería de textos y los mezcló de tal manera 
              que logró hacer un libro de textos especimen.
            </p>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  )
}
