

'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { CheckCircle, XCircle, Mail, RotateCcw, Upload } from 'lucide-react'
import { motion } from 'framer-motion'

interface EmailValidationResult {
  email: string
  isValid: boolean
  errors: string[]
}

export function EmailValidator() {
  const [singleEmail, setSingleEmail] = useState('')
  const [bulkEmails, setBulkEmails] = useState('')
  const [singleResult, setSingleResult] = useState<EmailValidationResult | null>(null)
  const [bulkResults, setBulkResults] = useState<EmailValidationResult[]>([])
  const [mode, setMode] = useState<'single' | 'bulk'>('single')

  const validateEmail = (email: string): EmailValidationResult => {
    const errors: string[] = []
    let isValid = true

    // Trim whitespace
    email = email.trim()

    if (!email) {
      errors.push('El email no puede estar vacío')
      isValid = false
      return { email, isValid, errors }
    }

    // Basic format check
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(email)) {
      errors.push('Formato de email inválido')
      isValid = false
    }

    // Length check
    if (email.length > 254) {
      errors.push('El email es demasiado largo (máximo 254 caracteres)')
      isValid = false
    }

    // Local part checks (before @)
    const [localPart, domain] = email.split('@')
    
    if (localPart) {
      if (localPart.length > 64) {
        errors.push('La parte local es demasiado larga (máximo 64 caracteres)')
        isValid = false
      }

      if (localPart.startsWith('.') || localPart.endsWith('.')) {
        errors.push('La parte local no puede empezar o terminar con punto')
        isValid = false
      }

      if (localPart.includes('..')) {
        errors.push('La parte local no puede contener puntos consecutivos')
        isValid = false
      }

      // Special characters check
      const validLocalChars = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+$/
      if (!validLocalChars.test(localPart)) {
        errors.push('La parte local contiene caracteres inválidos')
        isValid = false
      }
    }

    // Domain checks (after @)
    if (domain) {
      if (domain.length > 253) {
        errors.push('El dominio es demasiado largo (máximo 253 caracteres)')
        isValid = false
      }

      if (domain.startsWith('.') || domain.endsWith('.')) {
        errors.push('El dominio no puede empezar o terminar con punto')
        isValid = false
      }

      if (domain.includes('..')) {
        errors.push('El dominio no puede contener puntos consecutivos')
        isValid = false
      }

      // Domain format check
      const domainRegex = /^[a-zA-Z0-9.-]+$/
      if (!domainRegex.test(domain)) {
        errors.push('El dominio contiene caracteres inválidos')
        isValid = false
      }

      // TLD check (at least 2 characters)
      const parts = domain.split('.')
      const tld = parts[parts.length - 1]
      if (tld.length < 2) {
        errors.push('El TLD debe tener al menos 2 caracteres')
        isValid = false
      }

      // Common domain checks
      const commonDomains = ['gmail.com', 'yahoo.com', 'hotmail.com', 'outlook.com', 'company.com']
      // This is just for demonstration - in a real app you might check against a list of valid domains
    }

    return { email, isValid, errors }
  }

  const handleSingleValidation = () => {
    const result = validateEmail(singleEmail)
    setSingleResult(result)
  }

  const handleBulkValidation = () => {
    const emails = bulkEmails
      .split('\n')
      .map(email => email.trim())
      .filter(email => email.length > 0)

    const results = emails.map(email => validateEmail(email))
    setBulkResults(results)
  }

  const reset = () => {
    setSingleEmail('')
    setBulkEmails('')
    setSingleResult(null)
    setBulkResults([])
  }

  const getValidCount = () => bulkResults.filter(r => r.isValid).length
  const getInvalidCount = () => bulkResults.filter(r => !r.isValid).length

  useEffect(() => {
    if (singleEmail && mode === 'single') {
      handleSingleValidation()
    }
  }, [singleEmail, mode])

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <div className="h-16 w-16 rounded-2xl bg-blue-500 flex items-center justify-center">
              <Mail className="h-8 w-8 text-white" />
            </div>
          </div>
          <h1 className="text-3xl font-bold tracking-tight mb-4">
            📧 Validador de Emails
          </h1>
          <p className="text-lg text-muted-foreground">
            Valida la estructura y formato de direcciones de correo electrónico
          </p>
        </div>

        {/* Mode Selector */}
        <div className="flex justify-center mb-8">
          <div className="bg-muted p-1 rounded-lg">
            <Button
              variant={mode === 'single' ? 'default' : 'ghost'}
              onClick={() => setMode('single')}
              size="sm"
            >
              Email Individual
            </Button>
            <Button
              variant={mode === 'bulk' ? 'default' : 'ghost'}
              onClick={() => setMode('bulk')}
              size="sm"
            >
              Validación Masiva
            </Button>
          </div>
        </div>

        {mode === 'single' ? (
          /* Single Email Validation */
          <div className="max-w-2xl mx-auto">
            <Card>
              <CardHeader>
                <CardTitle>Validar Email Individual</CardTitle>
                <CardDescription>
                  Ingresa una dirección de email para validar su formato
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="singleEmail">Dirección de Email</Label>
                  <Input
                    id="singleEmail"
                    type="email"
                    placeholder="ejemplo@dominio.com"
                    value={singleEmail}
                    onChange={(e) => setSingleEmail(e.target.value)}
                  />
                </div>

                {singleResult && (
                  <div className={`p-4 rounded-lg border-2 ${
                    singleResult.isValid 
                      ? 'border-green-200 bg-green-50 dark:border-green-800 dark:bg-green-950' 
                      : 'border-red-200 bg-red-50 dark:border-red-800 dark:bg-red-950'
                  }`}>
                    <div className="flex items-center gap-2 mb-3">
                      {singleResult.isValid ? (
                        <CheckCircle className="h-5 w-5 text-green-600" />
                      ) : (
                        <XCircle className="h-5 w-5 text-red-600" />
                      )}
                      <span className={`font-semibold ${
                        singleResult.isValid ? 'text-green-700 dark:text-green-300' : 'text-red-700 dark:text-red-300'
                      }`}>
                        {singleResult.isValid ? 'Email Válido' : 'Email Inválido'}
                      </span>
                    </div>
                    
                    <div className="font-mono text-sm mb-3">
                      {singleResult.email}
                    </div>

                    {!singleResult.isValid && singleResult.errors.length > 0 && (
                      <div>
                        <div className="text-sm font-medium mb-2">Errores encontrados:</div>
                        <ul className="list-disc list-inside space-y-1 text-sm text-red-600 dark:text-red-400">
                          {singleResult.errors.map((error, index) => (
                            <li key={index}>{error}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        ) : (
          /* Bulk Email Validation */
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Validación Masiva de Emails</CardTitle>
                <CardDescription>
                  Ingresa múltiples emails (uno por línea) para validarlos todos a la vez
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="bulkEmails">Emails (uno por línea)</Label>
                  <Textarea
                    id="bulkEmails"
                    placeholder={`ejemplo1@dominio.com\nejemplo2@dominio.com\nejemplo3@dominio.com`}
                    value={bulkEmails}
                    onChange={(e) => setBulkEmails(e.target.value)}
                    rows={8}
                  />
                </div>

                <div className="flex justify-between items-center">
                  <Button onClick={handleBulkValidation} disabled={!bulkEmails.trim()}>
                    <Mail className="mr-2 h-4 w-4" />
                    Validar Todos
                  </Button>
                  
                  {bulkResults.length > 0 && (
                    <div className="flex gap-2">
                      <Badge className="bg-green-500">
                        <CheckCircle className="mr-1 h-3 w-3" />
                        {getValidCount()} válidos
                      </Badge>
                      <Badge variant="destructive">
                        <XCircle className="mr-1 h-3 w-3" />
                        {getInvalidCount()} inválidos
                      </Badge>
                    </div>
                  )}
                </div>

                {bulkResults.length > 0 && (
                  <div className="space-y-3 max-h-96 overflow-y-auto">
                    {bulkResults.map((result, index) => (
                      <div key={index} className={`p-3 rounded-lg border ${
                        result.isValid 
                          ? 'border-green-200 bg-green-50 dark:border-green-800 dark:bg-green-950' 
                          : 'border-red-200 bg-red-50 dark:border-red-800 dark:bg-red-950'
                      }`}>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2 flex-1">
                            {result.isValid ? (
                              <CheckCircle className="h-4 w-4 text-green-600 flex-shrink-0" />
                            ) : (
                              <XCircle className="h-4 w-4 text-red-600 flex-shrink-0" />
                            )}
                            <span className="font-mono text-sm truncate">{result.email}</span>
                          </div>
                          <Badge variant={result.isValid ? 'default' : 'destructive'} className="text-xs">
                            {result.isValid ? 'Válido' : 'Inválido'}
                          </Badge>
                        </div>
                        
                        {!result.isValid && result.errors.length > 0 && (
                          <div className="mt-2 text-xs text-red-600 dark:text-red-400">
                            {result.errors.join(', ')}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        )}

        {/* Reset Button */}
        <div className="text-center mt-8">
          <Button onClick={reset} variant="outline">
            <RotateCcw className="mr-2 h-4 w-4" />
            Limpiar Todo
          </Button>
        </div>

        {/* Info */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>Reglas de Validación</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-sm">
              <div>
                <h4 className="font-semibold mb-2">Formato Básico:</h4>
                <ul className="space-y-1 text-muted-foreground">
                  <li>• Debe contener exactamente un símbolo @</li>
                  <li>• Debe tener una parte local y un dominio</li>
                  <li>• No puede exceder 254 caracteres totales</li>
                  <li>• No puede contener espacios</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold mb-2">Restricciones Avanzadas:</h4>
                <ul className="space-y-1 text-muted-foreground">
                  <li>• Parte local máximo 64 caracteres</li>
                  <li>• Dominio máximo 253 caracteres</li>
                  <li>• No puede empezar/terminar con punto</li>
                  <li>• No puede tener puntos consecutivos</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  )
}
