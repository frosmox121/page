
'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Globe, MapPin, Server, Wifi, Eye, Search, Copy, Check, AlertCircle, RefreshCw } from 'lucide-react'
import { motion } from 'framer-motion'

interface IPInfo {
  ip: string
  type: 'IPv4' | 'IPv6'
  country: string
  countryCode: string
  region: string
  city: string
  latitude: number
  longitude: number
  timezone: string
  isp: string
  organization: string
  asn: string
  threat: {
    isTor: boolean
    isProxy: boolean
    isAnonymous: boolean
    isKnownAttacker: boolean
    isKnownAbuser: boolean
    isThreat: boolean
    isBogon: boolean
  }
}

export function IpAnalyzer() {
  const [input, setInput] = useState('')
  const [ipInfo, setIpInfo] = useState<IPInfo | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState('')
  const [copiedField, setCopiedField] = useState<string | null>(null)

  const validateIP = (ip: string): boolean => {
    const ipv4Regex = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/
    const ipv6Regex = /^(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$|^::1$|^::$/
    return ipv4Regex.test(ip) || ipv6Regex.test(ip)
  }

  const getIPType = (ip: string): 'IPv4' | 'IPv6' => {
    return ip.includes(':') ? 'IPv6' : 'IPv4'
  }

  const analyzeIP = async () => {
    const ipToAnalyze = input.trim()
    
    if (!ipToAnalyze) {
      setError('Por favor ingresa una dirección IP')
      return
    }

    if (!validateIP(ipToAnalyze)) {
      setError('Formato de IP inválido')
      return
    }

    setIsLoading(true)
    setError('')

    try {
      // Try multiple IP geolocation services for better reliability
      let ipData: any = null
      
      // First try: ipapi.co (free tier: 1000 requests/day)
      try {
        const response = await fetch(`https://ipapi.co/${ipToAnalyze}/json/`)
        if (response.ok) {
          ipData = await response.json()
        }
      } catch (e) {
        console.log('ipapi.co failed, trying backup...')
      }

      // Backup: ip-api.com (free, no key required)
      if (!ipData || ipData.error) {
        try {
          const response = await fetch(`http://ip-api.com/json/${ipToAnalyze}?fields=status,message,country,countryCode,region,city,lat,lon,timezone,isp,org,as,proxy,hosting`)
          if (response.ok) {
            const backupData = await response.json()
            if (backupData.status === 'success') {
              ipData = {
                ip: ipToAnalyze,
                country_name: backupData.country,
                country_code: backupData.countryCode,
                region: backupData.region,
                city: backupData.city,
                latitude: backupData.lat,
                longitude: backupData.lon,
                timezone: backupData.timezone,
                org: backupData.isp,
                asn: backupData.as,
                is_proxy: backupData.proxy,
                is_hosting: backupData.hosting
              }
            }
          }
        } catch (e) {
          console.log('ip-api.com also failed')
        }
      }

      if (!ipData || ipData.error) {
        // Fallback to basic info if APIs fail
        setIpInfo({
          ip: ipToAnalyze,
          type: getIPType(ipToAnalyze),
          country: 'Información no disponible',
          countryCode: '--',
          region: 'Información no disponible',
          city: 'Información no disponible',
          latitude: 0,
          longitude: 0,
          timezone: 'Información no disponible',
          isp: 'Información no disponible',
          organization: 'Información no disponible',
          asn: 'Información no disponible',
          threat: {
            isTor: false,
            isProxy: false,
            isAnonymous: false,
            isKnownAttacker: false,
            isKnownAbuser: false,
            isThreat: false,
            isBogon: false
          }
        })
        setError('APIs de geolocalización temporalmente no disponibles. Mostrando información básica.')
        return
      }

      // Process the successful response
      setIpInfo({
        ip: ipToAnalyze,
        type: getIPType(ipToAnalyze),
        country: ipData.country_name || ipData.country || 'No disponible',
        countryCode: ipData.country_code || ipData.countryCode || '--',
        region: ipData.region || 'No disponible',
        city: ipData.city || 'No disponible',
        latitude: ipData.latitude || ipData.lat || 0,
        longitude: ipData.longitude || ipData.lon || 0,
        timezone: ipData.timezone || 'No disponible',
        isp: ipData.org || ipData.isp || 'No disponible',
        organization: ipData.org || ipData.isp || 'No disponible',
        asn: ipData.asn || ipData.as || 'No disponible',
        threat: {
          isTor: ipData.is_tor || false,
          isProxy: ipData.is_proxy || ipData.proxy || false,
          isAnonymous: ipData.is_anonymous || false,
          isKnownAttacker: ipData.is_known_attacker || false,
          isKnownAbuser: ipData.is_known_abuser || false,
          isThreat: ipData.is_threat || false,
          isBogon: ipData.is_bogon || false
        }
      })
    } catch (err) {
      setError('Error al obtener información de la IP. Intenta nuevamente.')
      console.error('IP analysis error:', err)
    } finally {
      setIsLoading(false)
    }
  }

  const getMyIP = async () => {
    setIsLoading(true)
    try {
      const response = await fetch('https://api.ipify.org?format=json')
      const data = await response.json()
      setInput(data.ip)
      setError('')
    } catch (err) {
      setError('No se pudo obtener tu IP pública')
    } finally {
      setIsLoading(false)
    }
  }

  const copyToClipboard = async (text: string, field: string) => {
    try {
      await navigator.clipboard.writeText(text)
      setCopiedField(field)
      setTimeout(() => setCopiedField(null), 2000)
    } catch (err) {
      console.error('Failed to copy text: ', err)
    }
  }

  const clearResults = () => {
    setInput('')
    setIpInfo(null)
    setError('')
  }

  const loadExampleIP = () => {
    setInput('8.8.8.8') // Google DNS
  }

  const getThreatLevel = () => {
    if (!ipInfo) return null
    
    const threats = ipInfo.threat
    let threatCount = 0
    
    if (threats.isTor) threatCount++
    if (threats.isProxy) threatCount++
    if (threats.isAnonymous) threatCount++
    if (threats.isKnownAttacker) threatCount++
    if (threats.isKnownAbuser) threatCount++
    if (threats.isThreat) threatCount++
    
    if (threatCount === 0) return { level: 'Bajo', color: 'bg-green-500', description: 'IP aparenta ser segura' }
    if (threatCount <= 2) return { level: 'Medio', color: 'bg-yellow-500', description: 'Algunas características sospechosas' }
    return { level: 'Alto', color: 'bg-red-500', description: 'Múltiples indicadores de amenaza' }
  }

  const threatLevel = getThreatLevel()

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <div className="h-16 w-16 rounded-2xl bg-green-500 flex items-center justify-center">
              <Globe className="h-8 w-8 text-white" />
            </div>
          </div>
          <h1 className="text-3xl font-bold tracking-tight mb-4">
            🌐 Analizador de IP
          </h1>
          <p className="text-lg text-muted-foreground">
            Obtén información detallada sobre direcciones IP incluyendo geolocalización y análisis de seguridad
          </p>
        </div>

        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Search className="h-5 w-5" />
              Buscar IP
            </CardTitle>
            <CardDescription>
              Ingresa una dirección IPv4 o IPv6 para analizar
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="ip-input">Dirección IP</Label>
              <Input
                id="ip-input"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Ej: 8.8.8.8 o 2001:4860:4860::8888"
                className="font-mono"
                onKeyDown={(e) => e.key === 'Enter' && analyzeIP()}
              />
            </div>
            
            <div className="flex flex-wrap gap-2">
              <Button onClick={analyzeIP} disabled={isLoading}>
                {isLoading ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                    Analizando...
                  </>
                ) : (
                  <>
                    <Search className="mr-2 h-4 w-4" />
                    Analizar
                  </>
                )}
              </Button>
              <Button onClick={getMyIP} variant="outline" disabled={isLoading}>
                <Eye className="mr-2 h-4 w-4" />
                Mi IP
              </Button>
              <Button onClick={loadExampleIP} variant="outline">
                <RefreshCw className="mr-2 h-4 w-4" />
                Ejemplo
              </Button>
              <Button onClick={clearResults} variant="outline">
                Limpiar
              </Button>
            </div>

            {error && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>

        {ipInfo && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
            className="space-y-6"
          >
            <Tabs defaultValue="general" className="w-full">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="general">General</TabsTrigger>
                <TabsTrigger value="location">Ubicación</TabsTrigger>
                <TabsTrigger value="network">Red</TabsTrigger>
                <TabsTrigger value="security">Seguridad</TabsTrigger>
              </TabsList>
              
              <TabsContent value="general" className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  <Card>
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-medium text-muted-foreground">Dirección IP</span>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => copyToClipboard(ipInfo.ip, 'ip')}
                        >
                          {copiedField === 'ip' ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                        </Button>
                      </div>
                      <div className="text-lg font-semibold font-mono">{ipInfo.ip}</div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardContent className="p-6">
                      <span className="text-sm font-medium text-muted-foreground">Tipo</span>
                      <div className="flex items-center gap-2 mt-2">
                        <Badge variant={ipInfo.type === 'IPv4' ? 'default' : 'secondary'}>
                          {ipInfo.type}
                        </Badge>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardContent className="p-6">
                      <span className="text-sm font-medium text-muted-foreground">País</span>
                      <div className="text-lg font-semibold mt-2 flex items-center gap-2">
                        <span className="text-2xl">{ipInfo.countryCode !== '--' ? `${ipInfo.countryCode}` : '🌍'}</span>
                        {ipInfo.country}
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
              
              <TabsContent value="location" className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <MapPin className="h-5 w-5" />
                        Información Geográfica
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-1 gap-4">
                        <div>
                          <span className="text-sm font-medium text-muted-foreground">Ciudad</span>
                          <div className="text-lg font-semibold">{ipInfo.city}</div>
                        </div>
                        <div>
                          <span className="text-sm font-medium text-muted-foreground">Región/Estado</span>
                          <div className="text-lg font-semibold">{ipInfo.region}</div>
                        </div>
                        <div>
                          <span className="text-sm font-medium text-muted-foreground">Zona Horaria</span>
                          <div className="text-lg font-semibold">{ipInfo.timezone}</div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader>
                      <CardTitle>Coordenadas</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div>
                        <span className="text-sm font-medium text-muted-foreground">Latitud</span>
                        <div className="text-lg font-semibold font-mono">{ipInfo.latitude}°</div>
                      </div>
                      <div>
                        <span className="text-sm font-medium text-muted-foreground">Longitud</span>
                        <div className="text-lg font-semibold font-mono">{ipInfo.longitude}°</div>
                      </div>
                      {ipInfo.latitude !== 0 && ipInfo.longitude !== 0 && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => window.open(`https://www.google.com/maps?q=${ipInfo.latitude},${ipInfo.longitude}`, '_blank')}
                        >
                          <MapPin className="mr-2 h-4 w-4" />
                          Ver en Maps
                        </Button>
                      )}
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
              
              <TabsContent value="network" className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Server className="h-5 w-5" />
                        Información de Red
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div>
                        <span className="text-sm font-medium text-muted-foreground">ISP</span>
                        <div className="text-lg font-semibold">{ipInfo.isp}</div>
                      </div>
                      <div>
                        <span className="text-sm font-medium text-muted-foreground">Organización</span>
                        <div className="text-lg font-semibold">{ipInfo.organization}</div>
                      </div>
                      <div>
                        <span className="text-sm font-medium text-muted-foreground">ASN</span>
                        <div className="text-lg font-semibold">{ipInfo.asn}</div>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Wifi className="h-5 w-5" />
                        Detalles Técnicos
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div>
                        <span className="text-sm font-medium text-muted-foreground">Versión IP</span>
                        <div className="text-lg font-semibold">{ipInfo.type}</div>
                      </div>
                      <div>
                        <span className="text-sm font-medium text-muted-foreground">Clase de Red</span>
                        <div className="text-lg font-semibold">
                          {ipInfo.type === 'IPv4' ? 
                            (ipInfo.ip.startsWith('192.168.') || ipInfo.ip.startsWith('10.') || ipInfo.ip.startsWith('172.') ? 'Privada' : 'Pública') 
                            : 'IPv6'
                          }
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
              
              <TabsContent value="security" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <AlertCircle className="h-5 w-5" />
                      Análisis de Seguridad
                    </CardTitle>
                    <CardDescription>
                      Evaluación de posibles amenazas asociadas con esta IP
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {threatLevel && (
                      <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
                        <div>
                          <div className="font-semibold">Nivel de Amenaza</div>
                          <div className="text-sm text-muted-foreground">{threatLevel.description}</div>
                        </div>
                        <Badge className={`${threatLevel.color} text-white`}>
                          {threatLevel.level}
                        </Badge>
                      </div>
                    )}
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-3">
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Red Tor</span>
                          <Badge variant={ipInfo.threat.isTor ? 'destructive' : 'secondary'}>
                            {ipInfo.threat.isTor ? 'Sí' : 'No'}
                          </Badge>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Proxy</span>
                          <Badge variant={ipInfo.threat.isProxy ? 'destructive' : 'secondary'}>
                            {ipInfo.threat.isProxy ? 'Sí' : 'No'}
                          </Badge>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Anónimo</span>
                          <Badge variant={ipInfo.threat.isAnonymous ? 'destructive' : 'secondary'}>
                            {ipInfo.threat.isAnonymous ? 'Sí' : 'No'}
                          </Badge>
                        </div>
                      </div>
                      
                      <div className="space-y-3">
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Atacante Conocido</span>
                          <Badge variant={ipInfo.threat.isKnownAttacker ? 'destructive' : 'secondary'}>
                            {ipInfo.threat.isKnownAttacker ? 'Sí' : 'No'}
                          </Badge>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Abusador Conocido</span>
                          <Badge variant={ipInfo.threat.isKnownAbuser ? 'destructive' : 'secondary'}>
                            {ipInfo.threat.isKnownAbuser ? 'Sí' : 'No'}
                          </Badge>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Amenaza General</span>
                          <Badge variant={ipInfo.threat.isThreat ? 'destructive' : 'secondary'}>
                            {ipInfo.threat.isThreat ? 'Sí' : 'No'}
                          </Badge>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </motion.div>
        )}

        <Alert className="mt-6">
          <Globe className="h-4 w-4" />
          <AlertDescription>
            <strong>Nota:</strong> La información se obtiene de APIs públicas de geolocalización. 
            La precisión puede variar según el proveedor de servicios de internet y la ubicación.
          </AlertDescription>
        </Alert>
      </motion.div>
    </div>
  )
}
