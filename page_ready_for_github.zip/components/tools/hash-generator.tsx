
'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Copy, Hash, Check, AlertCircle } from 'lucide-react'
import { motion } from 'framer-motion'


export function HashGenerator() {
  const [input, setInput] = useState('')
  const [results, setResults] = useState({
    md5: '',
    sha1: '',
    sha256: '',
    sha512: ''
  })
  const [copiedField, setCopiedField] = useState<string | null>(null)
  const [isGenerating, setIsGenerating] = useState(false)

  // Helper function to convert buffer to hex string
  const bufferToHex = (buffer: ArrayBuffer): string => {
    return Array.from(new Uint8Array(buffer))
      .map(b => b.toString(16).padStart(2, '0'))
      .join('')
  }

  // Simple MD5 implementation (for demo purposes - not cryptographically secure)
  const simpleMD5 = (str: string): string => {
    // This is a simplified demo MD5 - in production use a proper library
    let hash = 0
    if (str.length === 0) return hash.toString(16).padStart(32, '0')
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i)
      hash = ((hash << 5) - hash) + char
      hash = hash & hash // Convert to 32bit integer
    }
    return Math.abs(hash).toString(16).padStart(32, '0')
  }

  const generateHashes = async () => {
    if (!input.trim()) return

    setIsGenerating(true)
    
    try {
      // Simulate processing time for better UX
      await new Promise(resolve => setTimeout(resolve, 300))
      
      const textBytes = new TextEncoder().encode(input)
      
      // Generate MD5 (simplified version for demo)
      const md5Hash = simpleMD5(input)
      
      // Generate SHA-1 using Web Crypto API
      const sha1Buffer = await crypto.subtle.digest('SHA-1', textBytes)
      const sha1Hash = bufferToHex(sha1Buffer)
      
      // Generate SHA-256 using Web Crypto API
      const sha256Buffer = await crypto.subtle.digest('SHA-256', textBytes)
      const sha256Hash = bufferToHex(sha256Buffer)
      
      // Generate SHA-512 using Web Crypto API
      const sha512Buffer = await crypto.subtle.digest('SHA-512', textBytes)
      const sha512Hash = bufferToHex(sha512Buffer)
      
      setResults({
        md5: md5Hash,
        sha1: sha1Hash,
        sha256: sha256Hash,
        sha512: sha512Hash
      })
    } catch (error) {
      console.error('Error generating hashes:', error)
    } finally {
      setIsGenerating(false)
    }
  }

  const copyToClipboard = async (text: string, field: string) => {
    try {
      await navigator.clipboard.writeText(text)
      setCopiedField(field)
      setTimeout(() => setCopiedField(null), 2000)
    } catch (err) {
      console.error('Failed to copy text: ', err)
    }
  }

  const clearAll = () => {
    setInput('')
    setResults({
      md5: '',
      sha1: '',
      sha256: '',
      sha512: ''
    })
    setCopiedField(null)
  }

  const hashTypes = [
    {
      name: 'MD5',
      key: 'md5' as keyof typeof results,
      description: 'Algoritmo de hash de 128 bits (no recomendado para seguridad)',
      color: 'bg-red-500'
    },
    {
      name: 'SHA-1',
      key: 'sha1' as keyof typeof results,
      description: 'Algoritmo de hash de 160 bits (vulnerabilidades conocidas)',
      color: 'bg-orange-500'
    },
    {
      name: 'SHA-256',
      key: 'sha256' as keyof typeof results,
      description: 'Algoritmo de hash seguro de 256 bits (recomendado)',
      color: 'bg-green-500'
    },
    {
      name: 'SHA-512',
      key: 'sha512' as keyof typeof results,
      description: 'Algoritmo de hash seguro de 512 bits (más seguro)',
      color: 'bg-blue-500'
    }
  ]

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <div className="h-16 w-16 rounded-2xl bg-purple-500 flex items-center justify-center">
              <Hash className="h-8 w-8 text-white" />
            </div>
          </div>
          <h1 className="text-3xl font-bold tracking-tight mb-4">
            🔧 Generador de Hash
          </h1>
          <p className="text-lg text-muted-foreground">
            Genera hashes MD5, SHA-1, SHA-256 y SHA-512 de cualquier texto
          </p>
        </div>

        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Hash className="h-5 w-5" />
              Texto de Entrada
            </CardTitle>
            <CardDescription>
              Ingresa el texto que deseas hashear
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="input">Texto</Label>
              <Textarea
                id="input"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Escribe aquí el texto que quieres hashear..."
                className="min-h-[120px] resize-none"
              />
            </div>
            
            <div className="flex gap-2">
              <Button 
                onClick={generateHashes} 
                disabled={!input.trim() || isGenerating}
                className="flex-1"
              >
                {isGenerating ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                    Generando...
                  </>
                ) : (
                  <>
                    <Hash className="mr-2 h-4 w-4" />
                    Generar Hashes
                  </>
                )}
              </Button>
              <Button variant="outline" onClick={clearAll}>
                Limpiar
              </Button>
            </div>

            {input && (
              <div className="text-sm text-muted-foreground">
                Longitud del texto: {input.length} caracteres
              </div>
            )}
          </CardContent>
        </Card>

        {Object.values(results).some(result => result) && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
          >
            <Card>
              <CardHeader>
                <CardTitle>Resultados</CardTitle>
                <CardDescription>
                  Hashes generados para tu texto
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {hashTypes.map((hashType, index) => (
                    <motion.div
                      key={hashType.key}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.1, duration: 0.4 }}
                      className="space-y-3"
                    >
                      <div className="flex items-center gap-3">
                        <div className={`h-10 w-10 rounded-lg ${hashType.color} flex items-center justify-center`}>
                          <Hash className="h-5 w-5 text-white" />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <h3 className="font-semibold">{hashType.name}</h3>
                            <Badge variant="secondary" className="text-xs">
                              {results[hashType.key].length * 4} bits
                            </Badge>
                          </div>
                          <p className="text-sm text-muted-foreground">
                            {hashType.description}
                          </p>
                        </div>
                      </div>
                      
                      {results[hashType.key] && (
                        <div className="relative">
                          <div className="p-3 bg-muted rounded-lg font-mono text-sm break-all">
                            {results[hashType.key]}
                          </div>
                          <Button
                            size="sm"
                            variant="ghost"
                            className="absolute top-2 right-2"
                            onClick={() => copyToClipboard(results[hashType.key], hashType.key)}
                          >
                            {copiedField === hashType.key ? (
                              <Check className="h-4 w-4 text-green-500" />
                            ) : (
                              <Copy className="h-4 w-4" />
                            )}
                          </Button>
                        </div>
                      )}
                    </motion.div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}

        <Alert className="mt-6">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            <strong>Nota de Seguridad:</strong> MD5 y SHA-1 tienen vulnerabilidades conocidas y no se recomiendan para aplicaciones de seguridad. 
            Usa SHA-256 o SHA-512 para casos que requieren seguridad criptográfica.
          </AlertDescription>
        </Alert>
      </motion.div>
    </div>
  )
}
