
'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import Link from 'next/link'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { 
  Code2, 
  Trophy, 
  BookOpen, 
  Gamepad2, 
  MessageSquare, 
  TrendingUp,
  Star,
  Target,
  Users,
  Clock,
  Medal,
  ArrowRight,
  Zap
} from 'lucide-react'
import { motion } from 'framer-motion'
import { useInView } from 'react-intersection-observer'

interface UserStats {
  level: number
  totalPoints: number
  practicePoints: number
  country: string
  rank: number
}

interface DashboardProps {
  userStats: UserStats | null
}

export function UserDashboard({ userStats }: DashboardProps) {
  const { data: session } = useSession()
  const [ref, inView] = useInView({ triggerOnce: true, threshold: 0.1 })
  const [recentActivity, setRecentActivity] = useState([])
  const [achievements, setAchievements] = useState([])

  useEffect(() => {
    fetchActivityAndAchievements()
  }, [session])

  const fetchActivityAndAchievements = async () => {
    if (session?.user) {
      try {
        // Fetch recent activity
        const activityResponse = await fetch('/api/user/activity')
        if (activityResponse.ok) {
          const activityData = await activityResponse.json()
          setRecentActivity(activityData.activities || [])
        }

        // Fetch achievements
        const achievementsResponse = await fetch('/api/user/achievements')
        if (achievementsResponse.ok) {
          const achievementsData = await achievementsResponse.json()
          setAchievements(achievementsData.achievements || [])
        }
      } catch (error) {
        console.error('Error fetching activity and achievements:', error)
      }
    }
  }

  // Calculate progress to next level
  const getProgressToNextLevel = () => {
    if (!userStats) return 0
    const pointsForCurrentLevel = (userStats.level - 1) * 100
    const pointsForNextLevel = userStats.level * 100
    const progressPoints = userStats.totalPoints - pointsForCurrentLevel
    return Math.min((progressPoints / 100) * 100, 100)
  }

  const quickActions = [
    {
      title: 'Herramientas',
      description: 'Ejecutor de código y utilidades',
      href: '/tools',
      icon: Code2,
      color: 'bg-blue-500'
    },
    {
      title: 'Practicar',
      description: 'Ejercicios de programación',
      href: '/practice',
      icon: Trophy,
      color: 'bg-yellow-500'
    },
    {
      title: 'Aprender',
      description: 'Cursos y recursos',
      href: '/learn',
      icon: BookOpen,
      color: 'bg-green-500'
    },
    {
      title: 'Juegos',
      description: 'Arcade clásicos',
      href: '/games',
      icon: Gamepad2,
      color: 'bg-purple-500'
    },
    {
      title: 'Chat IA',
      description: 'Asistente inteligente',
      href: '/chat',
      icon: MessageSquare,
      color: 'bg-pink-500'
    }
  ]

  const stats = [
    {
      label: 'Puntos Totales',
      value: userStats?.totalPoints || 0,
      icon: Star,
      color: 'text-yellow-500'
    },
    {
      label: 'Nivel Actual',
      value: userStats?.level || 1,
      icon: TrendingUp,
      color: 'text-blue-500'
    },
    {
      label: 'Ranking',
      value: `#${userStats?.rank || '---'}`,
      icon: Medal,
      color: 'text-purple-500'
    },
    {
      label: 'País',
      value: userStats?.country || 'Argentina',
      icon: Users,
      color: 'text-green-500'
    }
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted">
      <div className="container mx-auto px-4 py-8">
        {/* Welcome Header */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-8"
        >
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div>
              <h1 className="text-3xl font-bold tracking-tight flex items-center gap-2">
                ¡Hola, {session?.user?.name || 'Desarrollador'}!
                <span className="inline-block animate-bounce">
                  <Zap className="h-8 w-8 text-yellow-500" />
                </span>
              </h1>
              <p className="text-muted-foreground mt-2">
                Bienvenido de vuelta a DevTools. Continúa tu journey de programación.
              </p>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="secondary" className="text-sm flex items-center gap-1">
                <Users className="h-3 w-3" />
                {userStats?.country || 'Argentina'}
              </Badge>
              <Badge className="text-sm flex items-center gap-1">
                <TrendingUp className="h-3 w-3" />
                Nivel {userStats?.level || 1}
              </Badge>
            </div>
          </div>
        </motion.div>

        {/* Stats Cards */}
        <motion.div 
          ref={ref}
          initial={{ opacity: 0 }}
          animate={inView ? { opacity: 1 } : { opacity: 0 }}
          transition={{ duration: 0.6 }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8"
        >
          {stats.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
              transition={{ delay: index * 0.1, duration: 0.6 }}
            >
              <Card className="h-full hover:shadow-lg transition-all duration-300">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">
                        {stat.label}
                      </p>
                      <p className="text-2xl font-bold">
                        {stat.value}
                      </p>
                    </div>
                    <div className={`h-12 w-12 rounded-lg bg-muted flex items-center justify-center`}>
                      <stat.icon className={`h-6 w-6 ${stat.color}`} />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>

        {/* Progress Section */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ delay: 0.2, duration: 0.6 }}
          className="mb-8"
        >
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="h-5 w-5" />
                Progreso General
              </CardTitle>
              <CardDescription>
                Tu progreso hacia el siguiente nivel
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between text-sm">
                  <span>Nivel {userStats?.level || 1}</span>
                  <span>{userStats?.totalPoints || 0} puntos</span>
                  <span>Nivel {(userStats?.level || 1) + 1}</span>
                </div>
                <Progress value={getProgressToNextLevel()} className="h-3" />
                <p className="text-sm text-muted-foreground">
                  Necesitas {((userStats?.level || 1) * 100) - (userStats?.totalPoints || 0)} puntos más para subir al siguiente nivel
                </p>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Quick Actions */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ delay: 0.3, duration: 0.6 }}
          className="mb-8"
        >
          <h2 className="text-2xl font-bold tracking-tight mb-6">Acciones Rápidas</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6">
            {quickActions.map((action, index) => (
              <motion.div
                key={action.title}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={inView ? { opacity: 1, scale: 1 } : { opacity: 0, scale: 0.9 }}
                transition={{ delay: 0.1 * index, duration: 0.4 }}
                whileHover={{ y: -5, transition: { duration: 0.2 } }}
              >
                <Card className="h-full hover:shadow-xl transition-all duration-300 cursor-pointer group">
                  <Link href={action.href}>
                    <CardContent className="p-6">
                      <div className="flex flex-col items-center text-center space-y-4">
                        <div className={`h-16 w-16 rounded-2xl ${action.color} flex items-center justify-center group-hover:scale-110 transition-transform duration-300`}>
                          <action.icon className="h-8 w-8 text-white" />
                        </div>
                        <div>
                          <h3 className="font-semibold text-lg">{action.title}</h3>
                          <p className="text-sm text-muted-foreground mt-1">
                            {action.description}
                          </p>
                        </div>
                        <ArrowRight className="h-4 w-4 text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all duration-300" />
                      </div>
                    </CardContent>
                  </Link>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Recent Activity & Achievements */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Recent Activity */}
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={inView ? { opacity: 1, x: 0 } : { opacity: 0, x: -20 }}
            transition={{ delay: 0.4, duration: 0.6 }}
          >
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="h-5 w-5" />
                  Actividad Reciente
                </CardTitle>
                <CardDescription>
                  Tus últimas acciones en la plataforma
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentActivity.length === 0 ? (
                    <div className="text-center py-8">
                      <Zap className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                      <p className="text-muted-foreground">
                        Aún no tienes actividad reciente
                      </p>
                      <Button variant="outline" className="mt-4" asChild>
                        <Link href="/practice">
                          Comenzar a Practicar
                        </Link>
                      </Button>
                    </div>
                  ) : (
                    recentActivity.map((activity: any, index) => (
                      <div key={index} className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                        <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center">
                          <Trophy className="h-4 w-4 text-primary" />
                        </div>
                        <div className="flex-1">
                          <p className="text-sm font-medium">{activity.title}</p>
                          <p className="text-xs text-muted-foreground">{activity.time}</p>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Achievements */}
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={inView ? { opacity: 1, x: 0 } : { opacity: 0, x: 20 }}
            transition={{ delay: 0.5, duration: 0.6 }}
          >
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Medal className="h-5 w-5" />
                  Logros
                </CardTitle>
                <CardDescription>
                  Tus logros y reconocimientos
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {achievements.length === 0 ? (
                    <div className="text-center py-8">
                      <Medal className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                      <p className="text-muted-foreground">
                        Aún no tienes logros desbloqueados
                      </p>
                      <p className="text-sm text-muted-foreground mt-2">
                        ¡Comienza a practicar para ganar tus primeros logros!
                      </p>
                    </div>
                  ) : (
                    achievements.map((achievement: any, index) => (
                      <div key={index} className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                        <div className="h-8 w-8 rounded-full bg-yellow-500/10 flex items-center justify-center">
                          <Medal className="h-4 w-4 text-yellow-500" />
                        </div>
                        <div className="flex-1">
                          <p className="text-sm font-medium">{achievement.title}</p>
                          <p className="text-xs text-muted-foreground">{achievement.description}</p>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </div>
  )
}
