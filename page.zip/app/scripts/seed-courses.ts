

import { PrismaClient } from '@prisma/client'
import * as dotenv from 'dotenv'

// Load environment variables
dotenv.config()

const prisma = new PrismaClient()

async function seedCourses() {
  try {
    console.log('🌱 Seeding courses...')

    // Delete existing courses to avoid duplicates
    await prisma.courseModule.deleteMany()
    await prisma.userProgress.deleteMany()
    await prisma.course.deleteMany()

    // Create Python course
    const pythonCourse = await prisma.course.create({
      data: {
        title: 'Python Fundamentals',
        description: 'Aprende los fundamentos de Python desde cero. Este curso te llevará desde los conceptos básicos hasta técnicas intermedias.',
        language: 'python',
        difficulty: 'beginner',
        imageUrl: 'https://images.unsplash.com/photo-1526379095098-d400fd0bf935?w=300&h=200&fit=crop',
        orderIndex: 1,
        isActive: true,
        modules: {
          create: [
            {
              title: 'Introducción a Python',
              content: `# Introducción a Python

Python es un lenguaje de programación de alto nivel, interpretado y de propósito general. Es conocido por su sintaxis clara y legible.

## ¿Por qué Python?

- **Fácil de aprender**: Sintaxis simple y clara
- **Versátil**: Desarrollo web, ciencia de datos, IA, automatización
- **Gran comunidad**: Amplio ecosistema de librerías
- **Multiplataforma**: Funciona en Windows, Mac, Linux

## Tu primer programa

\`\`\`python
print("¡Hola, mundo!")
\`\`\`

Este simple comando imprime texto en la pantalla. ¡Es así de fácil comenzar con Python!`,
              videoUrl: 'https://www.youtube.com/embed/kqtD5dpn9C8',
              orderIndex: 1,
              isActive: true
            },
            {
              title: 'Variables y Tipos de Datos',
              content: `# Variables y Tipos de Datos

Las variables en Python son contenedores para almacenar datos.

## Tipos de datos básicos

### Números
\`\`\`python
edad = 25          # Entero (int)
altura = 1.75      # Decimal (float)
\`\`\`

### Texto
\`\`\`python
nombre = "Ana"     # Cadena de texto (string)
apellido = 'García'
\`\`\`

### Booleanos
\`\`\`python
es_estudiante = True
tiene_trabajo = False
\`\`\`

## Operaciones básicas
\`\`\`python
# Aritmética
suma = 10 + 5      # 15
resta = 10 - 3     # 7
multiplicacion = 4 * 3  # 12
division = 15 / 3  # 5.0

# Concatenación de texto
saludo = "Hola " + nombre  # "Hola Ana"
\`\`\``,
              orderIndex: 2,
              isActive: true
            },
            {
              title: 'Estructuras de Control',
              content: `# Estructuras de Control

Las estructuras de control permiten que tu programa tome decisiones y repita acciones.

## Condicionales (if/elif/else)

\`\`\`python
edad = 18

if edad >= 18:
    print("Eres mayor de edad")
elif edad >= 13:
    print("Eres adolescente")
else:
    print("Eres un niño")
\`\`\`

## Bucles

### Bucle for
\`\`\`python
# Repetir una acción
for i in range(5):
    print(f"Número: {i}")

# Recorrer una lista
frutas = ["manzana", "banana", "naranja"]
for fruta in frutas:
    print(f"Me gusta la {fruta}")
\`\`\`

### Bucle while
\`\`\`python
contador = 0
while contador < 5:
    print(f"Contador: {contador}")
    contador += 1
\`\`\``,
              orderIndex: 3,
              isActive: true
            }
          ]
        }
      }
    })

    // Create C# course
    const csharpCourse = await prisma.course.create({
      data: {
        title: 'C# Essentials',
        description: 'Domina los conceptos esenciales de C# y .NET. Perfecto para desarrollo de aplicaciones Windows y web.',
        language: 'csharp',
        difficulty: 'intermediate',
        imageUrl: 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=300&h=200&fit=crop',
        orderIndex: 2,
        isActive: true,
        modules: {
          create: [
            {
              title: 'Introducción a C#',
              content: `# Introducción a C#

C# es un lenguaje de programación moderno, orientado a objetos y type-safe desarrollado por Microsoft.

## Características principales

- **Orientado a objetos**: Basado en clases y objetos
- **Type-safe**: Previene errores de tipos en tiempo de compilación
- **Gestión automática de memoria**: Garbage collection integrado
- **Multiplataforma**: Con .NET Core/5+

## Tu primer programa

\`\`\`csharp
using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("¡Hola, mundo!");
    }
}
\`\`\``,
              orderIndex: 1,
              isActive: true
            },
            {
              title: 'Variables y Tipos',
              content: `# Variables y Tipos en C#

C# es un lenguaje fuertemente tipado, lo que significa que debes declarar el tipo de cada variable.

## Tipos básicos

\`\`\`csharp
// Números enteros
int edad = 25;
long poblacion = 8000000000L;

// Números decimales
float precio = 19.99f;
double pi = 3.14159265359;
decimal dinero = 1000.50m;

// Texto
string nombre = "Ana";
char inicial = 'A';

// Booleano
bool esVerdad = true;
\`\`\`

## Declaración implícita
\`\`\`csharp
var numero = 42;        // int
var texto = "Hola";     // string
var esValido = true;    // bool
\`\`\``,
              orderIndex: 2,
              isActive: true
            }
          ]
        }
      }
    })

    // Create C++ course
    const cppCourse = await prisma.course.create({
      data: {
        title: 'C++ Mastery',
        description: 'Curso avanzado de C++ para desarrollo de sistemas y aplicaciones de alto rendimiento.',
        language: 'cpp',
        difficulty: 'advanced',
        imageUrl: 'https://images.unsplash.com/photo-1515879218367-8466d910aaa4?w=300&h=200&fit=crop',
        orderIndex: 3,
        isActive: true,
        modules: {
          create: [
            {
              title: 'Fundamentos de C++',
              content: `# Fundamentos de C++

C++ es un lenguaje de programación de propósito general que soporta programación procedimental, orientada a objetos y genérica.

## Características principales

- **Control de bajo nivel**: Gestión manual de memoria
- **Alto rendimiento**: Compilado a código nativo
- **Múltiples paradigmas**: Procedimental, OOP, genérico
- **Estándar moderno**: C++11, C++14, C++17, C++20

## Programa básico

\`\`\`cpp
#include <iostream>

int main() {
    std::cout << "¡Hola, mundo!" << std::endl;
    return 0;
}
\`\`\``,
              orderIndex: 1,
              isActive: true
            }
          ]
        }
      }
    })

    console.log('✅ Courses seeded successfully!')
    console.log(`Created courses:`)
    console.log(`- Python Fundamentals (${pythonCourse.id})`)
    console.log(`- C# Essentials (${csharpCourse.id})`)
    console.log(`- C++ Mastery (${cppCourse.id})`)

  } catch (error) {
    console.error('❌ Error seeding courses:', error)
  } finally {
    await prisma.$disconnect()
  }
}

if (require.main === module) {
  seedCourses()
}

export { seedCourses }
