
import { PrismaClient } from '@prisma/client'
import bcrypt from 'bcryptjs'

const prisma = new PrismaClient()

async function main() {
  console.log('🌱 Iniciando seeding de la base de datos...')

  // Create test user
  const hashedPassword = await bcrypt.hash('johndoe123', 12)
  
  const testUser = await prisma.user.upsert({
    where: { email: 'john@doe.com' },
    update: {},
    create: {
      name: 'John Doe',
      email: 'john@doe.com',
      password: hashedPassword,
      level: 5,
      totalPoints: 450,
      practicePoints: 350,
      country: 'Argentina'
    }
  })

  console.log('✅ Usuario de test creado:', testUser.email)

  // Create Python exercises
  const pythonExercises = [
    {
      title: 'Hola Mundo en Python',
      description: 'Escribe un programa que imprima "Hola Mundo" en la consola.',
      language: 'python',
      difficulty: 'beginner',
      points: 10,
      category: 'basic-syntax',
      testCases: [
        { input: '', expected: 'Hola Mundo' }
      ],
      starterCode: '# Escribe tu código aquí\nprint("Hola Mundo")',
      solution: 'print("Hola Mundo")'
    },
    {
      title: 'Suma de dos números',
      description: 'Crea una función que sume dos números y retorne el resultado.',
      language: 'python',
      difficulty: 'beginner',
      points: 15,
      category: 'basic-syntax',
      testCases: [
        { input: '5, 3', expected: '8' },
        { input: '10, -2', expected: '8' },
        { input: '0, 0', expected: '0' }
      ],
      starterCode: 'def suma(a, b):\n    # Completa esta función\n    pass\n\n# Prueba tu función\nprint(suma(5, 3))',
      solution: 'def suma(a, b):\n    return a + b\n\nprint(suma(5, 3))'
    },
    {
      title: 'Número par o impar',
      description: 'Escribe una función que determine si un número es par o impar.',
      language: 'python',
      difficulty: 'beginner',
      points: 15,
      category: 'basic-syntax',
      testCases: [
        { input: '4', expected: 'par' },
        { input: '7', expected: 'impar' },
        { input: '0', expected: 'par' }
      ],
      starterCode: 'def par_o_impar(numero):\n    # Completa esta función\n    pass',
      solution: 'def par_o_impar(numero):\n    if numero % 2 == 0:\n        return "par"\n    else:\n        return "impar"'
    },
    {
      title: 'Factorial recursivo',
      description: 'Implementa una función recursiva para calcular el factorial de un número.',
      language: 'python',
      difficulty: 'intermediate',
      points: 25,
      category: 'algorithms',
      testCases: [
        { input: '5', expected: '120' },
        { input: '0', expected: '1' },
        { input: '3', expected: '6' }
      ],
      starterCode: 'def factorial(n):\n    # Implementa la función recursiva\n    pass',
      solution: 'def factorial(n):\n    if n == 0 or n == 1:\n        return 1\n    return n * factorial(n - 1)'
    }
  ]

  // Create C# exercises
  const csharpExercises = [
    {
      title: 'Hola Mundo en C#',
      description: 'Escribe un programa que imprima "Hola Mundo" en la consola.',
      language: 'csharp',
      difficulty: 'beginner',
      points: 10,
      category: 'basic-syntax',
      testCases: [
        { input: '', expected: 'Hola Mundo' }
      ],
      starterCode: 'using System;\n\nclass Program\n{\n    static void Main()\n    {\n        // Escribe tu código aquí\n        Console.WriteLine("Hola Mundo");\n    }\n}',
      solution: 'using System;\n\nclass Program\n{\n    static void Main()\n    {\n        Console.WriteLine("Hola Mundo");\n    }\n}'
    },
    {
      title: 'Suma en C#',
      description: 'Crea un método que sume dos números enteros.',
      language: 'csharp',
      difficulty: 'beginner',
      points: 15,
      category: 'basic-syntax',
      testCases: [
        { input: '5, 3', expected: '8' },
        { input: '10, -2', expected: '8' }
      ],
      starterCode: 'using System;\n\nclass Program\n{\n    static int Suma(int a, int b)\n    {\n        // Completa este método\n        return 0;\n    }\n    \n    static void Main()\n    {\n        Console.WriteLine(Suma(5, 3));\n    }\n}',
      solution: 'using System;\n\nclass Program\n{\n    static int Suma(int a, int b)\n    {\n        return a + b;\n    }\n    \n    static void Main()\n    {\n        Console.WriteLine(Suma(5, 3));\n    }\n}'
    }
  ]

  // Create C++ exercises
  const cppExercises = [
    {
      title: 'Hola Mundo en C++',
      description: 'Escribe un programa que imprima "Hola Mundo" en la consola.',
      language: 'cpp',
      difficulty: 'beginner',
      points: 10,
      category: 'basic-syntax',
      testCases: [
        { input: '', expected: 'Hola Mundo' }
      ],
      starterCode: '#include <iostream>\nusing namespace std;\n\nint main() {\n    // Escribe tu código aquí\n    cout << "Hola Mundo" << endl;\n    return 0;\n}',
      solution: '#include <iostream>\nusing namespace std;\n\nint main() {\n    cout << "Hola Mundo" << endl;\n    return 0;\n}'
    },
    {
      title: 'Suma en C++',
      description: 'Crea una función que sume dos números enteros.',
      language: 'cpp',
      difficulty: 'beginner',
      points: 15,
      category: 'basic-syntax',
      testCases: [
        { input: '5, 3', expected: '8' },
        { input: '10, -2', expected: '8' }
      ],
      starterCode: '#include <iostream>\nusing namespace std;\n\nint suma(int a, int b) {\n    // Completa esta función\n    return 0;\n}\n\nint main() {\n    cout << suma(5, 3) << endl;\n    return 0;\n}',
      solution: '#include <iostream>\nusing namespace std;\n\nint suma(int a, int b) {\n    return a + b;\n}\n\nint main() {\n    cout << suma(5, 3) << endl;\n    return 0;\n}'
    }
  ]

  const allExercises = [...pythonExercises, ...csharpExercises, ...cppExercises]

  for (const exercise of allExercises) {
    // Check if exercise already exists
    const existingExercise = await prisma.exercise.findFirst({
      where: { title: exercise.title }
    })
    
    if (!existingExercise) {
      await prisma.exercise.create({
        data: exercise
      })
    }
  }

  console.log(`✅ ${allExercises.length} ejercicios creados`)

  // Create courses
  const courses = [
    {
      title: 'Python Fundamentals',
      description: 'Aprende los conceptos básicos de Python desde cero.',
      language: 'python',
      difficulty: 'beginner',
      orderIndex: 1,
      modules: [
        {
          title: 'Introducción a Python',
          content: '# Introducción a Python\n\nPython es un lenguaje de programación de alto nivel, interpretado y de propósito general. Es conocido por su sintaxis simple y legible.\n\n## ¿Por qué Python?\n\n- Sintaxis simple y fácil de aprender\n- Gran comunidad y ecosistema\n- Versátil: web, ciencia de datos, IA, etc.\n- Multiplataforma\n\n## Tu primer programa\n\n```python\nprint("¡Hola, mundo!")\n```',
          orderIndex: 1
        },
        {
          title: 'Variables y Tipos de Datos',
          content: '# Variables y Tipos de Datos\n\nEn Python, las variables se crean automáticamente cuando les asignas un valor.\n\n## Tipos básicos\n\n```python\n# Números enteros\nedad = 25\n\n# Números decimales\naltura = 1.75\n\n# Cadenas de texto\nnombre = "Juan"\n\n# Booleanos\nes_estudiante = True\n```\n\n## Operaciones básicas\n\n```python\n# Operaciones matemáticas\nsuma = 5 + 3  # 8\nresta = 10 - 4  # 6\nmultiplicacion = 3 * 4  # 12\ndivision = 15 / 3  # 5.0\n```',
          orderIndex: 2
        }
      ]
    },
    {
      title: 'C# Essentials',
      description: 'Domina los fundamentos de C# y la programación orientada a objetos.',
      language: 'csharp',
      difficulty: 'beginner',
      orderIndex: 2,
      modules: [
        {
          title: 'Introducción a C#',
          content: '# Introducción a C#\n\nC# es un lenguaje de programación moderno, orientado a objetos y de propósito general desarrollado por Microsoft.\n\n## Características principales\n\n- Fuertemente tipado\n- Orientado a objetos\n- Gestión automática de memoria\n- Multiplataforma con .NET Core\n\n## Estructura básica\n\n```csharp\nusing System;\n\nclass Program\n{\n    static void Main(string[] args)\n    {\n        Console.WriteLine("¡Hola, mundo!");\n    }\n}\n```',
          orderIndex: 1
        }
      ]
    },
    {
      title: 'C++ Mastery',
      description: 'Aprende C++ desde lo básico hasta conceptos avanzados.',
      language: 'cpp',
      difficulty: 'intermediate',
      orderIndex: 3,
      modules: [
        {
          title: 'Fundamentos de C++',
          content: '# Fundamentos de C++\n\nC++ es un lenguaje de programación de propósito general que es una extensión del lenguaje C.\n\n## Características\n\n- Orientado a objetos\n- Control de memoria manual\n- Alto rendimiento\n- Usado en sistemas críticos\n\n## Programa básico\n\n```cpp\n#include <iostream>\nusing namespace std;\n\nint main() {\n    cout << "¡Hola, mundo!" << endl;\n    return 0;\n}\n```',
          orderIndex: 1
        }
      ]
    }
  ]

  for (const courseData of courses) {
    const { modules, ...course } = courseData
    
    // Check if course already exists
    let createdCourse = await prisma.course.findFirst({
      where: { title: course.title }
    })
    
    if (!createdCourse) {
      createdCourse = await prisma.course.create({
        data: course
      })
    }

    // Create modules for this course
    for (const moduleData of modules) {
      // Check if module already exists
      const existingModule = await prisma.courseModule.findFirst({
        where: {
          courseId: createdCourse.id,
          title: moduleData.title
        }
      })
      
      if (!existingModule) {
        await prisma.courseModule.create({
          data: {
            ...moduleData,
            courseId: createdCourse.id
          }
        })
      }
    }
  }

  console.log(`✅ ${courses.length} cursos creados con sus módulos`)

  // Create some sample game scores
  const gameScores = [
    {
      userId: testUser.id,
      gameType: 'snake',
      score: 150,
      level: 3
    },
    {
      userId: testUser.id,
      gameType: 'tetris',
      score: 2500,
      level: 5
    }
  ]

  for (const score of gameScores) {
    await prisma.gameScore.create({
      data: score
    })
  }

  console.log(`✅ ${gameScores.length} puntajes de juegos creados`)

  // Create achievements
  const achievements = [
    {
      title: 'Primer Paso',
      description: 'Completa tu primer ejercicio de programación',
      icon: 'Star',
      category: 'practice',
      condition: { type: 'exercises_completed', value: 1 },
      points: 10,
      rarity: 'common'
    },
    {
      title: 'Practicante',
      description: 'Completa 5 ejercicios de programación',
      icon: 'Trophy',
      category: 'practice',
      condition: { type: 'exercises_completed', value: 5 },
      points: 25,
      rarity: 'common'
    },
    {
      title: 'Experto en Práctica',
      description: 'Completa 25 ejercicios de programación',
      icon: 'Award',
      category: 'practice',
      condition: { type: 'exercises_completed', value: 25 },
      points: 100,
      rarity: 'rare'
    },
    {
      title: 'Centurión',
      description: 'Acumula 100 puntos totales',
      icon: 'Target',
      category: 'milestone',
      condition: { type: 'points_earned', value: 100 },
      points: 20,
      rarity: 'common'
    },
    {
      title: 'Millonario',
      description: 'Acumula 1000 puntos totales',
      icon: 'Crown',
      category: 'milestone',
      condition: { type: 'points_earned', value: 1000 },
      points: 200,
      rarity: 'epic'
    },
    {
      title: 'Gamer',
      description: 'Juega tu primer juego arcade',
      icon: 'Gamepad2',
      category: 'gaming',
      condition: { type: 'games_played', value: 1 },
      points: 15,
      rarity: 'common'
    },
    {
      title: 'Estudiante',
      description: 'Completa tu primer curso',
      icon: 'BookOpen',
      category: 'learning',
      condition: { type: 'courses_completed', value: 1 },
      points: 50,
      rarity: 'common'
    },
    {
      title: 'Pythonista',
      description: 'Completa 10 ejercicios de Python',
      icon: 'Code2',
      category: 'practice',
      condition: { type: 'exercises_completed', value: 10, language: 'python' },
      points: 30,
      rarity: 'common'
    },
    {
      title: 'Master C#',
      description: 'Completa 10 ejercicios de C#',
      icon: 'Zap',
      category: 'practice',
      condition: { type: 'exercises_completed', value: 10, language: 'csharp' },
      points: 30,
      rarity: 'common'
    },
    {
      title: 'C++ Warrior',
      description: 'Completa 10 ejercicios de C++',
      icon: 'Sword',
      category: 'practice',
      condition: { type: 'exercises_completed', value: 10, language: 'cpp' },
      points: 30,
      rarity: 'common'
    }
  ]

  for (const achievement of achievements) {
    const existingAchievement = await prisma.achievement.findFirst({
      where: { title: achievement.title }
    })
    
    if (!existingAchievement) {
      await prisma.achievement.create({
        data: achievement
      })
    }
  }

  console.log(`✅ ${achievements.length} logros creados`)

  // Create some sample activities for the test user
  const activities = [
    {
      userId: testUser.id,
      type: 'exercise_completed',
      title: 'Completaste "Hola Mundo en Python"',
      description: 'Ganaste 10 puntos',
      metadata: { points: 10, language: 'python' }
    },
    {
      userId: testUser.id,
      type: 'achievement_unlocked',
      title: 'Desbloqueaste "Primer Paso"',
      description: 'Tu primer logro en DevTools',
      metadata: { points: 10, rarity: 'common' }
    },
    {
      userId: testUser.id,
      type: 'course_started',
      title: 'Comenzaste "Python Fundamentals"',
      description: 'Iniciaste tu journey de aprendizaje',
      metadata: { courseTitle: 'Python Fundamentals' }
    },
    {
      userId: testUser.id,
      type: 'game_played',
      title: 'Jugaste Snake',
      description: 'Puntuación: 150 puntos',
      metadata: { gameType: 'snake', score: 150 }
    },
    {
      userId: testUser.id,
      type: 'exercise_completed',
      title: 'Completaste "Suma de dos números"',
      description: 'Ganaste 15 puntos',
      metadata: { points: 15, language: 'python' }
    }
  ]

  for (const activity of activities) {
    const existingActivity = await prisma.activity.findFirst({
      where: {
        userId: activity.userId,
        title: activity.title
      }
    })
    
    if (!existingActivity) {
      await prisma.activity.create({
        data: activity
      })
    }
  }

  console.log(`✅ ${activities.length} actividades de ejemplo creadas`)

  // Unlock some achievements for the test user
  const firstAchievement = await prisma.achievement.findFirst({
    where: { title: 'Primer Paso' }
  })

  const centurionAchievement = await prisma.achievement.findFirst({
    where: { title: 'Centurión' }
  })

  const gamerAchievement = await prisma.achievement.findFirst({
    where: { title: 'Gamer' }
  })

  const achievementsToUnlock = [firstAchievement, centurionAchievement, gamerAchievement].filter(Boolean)

  for (const achievement of achievementsToUnlock) {
    if (achievement) {
      const existingUserAchievement = await prisma.userAchievement.findFirst({
        where: {
          userId: testUser.id,
          achievementId: achievement.id
        }
      })
      
      if (!existingUserAchievement) {
        await prisma.userAchievement.create({
          data: {
            userId: testUser.id,
            achievementId: achievement.id,
            progress: 100
          }
        })
      }
    }
  }

  console.log(`✅ ${achievementsToUnlock.length} logros desbloqueados para el usuario de prueba`)

  console.log('🎉 Seeding completado exitosamente!')
}

main()
  .catch((e) => {
    console.error('❌ Error durante el seeding:', e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
