

import { PrismaClient } from '@prisma/client'
import * as dotenv from 'dotenv'

// Load environment variables
dotenv.config()

const prisma = new PrismaClient()

async function seedForum() {
  try {
    console.log('🌱 Seeding forum categories...')

    // Delete existing forum data to avoid duplicates
    await prisma.forumPost.deleteMany()
    await prisma.forumTopic.deleteMany()
    await prisma.forumCategory.deleteMany()

    // Create forum categories
    const categories = [
      {
        name: 'Programación General',
        description: 'Discusiones generales sobre programación, algoritmos y mejores prácticas',
        color: '#3B82F6',
        orderIndex: 1
      },
      {
        name: 'Python',
        description: 'Todo sobre Python: frameworks, librerías, proyectos y ayuda',
        color: '#10B981',
        orderIndex: 2
      },
      {
        name: 'C# y .NET',
        description: 'Desarrollo con C#, .NET Framework, .NET Core y tecnologías relacionadas',
        color: '#8B5CF6',
        orderIndex: 3
      },
      {
        name: 'C++',
        description: 'Programación en C++, optimización y desarrollo de sistemas',
        color: '#EF4444',
        orderIndex: 4
      },
      {
        name: 'Ayuda y Dudas',
        description: 'Pide ayuda con ejercicios, proyectos o conceptos que no entiendas',
        color: '#F59E0B',
        orderIndex: 5
      },
      {
        name: 'Proyectos y Portafolio',
        description: 'Comparte tus proyectos, obtén feedback y construye tu portafolio',
        color: '#06B6D4',
        orderIndex: 6
      },
      {
        name: 'Carrera y Trabajo',
        description: 'Consejos sobre entrevistas, carrera profesional y búsqueda de empleo',
        color: '#84CC16',
        orderIndex: 7
      },
      {
        name: 'Off-Topic',
        description: 'Conversaciones generales no relacionadas con programación',
        color: '#6B7280',
        orderIndex: 8
      }
    ]

    for (const category of categories) {
      await prisma.forumCategory.create({
        data: category
      })
    }

    console.log('✅ Forum categories seeded successfully!')
    console.log(`Created ${categories.length} forum categories`)

  } catch (error) {
    console.error('❌ Error seeding forum:', error)
  } finally {
    await prisma.$disconnect()
  }
}

if (require.main === module) {
  seedForum()
}

export { seedForum }
