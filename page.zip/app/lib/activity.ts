
import { prisma } from '@/lib/db'

export interface ActivityData {
  userId: string
  type: 'exercise_completed' | 'course_started' | 'achievement_unlocked' | 'game_played' | 'tool_used' | 'level_up'
  title: string
  description?: string
  metadata?: any
}

export async function createActivity(data: ActivityData) {
  try {
    const activity = await prisma.activity.create({
      data: {
        userId: data.userId,
        type: data.type,
        title: data.title,
        description: data.description,
        metadata: data.metadata || {}
      }
    })
    return activity
  } catch (error) {
    console.error('Error creating activity:', error)
    return null
  }
}

export async function getUserActivities(userId: string, limit: number = 10) {
  try {
    const activities = await prisma.activity.findMany({
      where: { userId },
      orderBy: { createdAt: 'desc' },
      take: limit
    })
    return activities
  } catch (error) {
    console.error('Error fetching user activities:', error)
    return []
  }
}
