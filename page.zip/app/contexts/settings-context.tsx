

'use client'

import React, { createContext, useContext, useEffect, useState } from 'react'
import { useSession } from 'next-auth/react'

interface UserSettings {
  theme: 'light' | 'dark' | 'system'
  language: 'es' | 'en' | 'pt'
  emailNotifications: boolean
  achievementNotifications: boolean
  practiceReminders: boolean
  profilePublic: boolean
  showInRanking: boolean
}

interface SettingsContextType {
  settings: UserSettings
  updateSettings: (newSettings: Partial<UserSettings>) => Promise<void>
  isLoading: boolean
  resetSettings: () => Promise<void>
}

const defaultSettings: UserSettings = {
  theme: 'dark',
  language: 'es',
  emailNotifications: true,
  achievementNotifications: true,
  practiceReminders: false,
  profilePublic: true,
  showInRanking: true
}

const SettingsContext = createContext<SettingsContextType | undefined>(undefined)

export function SettingsProvider({ children }: { children: React.ReactNode }) {
  const { data: session } = useSession()
  const [settings, setSettings] = useState<UserSettings>(defaultSettings)
  const [isLoading, setIsLoading] = useState(true)

  // Load settings from server or localStorage
  useEffect(() => {
    const loadSettings = async () => {
      if (session?.user) {
        try {
          const response = await fetch('/api/user/settings')
          if (response.ok) {
            const data = await response.json()
            setSettings({ ...defaultSettings, ...data.settings })
          }
        } catch (error) {
          console.error('Error loading settings:', error)
          // Load from localStorage as fallback
          const localSettings = localStorage.getItem('devtools-settings')
          if (localSettings) {
            try {
              const parsed = JSON.parse(localSettings)
              setSettings({ ...defaultSettings, ...parsed })
            } catch (error) {
              console.error('Error parsing local settings:', error)
            }
          }
        }
      } else {
        // Load from localStorage for non-authenticated users
        const localSettings = localStorage.getItem('devtools-settings')
        if (localSettings) {
          try {
            const parsed = JSON.parse(localSettings)
            setSettings({ ...defaultSettings, ...parsed })
          } catch (error) {
            console.error('Error parsing local settings:', error)
          }
        }
      }
      setIsLoading(false)
    }

    loadSettings()
  }, [session])

  // Apply theme changes to document
  useEffect(() => {
    const applyTheme = () => {
      const root = document.documentElement
      
      if (settings.theme === 'system') {
        const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches
        root.classList.toggle('dark', prefersDark)
      } else {
        root.classList.toggle('dark', settings.theme === 'dark')
      }
    }

    applyTheme()

    // Listen for system theme changes
    if (settings.theme === 'system') {
      const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)')
      mediaQuery.addEventListener('change', applyTheme)
      return () => mediaQuery.removeEventListener('change', applyTheme)
    }
  }, [settings.theme])

  // Apply language changes
  useEffect(() => {
    if (typeof document !== 'undefined') {
      document.documentElement.lang = settings.language
    }
  }, [settings.language])

  const updateSettings = async (newSettings: Partial<UserSettings>) => {
    const updatedSettings = { ...settings, ...newSettings }
    setSettings(updatedSettings)

    // Save to localStorage immediately
    localStorage.setItem('devtools-settings', JSON.stringify(updatedSettings))

    // Save to server if authenticated
    if (session?.user) {
      try {
        await fetch('/api/user/settings', {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(updatedSettings),
        })
      } catch (error) {
        console.error('Error saving settings:', error)
      }
    }
  }

  const resetSettings = async () => {
    setSettings(defaultSettings)
    localStorage.setItem('devtools-settings', JSON.stringify(defaultSettings))

    if (session?.user) {
      try {
        await fetch('/api/user/settings', {
          method: 'DELETE',
        })
      } catch (error) {
        console.error('Error resetting settings:', error)
      }
    }
  }

  return (
    <SettingsContext.Provider value={{ settings, updateSettings, isLoading, resetSettings }}>
      {children}
    </SettingsContext.Provider>
  )
}

export function useSettings() {
  const context = useContext(SettingsContext)
  if (context === undefined) {
    throw new Error('useSettings must be used within a SettingsProvider')
  }
  return context
}
