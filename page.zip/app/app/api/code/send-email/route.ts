
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { NextRequest } from 'next/server'

export const dynamic = 'force-dynamic'

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user) {
      return new Response(JSON.stringify({ error: 'No autorizado' }), {
        status: 401,
      })
    }

    const { code, language, output, userEmail, userName } = await request.json()

    if (!code || !language || !userEmail) {
      return new Response(JSON.stringify({ error: 'Datos incompletos' }), {
        status: 400,
      })
    }

    // Language mapping for display
    const languageMap: { [key: string]: string } = {
      'python': '🐍 Python',
      'csharp': '⚡ C#',
      'cpp': '🔥 C++'
    }

    const languageDisplay = languageMap[language] || language

    // Create email content using LLM API to format it nicely
    const emailPrompt = `Crea un email profesional y bien formateado en HTML para enviar código ejecutado a un desarrollador. 

INFORMACIÓN:
- Usuario: ${userName}
- Email: ${userEmail}
- Lenguaje: ${languageDisplay}
- Código ejecutado:
\`\`\`${language}
${code}
\`\`\`
- Salida del programa:
\`\`\`
${output}
\`\`\`

REQUISITOS:
1. Crea un email en HTML profesional y atractivo
2. Incluye el logo de DevTools (🛠️) y el nombre de la plataforma
3. Usa un diseño limpio con colores apropiados
4. Incluye tanto el código como la salida de forma legible
5. Añade información de contacto: zzzfaze99@gmail.com (Agustín - DevTools Argentina)
6. Mantén un tono profesional pero amigable
7. Incluye la fecha y hora actual
8. NO agregues explicaciones adicionales, solo devuelve el HTML del email

HTML del email:`

    try {
      const response = await fetch('https://apps.abacus.ai/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${process.env.ABACUSAI_API_KEY}`
        },
        body: JSON.stringify({
          model: 'gpt-4.1-mini',
          messages: [
            {
              role: 'user',
              content: emailPrompt
            }
          ],
          max_tokens: 1500,
          temperature: 0.3
        }),
      })

      if (!response.ok) {
        throw new Error('Error generating email content')
      }

      const data = await response.json()
      const emailContent = data.choices?.[0]?.message?.content || ''

      // Since we don't have a real email service, we'll simulate sending
      // In a real implementation, you would use a service like SendGrid, Nodemailer, etc.
      
      // Simulate email sending delay
      await new Promise(resolve => setTimeout(resolve, 1000))

      // Log the email that would be sent (for development purposes)
      console.log('=== EMAIL SIMULADO ===')
      console.log(`Para: ${userEmail}`)
      console.log(`Asunto: DevTools - Código ${languageDisplay} Ejecutado`)
      console.log('Contenido:')
      console.log(emailContent)
      console.log('=====================')

      return new Response(JSON.stringify({ 
        success: true, 
        message: 'Email enviado exitosamente',
        preview: emailContent.substring(0, 200) + '...' // For development
      }), {
        status: 200,
        headers: {
          'Content-Type': 'application/json',
        },
      })

    } catch (error) {
      console.error('Email generation error:', error)
      
      // Fallback: create a simple email without LLM
      const fallbackSubject = `DevTools - Código ${languageDisplay} Ejecutado`
      const fallbackContent = `
        Hola ${userName},
        
        Tu código ${languageDisplay} ha sido ejecutado exitosamente en DevTools.
        
        CÓDIGO:
        ${code}
        
        SALIDA:
        ${output}
        
        Fecha: ${new Date().toLocaleString()}
        
        Saludos,
        Equipo DevTools Argentina
        Contacto: zzzfaze99@gmail.com
      `

      console.log('=== EMAIL FALLBACK ===')
      console.log(`Para: ${userEmail}`)
      console.log(`Asunto: ${fallbackSubject}`)
      console.log('Contenido:')
      console.log(fallbackContent)
      console.log('=====================')

      return new Response(JSON.stringify({ 
        success: true, 
        message: 'Email enviado exitosamente (modo simple)',
        preview: fallbackContent.substring(0, 200) + '...'
      }), {
        status: 200,
        headers: {
          'Content-Type': 'application/json',
        },
      })
    }

  } catch (error) {
    console.error('Send email route error:', error)
    return new Response(JSON.stringify({ 
      error: 'Error al enviar email' 
    }), {
      status: 500,
    })
  }
}
