

import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'

export const dynamic = 'force-dynamic'

export async function GET() {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user) {
      return new Response(JSON.stringify({ error: 'Not authenticated' }), {
        status: 401,
      })
    }

    const preferences = await prisma.userPreferences.findUnique({
      where: { userId: session.user.id }
    })

    const settings = preferences ? {
      theme: preferences.theme,
      language: preferences.language,
      emailNotifications: preferences.emailNotifications,
      achievementNotifications: preferences.achievementNotifications,
      practiceReminders: preferences.practiceReminders,
      profilePublic: preferences.profilePublic,
      showInRanking: preferences.showInRanking
    } : null

    return new Response(JSON.stringify({
      settings
    }), {
      status: 200,
      headers: {
        'Content-Type': 'application/json',
      },
    })

  } catch (error) {
    console.error('Get settings API error:', error)
    return new Response(JSON.stringify({ 
      error: 'Internal server error' 
    }), {
      status: 500,
    })
  }
}

export async function PUT(request: Request) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user) {
      return new Response(JSON.stringify({ error: 'Not authenticated' }), {
        status: 401,
      })
    }

    const settings = await request.json()

    // Validate settings
    const validThemes = ['light', 'dark', 'system']
    const validLanguages = ['es', 'en', 'pt']

    if (settings.theme && !validThemes.includes(settings.theme)) {
      return new Response(JSON.stringify({ error: 'Invalid theme' }), {
        status: 400,
      })
    }

    if (settings.language && !validLanguages.includes(settings.language)) {
      return new Response(JSON.stringify({ error: 'Invalid language' }), {
        status: 400,
      })
    }

    // Upsert user preferences
    const preferences = await prisma.userPreferences.upsert({
      where: { userId: session.user.id },
      create: {
        userId: session.user.id,
        theme: settings.theme || 'dark',
        language: settings.language || 'es',
        emailNotifications: settings.emailNotifications ?? true,
        achievementNotifications: settings.achievementNotifications ?? true,
        practiceReminders: settings.practiceReminders ?? false,
        profilePublic: settings.profilePublic ?? true,
        showInRanking: settings.showInRanking ?? true
      },
      update: {
        theme: settings.theme,
        language: settings.language,
        emailNotifications: settings.emailNotifications,
        achievementNotifications: settings.achievementNotifications,
        practiceReminders: settings.practiceReminders,
        profilePublic: settings.profilePublic,
        showInRanking: settings.showInRanking
      }
    })

    return new Response(JSON.stringify({
      success: true,
      settings: {
        theme: preferences.theme,
        language: preferences.language,
        emailNotifications: preferences.emailNotifications,
        achievementNotifications: preferences.achievementNotifications,
        practiceReminders: preferences.practiceReminders,
        profilePublic: preferences.profilePublic,
        showInRanking: preferences.showInRanking
      }
    }), {
      status: 200,
      headers: {
        'Content-Type': 'application/json',
      },
    })

  } catch (error) {
    console.error('Update settings API error:', error)
    return new Response(JSON.stringify({ 
      error: 'Internal server error' 
    }), {
      status: 500,
    })
  }
}

export async function DELETE() {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user) {
      return new Response(JSON.stringify({ error: 'Not authenticated' }), {
        status: 401,
      })
    }

    await prisma.userPreferences.deleteMany({
      where: { userId: session.user.id }
    })

    return new Response(JSON.stringify({
      success: true
    }), {
      status: 200,
      headers: {
        'Content-Type': 'application/json',
      },
    })

  } catch (error) {
    console.error('Delete settings API error:', error)
    return new Response(JSON.stringify({ 
      error: 'Internal server error' 
    }), {
      status: 500,
    })
  }
}
