

import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'

export const dynamic = 'force-dynamic'

export async function GET() {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user) {
      return new Response(JSON.stringify({ error: 'Not authenticated' }), {
        status: 401,
      })
    }

    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
      include: {
        activities: {
          select: {
            createdAt: true
          },
          orderBy: {
            createdAt: 'desc'
          }
        }
      }
    })

    if (!user) {
      return new Response(JSON.stringify({ error: 'User not found' }), {
        status: 404,
      })
    }

    // Calculate days active based on unique activity days
    const uniqueDays = new Set()
    user.activities.forEach(activity => {
      const date = activity.createdAt.toISOString().split('T')[0]
      uniqueDays.add(date)
    })

    // Also count the join date as an active day
    const joinDate = user.joinedAt.toISOString().split('T')[0]
    uniqueDays.add(joinDate)

    const daysActive = uniqueDays.size

    return new Response(JSON.stringify({
      daysActive,
      joinedAt: user.joinedAt.toISOString(),
      lastActive: user.lastActive.toISOString()
    }), {
      status: 200,
      headers: {
        'Content-Type': 'application/json',
      },
    })

  } catch (error) {
    console.error('Profile stats API error:', error)
    return new Response(JSON.stringify({ 
      error: 'Internal server error' 
    }), {
      status: 500,
    })
  }
}
