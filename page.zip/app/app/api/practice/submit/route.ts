
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'
import { NextRequest } from 'next/server'

export const dynamic = 'force-dynamic'

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user) {
      return new Response(JSON.stringify({ error: 'No autorizado' }), {
        status: 401,
      })
    }

    const { exerciseId, code, language } = await request.json()

    if (!exerciseId || !code || !language) {
      return new Response(JSON.stringify({ error: 'Datos incompletos' }), {
        status: 400,
      })
    }

    // Get exercise details
    const exercise = await prisma.exercise.findUnique({
      where: { id: exerciseId }
    })

    if (!exercise) {
      return new Response(JSON.stringify({ error: 'Ejercicio no encontrado' }), {
        status: 404,
      })
    }

    if (exercise.language !== language) {
      return new Response(JSON.stringify({ error: 'Lenguaje incorrecto para este ejercicio' }), {
        status: 400,
      })
    }

    // Create initial submission record
    const submission = await prisma.submission.create({
      data: {
        userId: session.user.id,
        exerciseId,
        code,
        language,
        status: 'pending',
        score: 0
      }
    })

    // Evaluate the solution using LLM API
    const testCases = exercise.testCases as any[]
    const evaluationPrompt = `Evalúa la siguiente solución de programación en ${language.toUpperCase()}:

EJERCICIO: ${exercise.title}
DESCRIPCIÓN: ${exercise.description}

CÓDIGO DEL USUARIO:
\`\`\`${language}
${code}
\`\`\`

CASOS DE PRUEBA:
${testCases.map((testCase, index) => `
Caso ${index + 1}:
- Entrada: ${testCase.input || 'Sin entrada'}
- Salida esperada: ${testCase.expected}
`).join('')}

INSTRUCCIONES:
1. Ejecuta el código mentalmente con cada caso de prueba
2. Verifica si la salida coincide exactamente con lo esperado
3. Considera sintaxis, lógica y eficiencia
4. Asigna una puntuación de 0-100 basada en:
   - Casos de prueba pasados (70% del puntaje)
   - Calidad del código (20% del puntaje)
   - Eficiencia (10% del puntaje)

RESPONDE EN JSON con el siguiente formato:
{
  "passed": true/false,
  "score": 0-100,
  "testResults": [
    {"case": 1, "passed": true/false, "output": "salida real", "expected": "salida esperada"},
    ...
  ],
  "feedback": "Explicación detallada del resultado y sugerencias de mejora"
}

Evalúa cuidadosamente y proporciona feedback constructivo.`

    try {
      const response = await fetch('https://apps.abacus.ai/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${process.env.ABACUSAI_API_KEY}`
        },
        body: JSON.stringify({
          model: 'gpt-4.1-mini',
          messages: [
            {
              role: 'user',
              content: evaluationPrompt
            }
          ],
          response_format: { type: "json_object" },
          max_tokens: 2000,
          temperature: 0.1
        }),
      })

      if (!response.ok) {
        throw new Error('Error evaluating solution')
      }

      const data = await response.json()
      const evaluation = JSON.parse(data.choices?.[0]?.message?.content || '{}')

      // Update submission with results
      const updatedSubmission = await prisma.submission.update({
        where: { id: submission.id },
        data: {
          status: evaluation.passed ? 'passed' : 'failed',
          score: evaluation.score || 0,
          testResults: evaluation.testResults || [],
          executionTime: Date.now() - submission.submittedAt.getTime()
        }
      })

      // If passed, update user points and level
      if (evaluation.passed) {
        const pointsToAdd = Math.floor((evaluation.score / 100) * exercise.points)
        
        await prisma.user.update({
          where: { id: session.user.id },
          data: {
            totalPoints: {
              increment: pointsToAdd
            },
            practicePoints: {
              increment: pointsToAdd
            }
          }
        })

        // Update user level based on total points
        const updatedUser = await prisma.user.findUnique({
          where: { id: session.user.id },
          select: { totalPoints: true }
        })

        if (updatedUser) {
          const newLevel = Math.floor(updatedUser.totalPoints / 100) + 1
          await prisma.user.update({
            where: { id: session.user.id },
            data: { level: newLevel }
          })
        }
      }

      return new Response(JSON.stringify({
        success: true,
        submission: {
          id: updatedSubmission.id,
          status: updatedSubmission.status,
          score: updatedSubmission.score,
          passed: evaluation.passed,
          testResults: evaluation.testResults,
          feedback: evaluation.feedback,
          pointsEarned: evaluation.passed ? Math.floor((evaluation.score / 100) * exercise.points) : 0
        }
      }), {
        status: 200,
        headers: {
          'Content-Type': 'application/json',
        },
      })

    } catch (error) {
      console.error('Evaluation error:', error)
      
      // Update submission as error
      await prisma.submission.update({
        where: { id: submission.id },
        data: {
          status: 'error',
          score: 0
        }
      })

      return new Response(JSON.stringify({ 
        error: 'Error al evaluar la solución' 
      }), {
        status: 500,
      })
    }

  } catch (error) {
    console.error('Submit API error:', error)
    return new Response(JSON.stringify({ 
      error: 'Error interno del servidor' 
    }), {
      status: 500,
    })
  }
}
