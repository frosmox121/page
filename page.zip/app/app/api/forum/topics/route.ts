

import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'
import { NextRequest } from 'next/server'

export const dynamic = 'force-dynamic'

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user) {
      return new Response(JSON.stringify({ error: 'Not authenticated' }), {
        status: 401,
      })
    }

    const { searchParams } = new URL(request.url)
    const categoryId = searchParams.get('categoryId')
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '20')
    const offset = (page - 1) * limit

    const whereClause = categoryId ? { categoryId } : {}

    const topics = await prisma.forumTopic.findMany({
      where: whereClause,
      skip: offset,
      take: limit,
      orderBy: [
        { isPinned: 'desc' },
        { updatedAt: 'desc' }
      ],
      include: {
        category: {
          select: { name: true, color: true }
        },
        author: {
          select: { name: true, image: true }
        },
        posts: {
          take: 1,
          orderBy: { createdAt: 'desc' },
          include: {
            author: {
              select: { name: true, image: true }
            }
          }
        },
        _count: {
          select: { posts: true }
        }
      }
    })

    const totalTopics = await prisma.forumTopic.count({
      where: whereClause
    })

    return new Response(JSON.stringify({
      topics: topics.map(topic => ({
        id: topic.id,
        title: topic.title,
        content: topic.content.substring(0, 200) + (topic.content.length > 200 ? '...' : ''),
        category: topic.category,
        author: topic.author,
        isPinned: topic.isPinned,
        isLocked: topic.isLocked,
        viewCount: topic.viewCount,
        postCount: topic._count.posts,
        lastPost: topic.posts[0] ? {
          author: topic.posts[0].author,
          createdAt: topic.posts[0].createdAt.toISOString()
        } : null,
        createdAt: topic.createdAt.toISOString(),
        updatedAt: topic.updatedAt.toISOString()
      })),
      pagination: {
        page,
        limit,
        total: totalTopics,
        pages: Math.ceil(totalTopics / limit)
      }
    }), {
      status: 200,
      headers: {
        'Content-Type': 'application/json',
      },
    })

  } catch (error) {
    console.error('Forum topics API error:', error)
    return new Response(JSON.stringify({ 
      error: 'Internal server error' 
    }), {
      status: 500,
    })
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user) {
      return new Response(JSON.stringify({ error: 'Not authenticated' }), {
        status: 401,
      })
    }

    const { title, content, categoryId } = await request.json()

    if (!title || !content || !categoryId) {
      return new Response(JSON.stringify({ error: 'Missing required fields' }), {
        status: 400,
      })
    }

    // Anti-spam: Check if user has posted recently
    const recentTopic = await prisma.forumTopic.findFirst({
      where: {
        authorId: session.user.id,
        createdAt: {
          gte: new Date(Date.now() - 2 * 60 * 1000) // 2 minutes
        }
      }
    })

    if (recentTopic) {
      return new Response(JSON.stringify({ 
        error: 'Debes esperar 2 minutos entre publicaciones para evitar spam' 
      }), {
        status: 429,
      })
    }

    // Validate category exists
    const category = await prisma.forumCategory.findUnique({
      where: { id: categoryId, isActive: true }
    })

    if (!category) {
      return new Response(JSON.stringify({ error: 'Category not found' }), {
        status: 404,
      })
    }

    const topic = await prisma.forumTopic.create({
      data: {
        title,
        content,
        categoryId,
        authorId: session.user.id
      },
      include: {
        category: {
          select: { name: true, color: true }
        },
        author: {
          select: { name: true, image: true }
        }
      }
    })

    return new Response(JSON.stringify({
      topic: {
        id: topic.id,
        title: topic.title,
        content: topic.content,
        category: topic.category,
        author: topic.author,
        createdAt: topic.createdAt.toISOString()
      }
    }), {
      status: 201,
      headers: {
        'Content-Type': 'application/json',
      },
    })

  } catch (error) {
    console.error('Create topic API error:', error)
    return new Response(JSON.stringify({ 
      error: 'Internal server error' 
    }), {
      status: 500,
    })
  }
}
