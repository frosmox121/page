
import './globals.css'
import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import { ThemeProvider } from '@/components/theme-provider'
import { Toaster } from '@/components/ui/toaster'
import { SessionProvider } from '@/components/session-provider'
import { ClientNavigation } from '@/components/client-navigation'
import { ConsoleErrorSuppressor } from '@/components/console-error-suppressor'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'DevTools - Plataforma de Desarrollo Professional',
  description: 'Herramientas de desarrollo, práctica de programación y aprendizaje para desarrolladores',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="es" suppressHydrationWarning>
      <body className={inter.className}>
        <ConsoleErrorSuppressor />
        <ThemeProvider
          attribute="class"
          defaultTheme="dark"
          enableSystem
          disableTransitionOnChange
        >
          <SessionProvider>
            <ClientNavigation />
            {children}
            <Toaster />
          </SessionProvider>
        </ThemeProvider>
      </body>
    </html>
  )
}
