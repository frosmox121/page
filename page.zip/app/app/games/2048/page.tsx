

import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { redirect } from 'next/navigation'
import { Game2048 } from '@/components/games/2048-game'
import { Button } from '@/components/ui/button'
import { ArrowLeft } from 'lucide-react'
import Link from 'next/link'

export default async function Game2048Page() {
  const session = await getServerSession(authOptions)

  if (!session?.user) {
    redirect('/auth/login')
  }

  return (
    <div>
      <div className="container mx-auto px-4 py-4">
        <Button variant="outline" asChild>
          <Link href="/games">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Volver a Juegos
          </Link>
        </Button>
      </div>
      <Game2048 />
    </div>
  )
}
