
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { redirect } from 'next/navigation'
import Link from 'next/link'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { 
  Code2, 
  Globe, 
  Hash, 
  FileText, 
  Calculator, 
  Key, 
  Type,
  Percent,
  Mail,
  BarChart3,
  Calendar,
  Palette,
  QrCode,
  LinkIcon,
  Image
} from 'lucide-react'

export default async function ToolsPage() {
  const session = await getServerSession(authOptions)

  if (!session?.user) {
    redirect('/auth/login')
  }

  const tools = [
    {
      title: '💻 Ejecutor de Código',
      description: 'Ejecuta código Python, C# y C++ online',
      href: '/tools/code-runner',
      icon: Code2,
      color: 'bg-blue-500'
    },
    {
      title: '🌐 Analizador IP',
      description: 'Obtén información detallada de direcciones IP',
      href: '/tools/ip-analyzer', 
      icon: Globe,
      color: 'bg-green-500'
    },
    {
      title: '🔧 Generador Hash',
      description: 'Genera hashes MD5, SHA-1, SHA-256',
      href: '/tools/hash-generator',
      icon: Hash,
      color: 'bg-purple-500'
    },
    {
      title: '📝 Validador JSON',
      description: 'Valida y formatea documentos JSON',
      href: '/tools/json-validator',
      icon: FileText,
      color: 'bg-orange-500'
    },
    {
      title: '🔢 Conversor Bases',
      description: 'Convierte entre binario, decimal, hexadecimal',
      href: '/tools/base-converter',
      icon: Calculator,
      color: 'bg-red-500'
    },
    {
      title: '🔐 Generador Password',
      description: 'Genera contraseñas seguras',
      href: '/tools/password-generator',
      icon: Key,
      color: 'bg-pink-500'
    },
    {
      title: '🧮 Calculadora Científica',
      description: 'Calculadora avanzada con funciones científicas',
      href: '/tools/calculator',
      icon: Calculator,
      color: 'bg-indigo-500'
    },
    {
      title: '📝 Generador Lorem Ipsum',
      description: 'Genera texto de relleno para diseños y mockups',
      href: '/tools/lorem-generator',
      icon: Type,
      color: 'bg-slate-500'
    },
    {
      title: '📧 Validador de Emails',
      description: 'Valida formato y estructura de emails',
      href: '/tools/email-validator',
      icon: Mail,
      color: 'bg-cyan-500'
    },
    {
      title: '📊 Analizador de Texto',
      description: 'Analiza estadísticas y métricas de cualquier texto',
      href: '/tools/text-analyzer',
      icon: BarChart3,
      color: 'bg-emerald-500'
    },
    {
      title: '📅 Calculadora de Fechas',
      description: 'Calcula diferencias de fechas y operaciones temporales',
      href: '/tools/date-calculator',
      icon: Calendar,
      color: 'bg-amber-500'
    },
    {
      title: '🎨 Generador de Paletas',
      description: 'Crea paletas de colores armoniosas',
      href: '/tools/color-palette',
      icon: Palette,
      color: 'bg-rose-500'
    },
    {
      title: '📊 Calculadora de Porcentajes',
      description: 'Realiza cálculos de porcentajes de todo tipo',
      href: '/tools/percentage-calculator',
      icon: Percent,
      color: 'bg-lime-500'
    },
    {
      title: '🔧 Utilidades Varias',
      description: 'Herramientas adicionales y utilidades diversas',
      href: '/tools/utilities',
      icon: FileText,
      color: 'bg-teal-500'
    }
  ]

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold tracking-tight mb-4">
          🛠️ Herramientas de Desarrollo
        </h1>
        <p className="text-lg text-muted-foreground">
          Herramientas útiles para desarrolladores y estudiantes de informática
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {tools.map((tool, index) => (
          <Card key={tool.href} className="hover:shadow-lg transition-all duration-300">
            <CardHeader>
              <div className="flex items-center space-x-4">
                <div className={`h-12 w-12 rounded-lg ${tool.color} flex items-center justify-center`}>
                  <tool.icon className="h-6 w-6 text-white" />
                </div>
                <div>
                  <CardTitle className="text-xl">{tool.title}</CardTitle>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <CardDescription className="text-base leading-relaxed mb-4">
                {tool.description}
              </CardDescription>
              <Button asChild className="w-full">
                <Link href={tool.href}>
                  Usar Herramienta
                </Link>
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
