
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { redirect } from 'next/navigation'
import { PasswordGenerator } from '@/components/tools/password-generator'
import { Button } from '@/components/ui/button'
import { ArrowLeft } from 'lucide-react'
import Link from 'next/link'

export default async function PasswordGeneratorPage() {
  const session = await getServerSession(authOptions)

  if (!session?.user) {
    redirect('/auth/login')
  }

  return (
    <div>
      <div className="container mx-auto px-4 py-4">
        <Button variant="outline" asChild>
          <Link href="/tools">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Volver a Herramientas
          </Link>
        </Button>
      </div>
      <PasswordGenerator />
    </div>
  )
}
