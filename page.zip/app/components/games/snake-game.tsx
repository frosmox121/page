
'use client'

import { useState, useEffect, useCallback, useRef } from 'react'
import { useSession } from 'next-auth/react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { 
  Play, 
  Pause, 
  RotateCcw, 
  Trophy, 
  Star, 
  Crown,
  ArrowUp,
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  Gamepad2
} from 'lucide-react'
import { motion } from 'framer-motion'

interface Position {
  x: number
  y: number
}

interface GameState {
  snake: Position[]
  food: Position
  direction: string
  score: number
  level: number
  isPlaying: boolean
  isGameOver: boolean
  isPaused: boolean
}

interface HighScore {
  id: string
  score: number
  level: number
  userName: string
  playedAt: string
}

const GRID_SIZE = 20
const INITIAL_SNAKE = [{ x: 10, y: 10 }]
const INITIAL_FOOD = { x: 15, y: 15 }

export function SnakeGame() {
  const { data: session } = useSession()
  const gameAreaRef = useRef<HTMLDivElement>(null)
  const gameLoopRef = useRef<NodeJS.Timeout>()
  
  const [gameState, setGameState] = useState<GameState>({
    snake: INITIAL_SNAKE,
    food: INITIAL_FOOD,
    direction: 'RIGHT',
    score: 0,
    level: 1,
    isPlaying: false,
    isGameOver: false,
    isPaused: false
  })
  
  const [highScores, setHighScores] = useState<HighScore[]>([])
  const [personalBest, setPersonalBest] = useState(0)
  const [gameSpeed, setGameSpeed] = useState(200)

  // Generate random food position
  const generateFood = useCallback((): Position => {
    return {
      x: Math.floor(Math.random() * GRID_SIZE),
      y: Math.floor(Math.random() * GRID_SIZE)
    }
  }, [])

  // Check if position is occupied by snake
  const isPositionOccupied = useCallback((position: Position, snake: Position[]): boolean => {
    return snake.some(segment => segment.x === position.x && segment.y === position.y)
  }, [])

  // Move snake
  const moveSnake = useCallback(() => {
    setGameState(prevState => {
      if (!prevState.isPlaying || prevState.isPaused || prevState.isGameOver) {
        return prevState
      }

      const { snake, direction, food, score, level } = prevState
      const head = { ...snake[0] }

      // Update head position based on direction
      switch (direction) {
        case 'UP':
          head.y -= 1
          break
        case 'DOWN':
          head.y += 1
          break
        case 'LEFT':
          head.x -= 1
          break
        case 'RIGHT':
          head.x += 1
          break
        default:
          break
      }

      // Check wall collision
      if (head.x < 0 || head.x >= GRID_SIZE || head.y < 0 || head.y >= GRID_SIZE) {
        return {
          ...prevState,
          isGameOver: true,
          isPlaying: false
        }
      }

      // Check self collision
      if (isPositionOccupied(head, snake)) {
        return {
          ...prevState,
          isGameOver: true,
          isPlaying: false
        }
      }

      const newSnake = [head, ...snake]

      // Check food collision
      if (head.x === food.x && head.y === food.y) {
        const newScore = score + (level * 10)
        const newLevel = Math.floor(newScore / 100) + 1
        let newFood = generateFood()
        
        // Ensure food doesn't spawn on snake
        while (isPositionOccupied(newFood, newSnake)) {
          newFood = generateFood()
        }

        return {
          ...prevState,
          snake: newSnake,
          food: newFood,
          score: newScore,
          level: newLevel
        }
      } else {
        // Remove tail if no food eaten
        newSnake.pop()
      }

      return {
        ...prevState,
        snake: newSnake
      }
    })
  }, [generateFood, isPositionOccupied])

  // Handle keyboard input
  const handleKeyPress = useCallback((event: KeyboardEvent) => {
    setGameState(prevState => {
      if (!prevState.isPlaying) return prevState

      const { direction } = prevState
      let newDirection = direction

      switch (event.key) {
        case 'ArrowUp':
        case 'w':
        case 'W':
          if (direction !== 'DOWN') newDirection = 'UP'
          break
        case 'ArrowDown':
        case 's':
        case 'S':
          if (direction !== 'UP') newDirection = 'DOWN'
          break
        case 'ArrowLeft':
        case 'a':
        case 'A':
          if (direction !== 'RIGHT') newDirection = 'LEFT'
          break
        case 'ArrowRight':
        case 'd':
        case 'D':
          if (direction !== 'LEFT') newDirection = 'RIGHT'
          break
        case ' ':
          event.preventDefault()
          return {
            ...prevState,
            isPaused: !prevState.isPaused
          }
        default:
          return prevState
      }

      return {
        ...prevState,
        direction: newDirection
      }
    })
  }, [])

  // Start game
  const startGame = () => {
    setGameState({
      snake: INITIAL_SNAKE,
      food: generateFood(),
      direction: 'RIGHT',
      score: 0,
      level: 1,
      isPlaying: true,
      isGameOver: false,
      isPaused: false
    })
    setGameSpeed(200)
  }

  // Pause/Resume game
  const togglePause = () => {
    setGameState(prevState => ({
      ...prevState,
      isPaused: !prevState.isPaused
    }))
  }

  // Reset game
  const resetGame = () => {
    if (gameLoopRef.current) {
      clearInterval(gameLoopRef.current)
    }
    setGameState({
      snake: INITIAL_SNAKE,
      food: INITIAL_FOOD,
      direction: 'RIGHT',
      score: 0,
      level: 1,
      isPlaying: false,
      isGameOver: false,
      isPaused: false
    })
  }

  // Save high score
  const saveHighScore = async (score: number, level: number) => {
    if (!session?.user) return

    try {
      const response = await fetch('/api/games/save-score', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          gameType: 'snake',
          score,
          level
        }),
      })

      if (response.ok) {
        fetchHighScores()
      }
    } catch (error) {
      console.error('Error saving high score:', error)
    }
  }

  // Fetch high scores
  const fetchHighScores = async () => {
    try {
      const response = await fetch('/api/games/high-scores?gameType=snake')
      if (response.ok) {
        const data = await response.json()
        setHighScores(data.scores || [])
        setPersonalBest(data.personalBest || 0)
      }
    } catch (error) {
      console.error('Error fetching high scores:', error)
    }
  }

  // Game loop effect
  useEffect(() => {
    if (gameState.isPlaying && !gameState.isPaused && !gameState.isGameOver) {
      const newSpeed = Math.max(50, 200 - (gameState.level - 1) * 15)
      setGameSpeed(newSpeed)
      
      gameLoopRef.current = setInterval(moveSnake, newSpeed)
    } else {
      if (gameLoopRef.current) {
        clearInterval(gameLoopRef.current)
      }
    }

    return () => {
      if (gameLoopRef.current) {
        clearInterval(gameLoopRef.current)
      }
    }
  }, [gameState.isPlaying, gameState.isPaused, gameState.isGameOver, gameState.level, moveSnake])

  // Keyboard event listener
  useEffect(() => {
    document.addEventListener('keydown', handleKeyPress)
    return () => {
      document.removeEventListener('keydown', handleKeyPress)
    }
  }, [handleKeyPress])

  // Save high score when game ends
  useEffect(() => {
    if (gameState.isGameOver && gameState.score > 0) {
      saveHighScore(gameState.score, gameState.level)
    }
  }, [gameState.isGameOver, gameState.score, gameState.level])

  // Fetch high scores on mount
  useEffect(() => {
    fetchHighScores()
  }, [])

  // Focus game area for keyboard events
  useEffect(() => {
    if (gameAreaRef.current) {
      gameAreaRef.current.focus()
    }
  }, [gameState.isPlaying])

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <div className="h-16 w-16 rounded-2xl bg-green-500 flex items-center justify-center">
              <Gamepad2 className="h-8 w-8 text-white" />
            </div>
          </div>
          <h1 className="text-3xl font-bold tracking-tight mb-4">
            🐍 Snake Game
          </h1>
          <p className="text-lg text-muted-foreground">
            Controla la serpiente, come la comida y evita chocar con las paredes o contigo mismo
          </p>
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-4 gap-6">
          {/* Game Area */}
          <div className="xl:col-span-3">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <Gamepad2 className="h-5 w-5" />
                    Área de Juego
                  </CardTitle>
                  <div className="flex items-center gap-4">
                    <Badge variant="outline">
                      <Star className="mr-1 h-3 w-3" />
                      {gameState.score}
                    </Badge>
                    <Badge variant="outline">
                      Nivel {gameState.level}
                    </Badge>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {/* Game Controls */}
                  <div className="flex items-center gap-2">
                    {!gameState.isPlaying && !gameState.isGameOver && (
                      <Button onClick={startGame}>
                        <Play className="mr-2 h-4 w-4" />
                        Iniciar Juego
                      </Button>
                    )}
                    
                    {gameState.isPlaying && !gameState.isGameOver && (
                      <Button onClick={togglePause} variant="outline">
                        {gameState.isPaused ? (
                          <>
                            <Play className="mr-2 h-4 w-4" />
                            Reanudar
                          </>
                        ) : (
                          <>
                            <Pause className="mr-2 h-4 w-4" />
                            Pausar
                          </>
                        )}
                      </Button>
                    )}
                    
                    <Button onClick={resetGame} variant="outline">
                      <RotateCcw className="mr-2 h-4 w-4" />
                      Reiniciar
                    </Button>
                  </div>

                  {/* Game Board */}
                  <div 
                    ref={gameAreaRef}
                    className="relative bg-gray-900 rounded-lg border-2 border-gray-700 focus:outline-none"
                    style={{
                      width: `${GRID_SIZE * 20}px`,
                      height: `${GRID_SIZE * 20}px`,
                      margin: '0 auto'
                    }}
                    tabIndex={0}
                  >
                    {/* Snake */}
                    {gameState.snake.map((segment, index) => (
                      <div
                        key={index}
                        className={`absolute ${
                          index === 0 ? 'bg-green-400' : 'bg-green-500'
                        } rounded-sm`}
                        style={{
                          left: `${segment.x * 20}px`,
                          top: `${segment.y * 20}px`,
                          width: '18px',
                          height: '18px',
                          border: index === 0 ? '2px solid #10b981' : '1px solid #059669'
                        }}
                      />
                    ))}

                    {/* Food */}
                    <div
                      className="absolute bg-red-500 rounded-full animate-pulse"
                      style={{
                        left: `${gameState.food.x * 20 + 1}px`,
                        top: `${gameState.food.y * 20 + 1}px`,
                        width: '18px',
                        height: '18px'
                      }}
                    />

                    {/* Game Over Overlay */}
                    {gameState.isGameOver && (
                      <div className="absolute inset-0 bg-black/80 flex items-center justify-center rounded-lg">
                        <div className="text-center text-white">
                          <h3 className="text-2xl font-bold mb-2">¡Juego Terminado!</h3>
                          <p className="text-lg mb-2">Puntuación: {gameState.score}</p>
                          <p className="text-md mb-4">Nivel: {gameState.level}</p>
                          <Button onClick={startGame} className="bg-green-500 hover:bg-green-600">
                            <Play className="mr-2 h-4 w-4" />
                            Jugar de Nuevo
                          </Button>
                        </div>
                      </div>
                    )}

                    {/* Pause Overlay */}
                    {gameState.isPaused && (
                      <div className="absolute inset-0 bg-black/60 flex items-center justify-center rounded-lg">
                        <div className="text-center text-white">
                          <Pause className="h-12 w-12 mx-auto mb-4" />
                          <h3 className="text-xl font-bold">Juego Pausado</h3>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Game Info */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                    <div className="p-3 bg-muted rounded-lg">
                      <div className="text-2xl font-bold text-green-500">{gameState.score}</div>
                      <div className="text-sm text-muted-foreground">Puntuación</div>
                    </div>
                    <div className="p-3 bg-muted rounded-lg">
                      <div className="text-2xl font-bold text-blue-500">{gameState.level}</div>
                      <div className="text-sm text-muted-foreground">Nivel</div>
                    </div>
                    <div className="p-3 bg-muted rounded-lg">
                      <div className="text-2xl font-bold text-purple-500">{gameState.snake.length}</div>
                      <div className="text-sm text-muted-foreground">Longitud</div>
                    </div>
                    <div className="p-3 bg-muted rounded-lg">
                      <div className="text-2xl font-bold text-yellow-500">{Math.round(1000/gameSpeed)}</div>
                      <div className="text-sm text-muted-foreground">Velocidad</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Controls */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Gamepad2 className="h-5 w-5" />
                  Controles
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="text-center">
                    <Button variant="outline" size="sm" className="p-2">
                      <ArrowUp className="h-4 w-4" />
                    </Button>
                    <div className="text-xs mt-1">↑ / W</div>
                  </div>
                  <div className="flex justify-center gap-2">
                    <div className="text-center">
                      <Button variant="outline" size="sm" className="p-2">
                        <ArrowLeft className="h-4 w-4" />
                      </Button>
                      <div className="text-xs mt-1">← / A</div>
                    </div>
                    <div className="text-center">
                      <Button variant="outline" size="sm" className="p-2">
                        <ArrowDown className="h-4 w-4" />
                      </Button>
                      <div className="text-xs mt-1">↓ / S</div>
                    </div>
                    <div className="text-center">
                      <Button variant="outline" size="sm" className="p-2">
                        <ArrowRight className="h-4 w-4" />
                      </Button>
                      <div className="text-xs mt-1">→ / D</div>
                    </div>
                  </div>
                  <div className="text-center">
                    <Button variant="outline" size="sm">
                      Espacio
                    </Button>
                    <div className="text-xs mt-1">Pausa</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Personal Best */}
            {personalBest > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Crown className="h-5 w-5 text-yellow-500" />
                    Tu Mejor Puntuación
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-yellow-500">{personalBest}</div>
                    <div className="text-sm text-muted-foreground">Puntos</div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* High Scores */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Trophy className="h-5 w-5" />
                  Ranking Global
                </CardTitle>
                <CardDescription>
                  Top 10 mejores puntuaciones
                </CardDescription>
              </CardHeader>
              <CardContent>
                {highScores.length === 0 ? (
                  <div className="text-center py-4 text-muted-foreground">
                    No hay puntuaciones aún
                  </div>
                ) : (
                  <div className="space-y-2">
                    {highScores.slice(0, 10).map((score, index) => (
                      <div key={score.id} className="flex items-center justify-between p-2 bg-muted rounded">
                        <div className="flex items-center gap-2">
                          <Badge variant={index < 3 ? 'default' : 'outline'} className="w-6 h-6 p-0 flex items-center justify-center text-xs">
                            {index + 1}
                          </Badge>
                          <span className="font-medium text-sm truncate max-w-[100px]">
                            {score.userName}
                          </span>
                        </div>
                        <div className="text-right">
                          <div className="font-semibold text-sm">{score.score}</div>
                          <div className="text-xs text-muted-foreground">Nv.{score.level}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Game Tips */}
            <Card>
              <CardHeader>
                <CardTitle>Consejos</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 text-sm text-muted-foreground">
                  <p>🎯 Come la comida roja para crecer</p>
                  <p>⚡ La velocidad aumenta con el nivel</p>
                  <p>🚫 Evita chocar con las paredes</p>
                  <p>🐍 No te muerdas la cola</p>
                  <p>⏸️ Usa Espacio para pausar</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </motion.div>
    </div>
  )
}
