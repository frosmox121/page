
'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { 
  Gamepad2, 
  Trophy, 
  Star, 
  Play,
  TrendingUp,
  Clock,
  Award,
  Crown
} from 'lucide-react'
import { motion } from 'framer-motion'
import Link from 'next/link'

interface GameStats {
  gameType: string
  highScore: number
  totalPlays: number
  averageScore: number
  lastPlayed?: string
}

export function GamesDashboard() {
  const { data: session } = useSession()
  const [gameStats, setGameStats] = useState<GameStats[]>([])
  const [isLoading, setIsLoading] = useState(true)

  const games = [
    {
      id: 'snake',
      name: 'Snake',
      emoji: '🐍',
      description: 'Clásico juego de la serpiente. Come, crece y evita chocar.',
      href: '/games/snake',
      color: 'bg-green-500',
      difficulty: 'Fácil'
    },
    {
      id: 'tetris',
      name: 'Tetris',
      emoji: '🧩',
      description: 'Apila los bloques y forma líneas completas.',
      href: '/games/tetris',
      color: 'bg-blue-500',
      difficulty: 'Medio'
    },
    {
      id: 'pong',
      name: 'Pong',
      emoji: '🏓',
      description: 'El clásico juego de ping pong arcade.',
      href: '/games/pong',
      color: 'bg-purple-500',
      difficulty: 'Fácil'
    },
    {
      id: 'memory',
      name: 'Memory',
      emoji: '🧠',
      description: 'Encuentra las parejas de cartas y ejercita tu memoria.',
      href: '/games/memory',
      color: 'bg-pink-500',
      difficulty: 'Fácil'
    },
    {
      id: '2048',
      name: '2048',
      emoji: '🎯',
      description: 'Combina números hasta llegar a 2048. ¡Muy adictivo!',
      href: '/games/2048',
      color: 'bg-orange-500',
      difficulty: 'Difícil'
    }
  ]

  useEffect(() => {
    fetchGameStats()
  }, [])

  const fetchGameStats = async () => {
    try {
      setIsLoading(true)
      
      // Fetch real game statistics for each game type
      const gameTypes = ['snake', 'tetris', 'pong', 'memory', '2048']
      const realStats: GameStats[] = []
      
      for (const gameType of gameTypes) {
        try {
          const response = await fetch(`/api/games/user-stats?gameType=${gameType}`)
          if (response.ok) {
            const data = await response.json()
            realStats.push({
              gameType,
              highScore: data.highScore || 0,
              totalPlays: data.totalPlays || 0,
              averageScore: data.averageScore || 0,
              lastPlayed: data.lastPlayed || undefined
            })
          } else {
            // If no stats exist for this game, add default values
            realStats.push({
              gameType,
              highScore: 0,
              totalPlays: 0,
              averageScore: 0,
              lastPlayed: undefined
            })
          }
        } catch (error) {
          console.error(`Error fetching ${gameType} stats:`, error)
          // Add default values on error
          realStats.push({
            gameType,
            highScore: 0,
            totalPlays: 0,
            averageScore: 0,
            lastPlayed: undefined
          })
        }
      }
      
      setGameStats(realStats)
    } catch (error) {
      console.error('Error fetching game stats:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const getGameStats = (gameId: string) => {
    return gameStats.find(stat => stat.gameType === gameId)
  }

  const getTotalHighScore = () => {
    return gameStats.reduce((total, stat) => total + stat.highScore, 0)
  }

  const getTotalPlays = () => {
    return gameStats.reduce((total, stat) => total + stat.totalPlays, 0)
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <div className="h-16 w-16 rounded-2xl bg-purple-500 flex items-center justify-center">
              <Gamepad2 className="h-8 w-8 text-white" />
            </div>
          </div>
          <h1 className="text-3xl font-bold tracking-tight mb-4">
            🎮 Juegos Arcade
          </h1>
          <p className="text-lg text-muted-foreground">
            Diviértete con nuestros juegos clásicos arcade y compite por el mejor puntaje
          </p>
        </div>

        {/* User Gaming Stats */}
        {!isLoading && gameStats.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1, duration: 0.6 }}
            className="mb-8"
          >
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Card>
                <CardContent className="p-6 text-center">
                  <div className="flex items-center justify-center mb-2">
                    <Trophy className="h-6 w-6 text-yellow-500" />
                  </div>
                  <div className="text-2xl font-bold">{getTotalHighScore()}</div>
                  <div className="text-sm text-muted-foreground">Puntuación Total</div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6 text-center">
                  <div className="flex items-center justify-center mb-2">
                    <Play className="h-6 w-6 text-blue-500" />
                  </div>
                  <div className="text-2xl font-bold">{getTotalPlays()}</div>
                  <div className="text-sm text-muted-foreground">Partidas Jugadas</div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6 text-center">
                  <div className="flex items-center justify-center mb-2">
                    <Star className="h-6 w-6 text-green-500" />
                  </div>
                  <div className="text-2xl font-bold">{games.length}</div>
                  <div className="text-sm text-muted-foreground">Juegos Disponibles</div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6 text-center">
                  <div className="flex items-center justify-center mb-2">
                    <Crown className="h-6 w-6 text-purple-500" />
                  </div>
                  <div className="text-2xl font-bold">
                    {Math.round(gameStats.reduce((total, stat) => total + stat.averageScore, 0) / gameStats.length) || 0}
                  </div>
                  <div className="text-sm text-muted-foreground">Promedio General</div>
                </CardContent>
              </Card>
            </div>
          </motion.div>
        )}

        {/* Games Grid */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2, duration: 0.6 }}
        >
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {games.map((game, index) => {
              const stats = getGameStats(game.id)
              return (
                <motion.div
                  key={game.id}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.1, duration: 0.4 }}
                  whileHover={{ y: -5, transition: { duration: 0.2 } }}
                >
                  <Card className="h-full hover:shadow-xl transition-all duration-300 cursor-pointer group">
                    <CardHeader>
                      <div className="flex items-center space-x-4">
                        <div className={`h-16 w-16 rounded-2xl ${game.color} flex items-center justify-center group-hover:scale-110 transition-transform duration-300`}>
                          <span className="text-2xl">{game.emoji}</span>
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <CardTitle className="text-xl">{game.name}</CardTitle>
                            <Badge variant="outline" className="text-xs">
                              {game.difficulty}
                            </Badge>
                          </div>
                          <CardDescription className="text-sm">
                            {game.description}
                          </CardDescription>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      {stats && (
                        <div className="grid grid-cols-2 gap-4 mb-4">
                          <div className="text-center p-2 bg-muted rounded-lg">
                            <div className="font-semibold text-lg">{stats.highScore}</div>
                            <div className="text-xs text-muted-foreground">Mejor Puntuación</div>
                          </div>
                          <div className="text-center p-2 bg-muted rounded-lg">
                            <div className="font-semibold text-lg">{stats.totalPlays}</div>
                            <div className="text-xs text-muted-foreground">Partidas</div>
                          </div>
                        </div>
                      )}
                      
                      <Button asChild className="w-full">
                        <Link href={game.href}>
                          <Play className="mr-2 h-4 w-4" />
                          Jugar Ahora
                        </Link>
                      </Button>
                      
                      {stats?.lastPlayed && (
                        <div className="flex items-center gap-1 mt-3 text-xs text-muted-foreground">
                          <Clock className="h-3 w-3" />
                          Último juego: {new Date(stats.lastPlayed).toLocaleDateString()}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </motion.div>
              )
            })}
          </div>
        </motion.div>

        {/* Coming Soon Games */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.6 }}
          className="mt-12"
        >
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5" />
                Próximamente
              </CardTitle>
              <CardDescription>
                Más juegos emocionantes llegarán pronto
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="text-center p-4 bg-muted/50 rounded-lg">
                  <div className="text-2xl mb-2">🚀</div>
                  <div className="font-medium">Asteroids</div>
                  <div className="text-xs text-muted-foreground">Arcade Clásico</div>
                </div>
                <div className="text-center p-4 bg-muted/50 rounded-lg">
                  <div className="text-2xl mb-2">👾</div>
                  <div className="font-medium">Space Invaders</div>
                  <div className="text-xs text-muted-foreground">Shoot 'em up</div>
                </div>
                <div className="text-center p-4 bg-muted/50 rounded-lg">
                  <div className="text-2xl mb-2">🕹️</div>
                  <div className="font-medium">Pac-Man</div>
                  <div className="text-xs text-muted-foreground">Laberinto</div>
                </div>
                <div className="text-center p-4 bg-muted/50 rounded-lg">
                  <div className="text-2xl mb-2">🎯</div>
                  <div className="font-medium">Breakout</div>
                  <div className="text-xs text-muted-foreground">Arcade</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </motion.div>
    </div>
  )
}
