
'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Copy, Calculator, Check, AlertCircle, RefreshCw } from 'lucide-react'
import { motion } from 'framer-motion'

interface BaseSystem {
  name: string
  base: number
  prefix: string
  description: string
  pattern: RegExp
  color: string
  example: string
}

export function BaseConverter() {
  const [input, setInput] = useState('')
  const [inputBase, setInputBase] = useState('10')
  const [results, setResults] = useState({
    binary: '',
    octal: '',
    decimal: '',
    hexadecimal: ''
  })
  const [error, setError] = useState('')
  const [copiedField, setCopiedField] = useState<string | null>(null)

  const baseSystems: BaseSystem[] = [
    {
      name: 'Binario',
      base: 2,
      prefix: '0b',
      description: 'Base 2 (0-1)',
      pattern: /^[01]+$/,
      color: 'bg-blue-500',
      example: '1010'
    },
    {
      name: 'Octal',
      base: 8,
      prefix: '0o',
      description: 'Base 8 (0-7)',
      pattern: /^[0-7]+$/,
      color: 'bg-green-500',
      example: '755'
    },
    {
      name: 'Decimal',
      base: 10,
      prefix: '',
      description: 'Base 10 (0-9)',
      pattern: /^[0-9]+$/,
      color: 'bg-orange-500',
      example: '123'
    },
    {
      name: 'Hexadecimal',
      base: 16,
      prefix: '0x',
      description: 'Base 16 (0-9, A-F)',
      pattern: /^[0-9A-Fa-f]+$/,
      color: 'bg-purple-500',
      example: 'FF'
    }
  ]

  const validateInput = (value: string, base: string): boolean => {
    if (!value.trim()) return true
    
    const baseSystem = baseSystems.find(b => b.base.toString() === base)
    if (!baseSystem) return false
    
    // Remove prefix if present
    let cleanValue = value.trim().toUpperCase()
    if (baseSystem.base === 2 && cleanValue.startsWith('0B')) {
      cleanValue = cleanValue.slice(2)
    } else if (baseSystem.base === 8 && cleanValue.startsWith('0O')) {
      cleanValue = cleanValue.slice(2)
    } else if (baseSystem.base === 16 && cleanValue.startsWith('0X')) {
      cleanValue = cleanValue.slice(2)
    }
    
    return baseSystem.pattern.test(cleanValue)
  }

  const convertNumber = (value: string, fromBase: string) => {
    if (!value.trim()) {
      setResults({
        binary: '',
        octal: '',
        decimal: '',
        hexadecimal: ''
      })
      setError('')
      return
    }

    if (!validateInput(value, fromBase)) {
      setError(`Entrada inválida para base ${fromBase}`)
      setResults({
        binary: '',
        octal: '',
        decimal: '',
        hexadecimal: ''
      })
      return
    }

    try {
      // Clean the input
      let cleanValue = value.trim().toUpperCase()
      const baseSystem = baseSystems.find(b => b.base.toString() === fromBase)
      
      if (baseSystem?.base === 2 && cleanValue.startsWith('0B')) {
        cleanValue = cleanValue.slice(2)
      } else if (baseSystem?.base === 8 && cleanValue.startsWith('0O')) {
        cleanValue = cleanValue.slice(2)
      } else if (baseSystem?.base === 16 && cleanValue.startsWith('0X')) {
        cleanValue = cleanValue.slice(2)
      }

      // Convert to decimal first
      const decimalValue = parseInt(cleanValue, parseInt(fromBase))
      
      if (isNaN(decimalValue) || decimalValue < 0) {
        throw new Error('Número inválido')
      }

      // Convert to all bases
      setResults({
        binary: decimalValue.toString(2),
        octal: decimalValue.toString(8),
        decimal: decimalValue.toString(10),
        hexadecimal: decimalValue.toString(16).toUpperCase()
      })
      setError('')
    } catch (err) {
      setError('Error en la conversión: número fuera de rango o inválido')
      setResults({
        binary: '',
        octal: '',
        decimal: '',
        hexadecimal: ''
      })
    }
  }

  useEffect(() => {
    convertNumber(input, inputBase)
  }, [input, inputBase])

  const copyToClipboard = async (text: string, field: string) => {
    try {
      await navigator.clipboard.writeText(text)
      setCopiedField(field)
      setTimeout(() => setCopiedField(null), 2000)
    } catch (err) {
      console.error('Failed to copy text: ', err)
    }
  }

  const clearAll = () => {
    setInput('')
    setInputBase('10')
    setResults({
      binary: '',
      octal: '',
      decimal: '',
      hexadecimal: ''
    })
    setError('')
  }

  const loadExample = () => {
    const examples = {
      '2': '1010110',
      '8': '127',
      '10': '255',
      '16': 'FF'
    }
    setInput(examples[inputBase as keyof typeof examples] || '42')
  }

  const getAdditionalInfo = () => {
    if (!results.decimal) return null
    
    const decimalValue = parseInt(results.decimal)
    const bitLength = decimalValue.toString(2).length
    const byteLength = Math.ceil(bitLength / 8)
    
    return {
      bitLength,
      byteLength,
      isSigned: decimalValue >= 0,
      maxValue8bit: 255,
      maxValue16bit: 65535,
      maxValue32bit: 4294967295
    }
  }

  const additionalInfo = getAdditionalInfo()

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <div className="h-16 w-16 rounded-2xl bg-red-500 flex items-center justify-center">
              <Calculator className="h-8 w-8 text-white" />
            </div>
          </div>
          <h1 className="text-3xl font-bold tracking-tight mb-4">
            🔢 Conversor de Bases
          </h1>
          <p className="text-lg text-muted-foreground">
            Convierte números entre binario, octal, decimal y hexadecimal
          </p>
        </div>

        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calculator className="h-5 w-5" />
              Número de Entrada
            </CardTitle>
            <CardDescription>
              Ingresa un número en cualquier base para convertirlo
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="input">Número</Label>
                <Input
                  id="input"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="Ingresa un número..."
                  className="font-mono"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="base">Base de Entrada</Label>
                <Select value={inputBase} onValueChange={setInputBase}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecciona una base" />
                  </SelectTrigger>
                  <SelectContent>
                    {baseSystems.map((base) => (
                      <SelectItem key={base.base} value={base.base.toString()}>
                        {base.name} (Base {base.base})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="flex gap-2">
              <Button onClick={loadExample} variant="outline" size="sm">
                <RefreshCw className="mr-2 h-4 w-4" />
                Ejemplo
              </Button>
              <Button onClick={clearAll} variant="outline" size="sm">
                Limpiar
              </Button>
            </div>

            {error && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>

        {Object.values(results).some(result => result) && !error && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              {baseSystems.map((baseSystem, index) => (
                <motion.div
                  key={baseSystem.base}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.1, duration: 0.3 }}
                >
                  <Card className="h-full hover:shadow-lg transition-all duration-300">
                    <CardHeader>
                      <div className="flex items-center space-x-4">
                        <div className={`h-12 w-12 rounded-lg ${baseSystem.color} flex items-center justify-center`}>
                          <Calculator className="h-6 w-6 text-white" />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <CardTitle className="text-lg">{baseSystem.name}</CardTitle>
                            <Badge variant="secondary" className="text-xs">
                              Base {baseSystem.base}
                            </Badge>
                          </div>
                          <CardDescription className="text-sm">
                            {baseSystem.description}
                          </CardDescription>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div className="relative">
                          <div className="p-3 bg-muted rounded-lg font-mono text-lg break-all">
                            {baseSystem.prefix}{results[baseSystem.name.toLowerCase() as keyof typeof results]}
                          </div>
                          <Button
                            size="sm"
                            variant="ghost"
                            className="absolute top-2 right-2"
                            onClick={() => copyToClipboard(
                              baseSystem.prefix + results[baseSystem.name.toLowerCase() as keyof typeof results], 
                              baseSystem.name.toLowerCase()
                            )}
                          >
                            {copiedField === baseSystem.name.toLowerCase() ? (
                              <Check className="h-4 w-4 text-green-500" />
                            ) : (
                              <Copy className="h-4 w-4" />
                            )}
                          </Button>
                        </div>
                        
                        <div className="text-sm text-muted-foreground">
                          Ejemplo: {baseSystem.prefix}{baseSystem.example}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>

            {additionalInfo && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4, duration: 0.4 }}
              >
                <Card>
                  <CardHeader>
                    <CardTitle>Información Adicional</CardTitle>
                    <CardDescription>
                      Detalles sobre el número convertido
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div className="text-center p-3 bg-muted rounded-lg">
                        <div className="font-semibold text-lg">{additionalInfo.bitLength}</div>
                        <div className="text-sm text-muted-foreground">Bits requeridos</div>
                      </div>
                      <div className="text-center p-3 bg-muted rounded-lg">
                        <div className="font-semibold text-lg">{additionalInfo.byteLength}</div>
                        <div className="text-sm text-muted-foreground">Bytes requeridos</div>
                      </div>
                      <div className="text-center p-3 bg-muted rounded-lg">
                        <div className="font-semibold text-lg">
                          {parseInt(results.decimal) <= additionalInfo.maxValue8bit ? '8' : 
                           parseInt(results.decimal) <= additionalInfo.maxValue16bit ? '16' : '32+'}
                        </div>
                        <div className="text-sm text-muted-foreground">Bits mínimos</div>
                      </div>
                      <div className="text-center p-3 bg-muted rounded-lg">
                        <div className="font-semibold text-lg">
                          {additionalInfo.isSigned ? 'Positivo' : 'Negativo'}
                        </div>
                        <div className="text-sm text-muted-foreground">Signo</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            )}
          </motion.div>
        )}

        <Alert className="mt-6">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            <strong>Consejo:</strong> Puedes usar prefijos como 0b (binario), 0o (octal), o 0x (hexadecimal) 
            en tu entrada. El conversor los reconocerá automáticamente.
          </AlertDescription>
        </Alert>
      </motion.div>
    </div>
  )
}
