
'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Checkbox } from '@/components/ui/checkbox'
import { Slider } from '@/components/ui/slider'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Copy, Key, Check, RefreshCw, Shield, AlertTriangle } from 'lucide-react'
import { motion } from 'framer-motion'

interface PasswordOptions {
  length: number
  includeUppercase: boolean
  includeLowercase: boolean
  includeNumbers: boolean
  includeSymbols: boolean
  excludeSimilar: boolean
}

interface PasswordStrength {
  score: number
  label: string
  color: string
  description: string
}

export function PasswordGenerator() {
  const [passwords, setPasswords] = useState<string[]>([])
  const [options, setOptions] = useState<PasswordOptions>({
    length: 16,
    includeUppercase: true,
    includeLowercase: true,
    includeNumbers: true,
    includeSymbols: true,
    excludeSimilar: false
  })
  const [passwordCount, setPasswordCount] = useState(5)
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null)
  const [strengthAnalysis, setStrengthAnalysis] = useState<PasswordStrength | null>(null)

  const characterSets = {
    uppercase: 'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
    lowercase: 'abcdefghijklmnopqrstuvwxyz',
    numbers: '0123456789',
    symbols: '!@#$%^&*()_+-=[]{}|;:,.<>?',
    similarChars: '0O1lI|'
  }

  const generatePassword = (): string => {
    let charset = ''
    
    if (options.includeUppercase) charset += characterSets.uppercase
    if (options.includeLowercase) charset += characterSets.lowercase
    if (options.includeNumbers) charset += characterSets.numbers
    if (options.includeSymbols) charset += characterSets.symbols
    
    if (options.excludeSimilar) {
      for (const char of characterSets.similarChars) {
        charset = charset.replace(new RegExp(char, 'g'), '')
      }
    }
    
    if (!charset) return ''
    
    let password = ''
    for (let i = 0; i < options.length; i++) {
      const randomIndex = Math.floor(Math.random() * charset.length)
      password += charset[randomIndex]
    }
    
    return password
  }

  const calculatePasswordStrength = (password: string): PasswordStrength => {
    let score = 0
    let feedback = []
    
    // Length scoring
    if (password.length >= 12) score += 25
    else if (password.length >= 8) score += 15
    else if (password.length >= 6) score += 10
    else score += 5
    
    // Character variety scoring
    if (/[a-z]/.test(password)) score += 15
    if (/[A-Z]/.test(password)) score += 15
    if (/[0-9]/.test(password)) score += 15
    if (/[^A-Za-z0-9]/.test(password)) score += 20
    
    // Bonus points for good practices
    if (password.length >= 16) score += 10
    if (/(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[^A-Za-z0-9])/.test(password)) score += 10
    
    // Determine strength level
    if (score >= 80) {
      return {
        score,
        label: 'Muy Fuerte',
        color: 'text-green-500',
        description: 'Excelente seguridad. Esta contraseña es muy difícil de descifrar.'
      }
    } else if (score >= 60) {
      return {
        score,
        label: 'Fuerte',
        color: 'text-blue-500',
        description: 'Buena seguridad. Esta contraseña ofrece una protección sólida.'
      }
    } else if (score >= 40) {
      return {
        score,
        label: 'Moderada',
        color: 'text-yellow-500',
        description: 'Seguridad aceptable. Considera aumentar la longitud o complejidad.'
      }
    } else if (score >= 20) {
      return {
        score,
        label: 'Débil',
        color: 'text-orange-500',
        description: 'Seguridad baja. Esta contraseña es vulnerable a ataques.'
      }
    } else {
      return {
        score,
        label: 'Muy Débil',
        color: 'text-red-500',
        description: 'Seguridad muy baja. Esta contraseña es fácil de descifrar.'
      }
    }
  }

  const generatePasswords = () => {
    if (!options.includeUppercase && !options.includeLowercase && 
        !options.includeNumbers && !options.includeSymbols) {
      return
    }

    const newPasswords = []
    for (let i = 0; i < passwordCount; i++) {
      newPasswords.push(generatePassword())
    }
    setPasswords(newPasswords)
    
    // Analyze strength of first password
    if (newPasswords[0]) {
      setStrengthAnalysis(calculatePasswordStrength(newPasswords[0]))
    }
  }

  const copyToClipboard = async (password: string, index: number) => {
    try {
      await navigator.clipboard.writeText(password)
      setCopiedIndex(index)
      setTimeout(() => setCopiedIndex(null), 2000)
    } catch (err) {
      console.error('Failed to copy password: ', err)
    }
  }

  const updateOptions = (key: keyof PasswordOptions, value: any) => {
    setOptions(prev => ({ ...prev, [key]: value }))
  }

  const getTimeToCrack = (password: string): string => {
    const charset = password.length
    let possibleChars = 0
    
    if (/[a-z]/.test(password)) possibleChars += 26
    if (/[A-Z]/.test(password)) possibleChars += 26
    if (/[0-9]/.test(password)) possibleChars += 10
    if (/[^A-Za-z0-9]/.test(password)) possibleChars += 32
    
    const possibilities = Math.pow(possibleChars, password.length)
    const seconds = possibilities / (2 * 1000000000) // Assuming 1 billion guesses per second
    
    if (seconds < 60) return 'Menos de 1 minuto'
    if (seconds < 3600) return `${Math.round(seconds / 60)} minutos`
    if (seconds < 86400) return `${Math.round(seconds / 3600)} horas`
    if (seconds < 31536000) return `${Math.round(seconds / 86400)} días`
    if (seconds < 31536000000) return `${Math.round(seconds / 31536000)} años`
    return 'Más de 1000 años'
  }

  useEffect(() => {
    generatePasswords()
  }, [options, passwordCount])

  const hasValidOptions = options.includeUppercase || options.includeLowercase || 
                         options.includeNumbers || options.includeSymbols

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <div className="h-16 w-16 rounded-2xl bg-pink-500 flex items-center justify-center">
              <Key className="h-8 w-8 text-white" />
            </div>
          </div>
          <h1 className="text-3xl font-bold tracking-tight mb-4">
            🔐 Generador de Contraseñas
          </h1>
          <p className="text-lg text-muted-foreground">
            Genera contraseñas seguras y personalizables con análisis de fortaleza
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Configuration Panel */}
          <Card className="lg:col-span-1">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5" />
                Configuración
              </CardTitle>
              <CardDescription>
                Personaliza las opciones de tu contraseña
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Password Length */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <Label>Longitud</Label>
                  <Badge variant="secondary">{options.length} caracteres</Badge>
                </div>
                <Slider
                  value={[options.length]}
                  onValueChange={(value) => updateOptions('length', value[0])}
                  min={4}
                  max={64}
                  step={1}
                  className="w-full"
                />
                <div className="flex justify-between text-sm text-muted-foreground">
                  <span>4</span>
                  <span>64</span>
                </div>
              </div>

              {/* Character Options */}
              <div className="space-y-4">
                <Label>Incluir Caracteres</Label>
                
                <div className="space-y-3">
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="uppercase"
                      checked={options.includeUppercase}
                      onCheckedChange={(checked) => updateOptions('includeUppercase', checked)}
                    />
                    <Label htmlFor="uppercase" className="text-sm">
                      Mayúsculas (A-Z)
                    </Label>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="lowercase"
                      checked={options.includeLowercase}
                      onCheckedChange={(checked) => updateOptions('includeLowercase', checked)}
                    />
                    <Label htmlFor="lowercase" className="text-sm">
                      Minúsculas (a-z)
                    </Label>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="numbers"
                      checked={options.includeNumbers}
                      onCheckedChange={(checked) => updateOptions('includeNumbers', checked)}
                    />
                    <Label htmlFor="numbers" className="text-sm">
                      Números (0-9)
                    </Label>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="symbols"
                      checked={options.includeSymbols}
                      onCheckedChange={(checked) => updateOptions('includeSymbols', checked)}
                    />
                    <Label htmlFor="symbols" className="text-sm">
                      Símbolos (!@#$%^&*)
                    </Label>
                  </div>
                </div>
              </div>

              {/* Advanced Options */}
              <div className="space-y-3">
                <Label>Opciones Avanzadas</Label>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="excludeSimilar"
                    checked={options.excludeSimilar}
                    onCheckedChange={(checked) => updateOptions('excludeSimilar', checked)}
                  />
                  <Label htmlFor="excludeSimilar" className="text-sm">
                    Excluir caracteres similares (0, O, 1, l, I, |)
                  </Label>
                </div>
              </div>

              {/* Password Count */}
              <div className="space-y-2">
                <Label htmlFor="count">Cantidad de Contraseñas</Label>
                <Input
                  id="count"
                  type="number"
                  min="1"
                  max="20"
                  value={passwordCount}
                  onChange={(e) => setPasswordCount(Math.max(1, Math.min(20, parseInt(e.target.value) || 1)))}
                />
              </div>

              <Button 
                onClick={generatePasswords} 
                className="w-full" 
                disabled={!hasValidOptions}
              >
                <RefreshCw className="mr-2 h-4 w-4" />
                Generar Contraseñas
              </Button>

              {!hasValidOptions && (
                <Alert variant="destructive">
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription>
                    Selecciona al menos un tipo de carácter
                  </AlertDescription>
                </Alert>
              )}
            </CardContent>
          </Card>

          {/* Results Panel */}
          <div className="lg:col-span-2 space-y-6">
            {/* Strength Analysis */}
            {strengthAnalysis && passwords.length > 0 && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4 }}
              >
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Shield className="h-5 w-5" />
                      Análisis de Seguridad
                    </CardTitle>
                    <CardDescription>
                      Evaluación de la primera contraseña generada
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">Fortaleza:</span>
                        <Badge className={strengthAnalysis.color}>
                          {strengthAnalysis.label}
                        </Badge>
                      </div>
                      
                      <div className="w-full bg-muted rounded-full h-2">
                        <div 
                          className="bg-primary h-2 rounded-full transition-all duration-300"
                          style={{ width: `${strengthAnalysis.score}%` }}
                        />
                      </div>
                      
                      <p className="text-sm text-muted-foreground">
                        {strengthAnalysis.description}
                      </p>
                      
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <span className="font-medium">Tiempo estimado para descifrar:</span>
                          <p className="text-muted-foreground">
                            {getTimeToCrack(passwords[0])}
                          </p>
                        </div>
                        <div>
                          <span className="font-medium">Puntuación:</span>
                          <p className="text-muted-foreground">
                            {strengthAnalysis.score}/100
                          </p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            )}

            {/* Generated Passwords */}
            {passwords.length > 0 && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, delay: 0.1 }}
              >
                <Card>
                  <CardHeader>
                    <CardTitle>Contraseñas Generadas</CardTitle>
                    <CardDescription>
                      Haz clic en el botón de copiar para usar una contraseña
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {passwords.map((password, index) => (
                        <motion.div
                          key={index}
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: index * 0.05, duration: 0.3 }}
                          className="flex items-center gap-3 p-3 bg-muted rounded-lg"
                        >
                          <div className="flex-1 font-mono text-sm break-all">
                            {password}
                          </div>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => copyToClipboard(password, index)}
                            className="shrink-0"
                          >
                            {copiedIndex === index ? (
                              <Check className="h-4 w-4 text-green-500" />
                            ) : (
                              <Copy className="h-4 w-4" />
                            )}
                          </Button>
                        </motion.div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            )}
          </div>
        </div>

        <Alert className="mt-6">
          <Shield className="h-4 w-4" />
          <AlertDescription>
            <strong>Consejo de Seguridad:</strong> Usa contraseñas únicas para cada cuenta, 
            considera usar un gestor de contraseñas, y cambia las contraseñas importantes regularmente.
          </AlertDescription>
        </Alert>
      </motion.div>
    </div>
  )
}
