
'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { FileText, Check, X, Copy, Minimize2, Maximize2, RefreshCw, AlertCircle } from 'lucide-react'
import { motion } from 'framer-motion'

interface ValidationResult {
  isValid: boolean
  error?: string
  errorLine?: number
  objectCount?: number
  arrayCount?: number
  size?: number
}

export function JsonValidator() {
  const [input, setInput] = useState('')
  const [output, setOutput] = useState('')
  const [validation, setValidation] = useState<ValidationResult>({ isValid: true })
  const [isProcessing, setIsProcessing] = useState(false)
  const [mode, setMode] = useState<'format' | 'minify'>('format')
  const [copiedOutput, setCopiedOutput] = useState(false)

  const validateAndFormat = async (jsonString: string, shouldMinify = false) => {
    if (!jsonString.trim()) {
      setOutput('')
      setValidation({ isValid: true })
      return
    }

    setIsProcessing(true)
    
    try {
      // Simulate processing time for better UX
      await new Promise(resolve => setTimeout(resolve, 200))
      
      // Parse JSON to validate
      const parsed = JSON.parse(jsonString)
      
      // Format or minify based on mode
      const formatted = shouldMinify 
        ? JSON.stringify(parsed)
        : JSON.stringify(parsed, null, 2)
      
      // Count objects and arrays
      const objectCount = (JSON.stringify(parsed).match(/\{/g) || []).length
      const arrayCount = (JSON.stringify(parsed).match(/\[/g) || []).length
      const size = new Blob([formatted]).size
      
      setOutput(formatted)
      setValidation({
        isValid: true,
        objectCount,
        arrayCount,
        size
      })
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Error desconocido'
      let errorLine: number | undefined
      
      // Try to extract line number from error message
      const lineMatch = errorMessage.match(/line (\d+)/)
      if (lineMatch) {
        errorLine = parseInt(lineMatch[1])
      }
      
      setOutput('')
      setValidation({
        isValid: false,
        error: errorMessage,
        errorLine
      })
    } finally {
      setIsProcessing(false)
    }
  }

  const handleInputChange = (value: string) => {
    setInput(value)
    validateAndFormat(value, mode === 'minify')
  }

  const formatJson = () => {
    setMode('format')
    validateAndFormat(input, false)
  }

  const minifyJson = () => {
    setMode('minify')
    validateAndFormat(input, true)
  }

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(output)
      setCopiedOutput(true)
      setTimeout(() => setCopiedOutput(false), 2000)
    } catch (err) {
      console.error('Failed to copy text: ', err)
    }
  }

  const clearAll = () => {
    setInput('')
    setOutput('')
    setValidation({ isValid: true })
    setMode('format')
  }

  const loadSampleJson = () => {
    const sample = {
      "name": "DevTools",
      "version": "1.0.0",
      "description": "Plataforma de desarrollo profesional",
      "features": [
        "Ejecutor de código",
        "Herramientas de desarrollo",
        "Sistema de práctica",
        "Juegos arcade"
      ],
      "languages": {
        "python": "3.9+",
        "csharp": ".NET 6+",
        "cpp": "C++17"
      },
      "settings": {
        "theme": "dark",
        "notifications": true,
        "autoSave": false
      }
    }
    const sampleString = JSON.stringify(sample, null, 2)
    setInput(sampleString)
    validateAndFormat(sampleString, mode === 'minify')
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <div className="h-16 w-16 rounded-2xl bg-orange-500 flex items-center justify-center">
              <FileText className="h-8 w-8 text-white" />
            </div>
          </div>
          <h1 className="text-3xl font-bold tracking-tight mb-4">
            📝 Validador JSON
          </h1>
          <p className="text-lg text-muted-foreground">
            Valida, formatea y minifica documentos JSON con detección de errores
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Input Section */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                JSON de Entrada
              </CardTitle>
              <CardDescription>
                Pega tu JSON aquí para validarlo y formatearlo
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Textarea
                value={input}
                onChange={(e) => handleInputChange(e.target.value)}
                placeholder='{"ejemplo": "Pega tu JSON aquí..."}'
                className="min-h-[300px] font-mono text-sm resize-none"
              />
              
              <div className="flex flex-wrap gap-2">
                <Button onClick={formatJson} variant="default" size="sm">
                  <Maximize2 className="mr-2 h-4 w-4" />
                  Formatear
                </Button>
                <Button onClick={minifyJson} variant="outline" size="sm">
                  <Minimize2 className="mr-2 h-4 w-4" />
                  Minificar
                </Button>
                <Button onClick={loadSampleJson} variant="outline" size="sm">
                  <RefreshCw className="mr-2 h-4 w-4" />
                  Ejemplo
                </Button>
                <Button onClick={clearAll} variant="outline" size="sm">
                  Limpiar
                </Button>
              </div>

              {input && (
                <div className="text-sm text-muted-foreground">
                  Caracteres: {input.length}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Output Section */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                {validation.isValid ? (
                  <Check className="h-5 w-5 text-green-500" />
                ) : (
                  <X className="h-5 w-5 text-red-500" />
                )}
                Resultado
                {validation.isValid && (
                  <Badge variant="secondary" className="ml-2">
                    JSON Válido
                  </Badge>
                )}
              </CardTitle>
              <CardDescription>
                {validation.isValid 
                  ? `JSON ${mode === 'format' ? 'formateado' : 'minificado'} y validado`
                  : 'Errores de validación encontrados'
                }
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {validation.isValid ? (
                <>
                  {output && (
                    <div className="relative">
                      <Textarea
                        value={output}
                        readOnly
                        className="min-h-[300px] font-mono text-sm resize-none"
                      />
                      <Button
                        size="sm"
                        variant="ghost"
                        className="absolute top-2 right-2"
                        onClick={copyToClipboard}
                      >
                        {copiedOutput ? (
                          <Check className="h-4 w-4 text-green-500" />
                        ) : (
                          <Copy className="h-4 w-4" />
                        )}
                      </Button>
                    </div>
                  )}
                  
                  {validation.objectCount !== undefined && (
                    <div className="grid grid-cols-3 gap-4 text-sm">
                      <div className="text-center p-3 bg-muted rounded-lg">
                        <div className="font-semibold text-lg">{validation.objectCount}</div>
                        <div className="text-muted-foreground">Objetos</div>
                      </div>
                      <div className="text-center p-3 bg-muted rounded-lg">
                        <div className="font-semibold text-lg">{validation.arrayCount}</div>
                        <div className="text-muted-foreground">Arrays</div>
                      </div>
                      <div className="text-center p-3 bg-muted rounded-lg">
                        <div className="font-semibold text-lg">{validation.size}B</div>
                        <div className="text-muted-foreground">Tamaño</div>
                      </div>
                    </div>
                  )}
                </>
              ) : (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>
                    <div className="font-semibold mb-2">Error de JSON inválido:</div>
                    <div className="font-mono text-sm bg-destructive/10 p-2 rounded">
                      {validation.error}
                    </div>
                    {validation.errorLine && (
                      <div className="mt-2 text-sm">
                        Línea {validation.errorLine}
                      </div>
                    )}
                  </AlertDescription>
                </Alert>
              )}
              
              {!output && !validation.error && (
                <div className="min-h-[300px] flex items-center justify-center text-muted-foreground">
                  <div className="text-center">
                    <FileText className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>El resultado aparecerá aquí</p>
                    <p className="text-sm mt-2">Pega JSON en el campo de entrada para comenzar</p>
                  </div>
                </div>
              )}

              {isProcessing && (
                <div className="flex items-center justify-center py-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <Alert className="mt-6">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            <strong>Consejo:</strong> Este validador puede manejar JSON anidado complejo, arrays y objetos. 
            Usa "Formatear" para hacer el JSON más legible o "Minificar" para reducir el tamaño del archivo.
          </AlertDescription>
        </Alert>
      </motion.div>
    </div>
  )
}
