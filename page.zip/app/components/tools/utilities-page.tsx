
'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Badge } from '@/components/ui/badge'
import {
  Wrench,
  Link,
  QrCode,
  Palette,
  Calculator,
  Clock,
  Hash,
  Zap,
  Copy,
  Check,
  RefreshCw,
  Download,
  Upload
} from 'lucide-react'
import { motion } from 'framer-motion'
import { useToast } from '@/hooks/use-toast'

export function UtilitiesPage() {
  const { toast } = useToast()
  const [copied, setCopied] = useState<string | null>(null)

  // URL Shortener
  const [longUrl, setLongUrl] = useState('')
  const [shortUrl, setShortUrl] = useState('')

  // QR Code Generator
  const [qrText, setQrText] = useState('')
  const [qrCode, setQrCode] = useState('')

  // Color Palette Generator
  const [baseColor, setBaseColor] = useState('#3B82F6')
  const [colorPalette, setColorPalette] = useState<string[]>([])

  // Unit Converter
  const [fromValue, setFromValue] = useState('')
  const [fromUnit, setFromUnit] = useState('px')
  const [toUnit, setToUnit] = useState('rem')
  const [convertedValue, setConvertedValue] = useState('')

  // Timestamp Converter
  const [timestamp, setTimestamp] = useState('')
  const [humanDate, setHumanDate] = useState('')

  // Text Utilities
  const [textInput, setTextInput] = useState('')
  const [textStats, setTextStats] = useState({
    characters: 0,
    words: 0,
    lines: 0
  })

  const copyToClipboard = async (text: string, id: string) => {
    try {
      await navigator.clipboard.writeText(text)
      setCopied(id)
      toast({
        title: "Copiado",
        description: "Texto copiado al portapapeles",
      })
      setTimeout(() => setCopied(null), 2000)
    } catch (error) {
      toast({
        title: "Error",
        description: "No se pudo copiar el texto",
        variant: "destructive",
      })
    }
  }

  const shortenUrl = async () => {
    if (!longUrl) return
    
    // Simulate URL shortening
    const mockShortUrl = `https://devtools.ly/${Math.random().toString(36).substr(2, 8)}`
    setShortUrl(mockShortUrl)
    
    toast({
      title: "URL Acortada",
      description: "Tu URL ha sido acortada exitosamente",
    })
  }

  const generateQR = async () => {
    if (!qrText) return
    
    // Simulate QR generation - in a real app you'd use a QR library
    const mockQrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(qrText)}`
    setQrCode(mockQrUrl)
    
    toast({
      title: "QR Generado",
      description: "Tu código QR ha sido generado",
    })
  }

  const generatePalette = () => {
    const base = baseColor.slice(1)
    const r = parseInt(base.substr(0, 2), 16)
    const g = parseInt(base.substr(2, 2), 16)
    const b = parseInt(base.substr(4, 2), 16)
    
    const palette = []
    for (let i = 0; i < 5; i++) {
      const factor = 0.2 + (i * 0.2)
      const newR = Math.round(r * factor)
      const newG = Math.round(g * factor)
      const newB = Math.round(b * factor)
      palette.push(`#${newR.toString(16).padStart(2, '0')}${newG.toString(16).padStart(2, '0')}${newB.toString(16).padStart(2, '0')}`)
    }
    
    setColorPalette(palette)
  }

  const convertUnits = () => {
    if (!fromValue) return
    
    const value = parseFloat(fromValue)
    let result = 0
    
    // Simple px to rem conversion (assuming 16px = 1rem)
    if (fromUnit === 'px' && toUnit === 'rem') {
      result = value / 16
    } else if (fromUnit === 'rem' && toUnit === 'px') {
      result = value * 16
    } else {
      result = value // Same unit
    }
    
    setConvertedValue(result.toString())
  }

  const convertTimestamp = () => {
    if (!timestamp) return
    
    const date = new Date(parseInt(timestamp) * 1000)
    setHumanDate(date.toLocaleString('es-ES'))
  }

  const analyzeText = (text: string) => {
    const characters = text.length
    const words = text.trim() ? text.trim().split(/\s+/).length : 0
    const lines = text.split('\n').length
    
    setTextStats({ characters, words, lines })
  }

  const utilities = [
    {
      id: 'url-shortener',
      title: 'Acortador de URLs',
      description: 'Acorta URLs largas para compartir fácilmente',
      icon: Link,
      color: 'bg-blue-500'
    },
    {
      id: 'qr-generator',
      title: 'Generador QR',
      description: 'Genera códigos QR para cualquier texto o URL',
      icon: QrCode,
      color: 'bg-green-500'
    },
    {
      id: 'color-palette',
      title: 'Paleta de Colores',
      description: 'Genera paletas de colores armoniosas',
      icon: Palette,
      color: 'bg-purple-500'
    },
    {
      id: 'unit-converter',
      title: 'Conversor de Unidades',
      description: 'Convierte entre diferentes unidades CSS',
      icon: Calculator,
      color: 'bg-orange-500'
    },
    {
      id: 'timestamp-converter',
      title: 'Conversor de Timestamps',
      description: 'Convierte timestamps a fechas legibles',
      icon: Clock,
      color: 'bg-red-500'
    },
    {
      id: 'text-analyzer',
      title: 'Analizador de Texto',
      description: 'Analiza y cuenta caracteres, palabras y líneas',
      icon: Hash,
      color: 'bg-teal-500'
    }
  ]

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <div className="h-16 w-16 rounded-2xl bg-primary flex items-center justify-center">
              <Wrench className="h-8 w-8 text-primary-foreground" />
            </div>
          </div>
          <h1 className="text-3xl font-bold tracking-tight mb-4">
            Utilidades para Desarrolladores
          </h1>
          <p className="text-lg text-muted-foreground">
            Herramientas útiles para tu flujo de trabajo diario
          </p>
        </div>

        {/* Utilities Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {utilities.map((utility, index) => (
            <motion.div
              key={utility.id}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.1, duration: 0.3 }}
              whileHover={{ y: -5, transition: { duration: 0.2 } }}
            >
              <Card className="h-full hover:shadow-lg transition-all duration-300 cursor-pointer">
                <CardContent className="p-6">
                  <div className="flex flex-col items-center text-center space-y-4">
                    <div className={`h-12 w-12 rounded-2xl ${utility.color} flex items-center justify-center`}>
                      <utility.icon className="h-6 w-6 text-white" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-lg">{utility.title}</h3>
                      <p className="text-sm text-muted-foreground mt-1">
                        {utility.description}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Utility Tools */}
        <Tabs defaultValue="url-shortener" className="w-full">
          <TabsList className="grid w-full grid-cols-3 lg:grid-cols-6">
            <TabsTrigger value="url-shortener">URLs</TabsTrigger>
            <TabsTrigger value="qr-generator">QR</TabsTrigger>
            <TabsTrigger value="color-palette">Colores</TabsTrigger>
            <TabsTrigger value="unit-converter">Unidades</TabsTrigger>
            <TabsTrigger value="timestamp-converter">Timestamps</TabsTrigger>
            <TabsTrigger value="text-analyzer">Texto</TabsTrigger>
          </TabsList>

          {/* URL Shortener */}
          <TabsContent value="url-shortener">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Link className="h-5 w-5" />
                  Acortador de URLs
                </CardTitle>
                <CardDescription>
                  Ingresa una URL larga para obtener una versión corta
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="long-url">URL Original</Label>
                  <div className="flex gap-2">
                    <Input
                      id="long-url"
                      placeholder="https://ejemplo.com/una-url-muy-larga"
                      value={longUrl}
                      onChange={(e) => setLongUrl(e.target.value)}
                    />
                    <Button onClick={shortenUrl}>
                      <Zap className="mr-2 h-4 w-4" />
                      Acortar
                    </Button>
                  </div>
                </div>
                
                {shortUrl && (
                  <div className="space-y-2">
                    <Label>URL Acortada</Label>
                    <div className="flex gap-2">
                      <Input value={shortUrl} readOnly />
                      <Button
                        variant="outline"
                        onClick={() => copyToClipboard(shortUrl, 'short-url')}
                      >
                        {copied === 'short-url' ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* QR Generator */}
          <TabsContent value="qr-generator">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <QrCode className="h-5 w-5" />
                  Generador de Código QR
                </CardTitle>
                <CardDescription>
                  Genera un código QR para cualquier texto o URL
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="qr-text">Texto o URL</Label>
                  <div className="flex gap-2">
                    <Input
                      id="qr-text"
                      placeholder="Ingresa texto o URL"
                      value={qrText}
                      onChange={(e) => setQrText(e.target.value)}
                    />
                    <Button onClick={generateQR}>
                      <QrCode className="mr-2 h-4 w-4" />
                      Generar
                    </Button>
                  </div>
                </div>
                
                {qrCode && (
                  <div className="text-center">
                    <img src={qrCode} alt="QR Code" className="mx-auto border rounded-lg" />
                    <Button className="mt-4" variant="outline">
                      <Download className="mr-2 h-4 w-4" />
                      Descargar QR
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Color Palette */}
          <TabsContent value="color-palette">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Palette className="h-5 w-5" />
                  Generador de Paleta de Colores
                </CardTitle>
                <CardDescription>
                  Genera una paleta de colores basada en un color base
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="base-color">Color Base</Label>
                  <div className="flex gap-2">
                    <Input
                      id="base-color"
                      type="color"
                      value={baseColor}
                      onChange={(e) => setBaseColor(e.target.value)}
                      className="w-20"
                    />
                    <Input
                      value={baseColor}
                      onChange={(e) => setBaseColor(e.target.value)}
                      placeholder="#3B82F6"
                    />
                    <Button onClick={generatePalette}>
                      <RefreshCw className="mr-2 h-4 w-4" />
                      Generar
                    </Button>
                  </div>
                </div>
                
                {colorPalette.length > 0 && (
                  <div className="space-y-2">
                    <Label>Paleta Generada</Label>
                    <div className="grid grid-cols-5 gap-2">
                      {colorPalette.map((color, index) => (
                        <div key={index} className="text-center">
                          <div 
                            className="h-16 w-full rounded-lg border cursor-pointer"
                            style={{ backgroundColor: color }}
                            onClick={() => copyToClipboard(color, `color-${index}`)}
                            title="Click para copiar"
                          />
                          <p className="text-xs mt-1 font-mono">{color}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Unit Converter */}
          <TabsContent value="unit-converter">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calculator className="h-5 w-5" />
                  Conversor de Unidades CSS
                </CardTitle>
                <CardDescription>
                  Convierte entre px, rem, em y otras unidades CSS
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="from-value">Valor</Label>
                    <Input
                      id="from-value"
                      type="number"
                      placeholder="16"
                      value={fromValue}
                      onChange={(e) => setFromValue(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>De</Label>
                    <Input value="px" readOnly />
                  </div>
                  <div className="space-y-2">
                    <Label>A</Label>
                    <Input value="rem" readOnly />
                  </div>
                </div>
                
                <Button onClick={convertUnits} className="w-full">
                  <Calculator className="mr-2 h-4 w-4" />
                  Convertir
                </Button>
                
                {convertedValue && (
                  <div className="p-4 bg-muted rounded-lg">
                    <p className="text-center">
                      <span className="font-mono text-lg">{fromValue} px</span>
                      <span className="mx-4">=</span>
                      <span className="font-mono text-lg font-bold">{convertedValue} rem</span>
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Timestamp Converter */}
          <TabsContent value="timestamp-converter">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="h-5 w-5" />
                  Conversor de Timestamps
                </CardTitle>
                <CardDescription>
                  Convierte timestamps Unix a fechas legibles
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="timestamp">Timestamp Unix</Label>
                  <div className="flex gap-2">
                    <Input
                      id="timestamp"
                      placeholder="1640995200"
                      value={timestamp}
                      onChange={(e) => setTimestamp(e.target.value)}
                    />
                    <Button onClick={convertTimestamp}>
                      <Clock className="mr-2 h-4 w-4" />
                      Convertir
                    </Button>
                  </div>
                </div>
                
                <Button 
                  variant="outline" 
                  onClick={() => setTimestamp(Math.floor(Date.now() / 1000).toString())}
                >
                  Usar Timestamp Actual
                </Button>
                
                {humanDate && (
                  <div className="p-4 bg-muted rounded-lg">
                    <p className="text-center text-lg font-mono">{humanDate}</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Text Analyzer */}
          <TabsContent value="text-analyzer">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Hash className="h-5 w-5" />
                  Analizador de Texto
                </CardTitle>
                <CardDescription>
                  Analiza caracteres, palabras y líneas en tu texto
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="text-input">Texto a Analizar</Label>
                  <Textarea
                    id="text-input"
                    placeholder="Escribe o pega tu texto aquí..."
                    value={textInput}
                    onChange={(e) => {
                      setTextInput(e.target.value)
                      analyzeText(e.target.value)
                    }}
                    className="min-h-[150px]"
                  />
                </div>
                
                <div className="grid grid-cols-3 gap-4">
                  <div className="text-center p-4 bg-muted rounded-lg">
                    <div className="text-2xl font-bold">{textStats.characters}</div>
                    <div className="text-sm text-muted-foreground">Caracteres</div>
                  </div>
                  <div className="text-center p-4 bg-muted rounded-lg">
                    <div className="text-2xl font-bold">{textStats.words}</div>
                    <div className="text-sm text-muted-foreground">Palabras</div>
                  </div>
                  <div className="text-center p-4 bg-muted rounded-lg">
                    <div className="text-2xl font-bold">{textStats.lines}</div>
                    <div className="text-sm text-muted-foreground">Líneas</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </motion.div>
    </div>
  )
}
