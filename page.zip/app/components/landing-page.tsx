
'use client'

import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { ArrowRight, Code2, Trophy, BookOpen, Gamepad2, MessageSquare, Zap, Target, Users } from 'lucide-react'
import { motion } from 'framer-motion'
import { useInView } from 'react-intersection-observer'

export function LandingPage() {
  const [heroRef, heroInView] = useInView({ triggerOnce: true, threshold: 0.1 })
  const [featuresRef, featuresInView] = useInView({ triggerOnce: true, threshold: 0.1 })
  const [statsRef, statsInView] = useInView({ triggerOnce: true, threshold: 0.1 })

  const features = [
    {
      icon: Code2,
      title: '🛠️ Herramientas de Desarrollo',
      description: 'Ejecutor de código online para Python, C# y C++, analizador de IP y utilidades útiles',
      color: 'bg-blue-500'
    },
    {
      icon: Trophy,
      title: '🏆 Sistema de Práctica',
      description: 'Ejercicios de programación con sistema de puntos, niveles y ranking mundial',
      color: 'bg-yellow-500'
    },
    {
      icon: BookOpen,
      title: '📚 Cursos Gratuitos',
      description: 'Aprende programación con cursos estructurados y recursos educativos',
      color: 'bg-green-500'
    },
    {
      icon: Gamepad2,
      title: '🎮 Juegos Arcade',
      description: 'Snake, Tetris y Pong con rankings separados para diversión y desafío',
      color: 'bg-purple-500'
    },
    {
      icon: MessageSquare,
      title: '💬 Chat con IA',
      description: 'Asistente inteligente para resolver dudas y obtener ayuda personalizada',
      color: 'bg-pink-500'
    },
    {
      icon: Users,
      title: '🌟 Comunidad Global',
      description: 'Compite con desarrolladores de todo el mundo y sube en el ranking',
      color: 'bg-orange-500'
    }
  ]

  const stats = [
    { number: '10+', label: 'Herramientas', icon: Zap },
    { number: '100+', label: 'Ejercicios', icon: Target },
    { number: '3', label: 'Lenguajes', icon: Code2 },
    { number: '∞', label: 'Diversión', icon: Trophy }
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted">
      {/* Hero Section */}
      <motion.section 
        ref={heroRef}
        initial={{ opacity: 0, y: 20 }}
        animate={heroInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
        transition={{ duration: 0.8 }}
        className="relative overflow-hidden"
      >
        <div className="absolute inset-0 bg-gradient-to-r from-primary/10 via-transparent to-accent/10" />
        <div className="container relative mx-auto px-4 py-24 sm:py-32">
          <div className="text-center max-w-4xl mx-auto">
            <motion.div
              initial={{ scale: 0 }}
              animate={heroInView ? { scale: 1 } : { scale: 0 }}
              transition={{ delay: 0.2, type: "spring", stiffness: 100 }}
              className="flex justify-center mb-8"
            >
              <div className="flex h-20 w-20 items-center justify-center rounded-2xl bg-primary text-4xl shadow-2xl">
                🛠️
              </div>
            </motion.div>
            
            <motion.h1 
              initial={{ opacity: 0, y: 20 }}
              animate={heroInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
              transition={{ delay: 0.3, duration: 0.8 }}
              className="text-4xl font-bold tracking-tight sm:text-6xl lg:text-7xl bg-gradient-to-r from-foreground to-muted-foreground bg-clip-text text-transparent"
            >
              DevTools
            </motion.h1>
            
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={heroInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
              transition={{ delay: 0.4, duration: 0.8 }}
              className="mt-6 text-lg leading-8 text-muted-foreground sm:text-xl max-w-2xl mx-auto"
            >
              La plataforma definitiva para desarrolladores. Practica, aprende y domina Python, C# y C++ 
              con nuestras herramientas profesionales y sistema de gamificación.
            </motion.p>
            
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={heroInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
              transition={{ delay: 0.5, duration: 0.8 }}
              className="mt-10 flex items-center justify-center gap-4 flex-wrap"
            >
              <Button size="lg" className="text-lg px-8 py-6" asChild>
                <Link href="/auth/register">
                  Comenzar Gratis <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </Button>
              <Button variant="outline" size="lg" className="text-lg px-8 py-6" asChild>
                <Link href="/auth/login">
                  Iniciar Sesión
                </Link>
              </Button>
            </motion.div>
            
            <motion.div 
              initial={{ opacity: 0 }}
              animate={heroInView ? { opacity: 1 } : { opacity: 0 }}
              transition={{ delay: 0.6, duration: 0.8 }}
              className="mt-8 flex justify-center gap-2 flex-wrap"
            >
              <Badge variant="secondary" className="text-sm">🇦🇷 Hecho en Argentina</Badge>
              <Badge variant="secondary" className="text-sm">🆓 Completamente Gratis</Badge>
              <Badge variant="secondary" className="text-sm">🚀 Sin Límites</Badge>
            </motion.div>
          </div>
        </div>
      </motion.section>

      {/* Stats Section */}
      <motion.section 
        ref={statsRef}
        initial={{ opacity: 0, y: 40 }}
        animate={statsInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 40 }}
        transition={{ duration: 0.8 }}
        className="py-16 bg-muted/50"
      >
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, scale: 0.5 }}
                animate={statsInView ? { opacity: 1, scale: 1 } : { opacity: 0, scale: 0.5 }}
                transition={{ delay: index * 0.1, duration: 0.5 }}
                className="text-center"
              >
                <div className="flex justify-center mb-4">
                  <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center">
                    <stat.icon className="h-6 w-6 text-primary" />
                  </div>
                </div>
                <div className="text-3xl font-bold text-foreground">{stat.number}</div>
                <div className="text-sm text-muted-foreground">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </motion.section>

      {/* Features Section */}
      <motion.section 
        ref={featuresRef}
        initial={{ opacity: 0 }}
        animate={featuresInView ? { opacity: 1 } : { opacity: 0 }}
        transition={{ duration: 0.8 }}
        className="py-24"
      >
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl mb-4">
              Todo lo que necesitas para programar
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Herramientas profesionales, sistema de aprendizaje gamificado y una comunidad global de desarrolladores
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                animate={featuresInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
                transition={{ delay: index * 0.1, duration: 0.6 }}
                whileHover={{ y: -5, transition: { duration: 0.2 } }}
              >
                <Card className="h-full hover:shadow-lg transition-all duration-300 border-0 bg-card/50 backdrop-blur">
                  <CardHeader>
                    <div className="flex items-center space-x-4">
                      <div className={`h-12 w-12 rounded-lg ${feature.color} flex items-center justify-center`}>
                        <feature.icon className="h-6 w-6 text-white" />
                      </div>
                      <div>
                        <CardTitle className="text-xl">{feature.title}</CardTitle>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <CardDescription className="text-base leading-relaxed">
                      {feature.description}
                    </CardDescription>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </motion.section>

      {/* CTA Section */}
      <section className="py-24 bg-gradient-to-r from-primary/10 via-accent/10 to-primary/10">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl mb-6">
            ¿Listo para convertirte en un mejor desarrollador?
          </h2>
          <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
            Únete a miles de desarrolladores que ya están mejorando sus habilidades con DevTools
          </p>
          <Button size="lg" className="text-lg px-8 py-6" asChild>
            <Link href="/auth/register">
              Comenzar Ahora 🚀
            </Link>
          </Button>
        </div>
      </section>
    </div>
  )
}
