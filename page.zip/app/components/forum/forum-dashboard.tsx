

'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { 
  MessageSquare, 
  Users, 
  TrendingUp, 
  Pin,
  Lock,
  Plus,
  Search,
  Eye,
  Clock,
  User
} from 'lucide-react'
import { motion } from 'framer-motion'
import Link from 'next/link'

interface ForumCategory {
  id: string
  name: string
  description: string
  color: string
  topicCount: number
  recentTopics: Array<{
    id: string
    title: string
    author: string
    authorImage?: string
    postCount: number
    updatedAt: string
  }>
}

interface ForumStats {
  totalTopics: number
  totalPosts: number
  totalUsers: number
  onlineUsers: number
}

export function ForumDashboard() {
  const { data: session } = useSession()
  const [categories, setCategories] = useState<ForumCategory[]>([])
  const [stats, setStats] = useState<ForumStats | null>(null)
  const [searchQuery, setSearchQuery] = useState('')
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    fetchForumData()
  }, [])

  const fetchForumData = async () => {
    try {
      setIsLoading(true)
      
      // Fetch categories
      const categoriesResponse = await fetch('/api/forum/categories')
      if (categoriesResponse.ok) {
        const categoriesData = await categoriesResponse.json()
        setCategories(categoriesData.categories || [])
      }

      // Mock stats for now
      setStats({
        totalTopics: 156,
        totalPosts: 1234,
        totalUsers: 89,
        onlineUsers: 12
      })
    } catch (error) {
      console.error('Error fetching forum data:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    const now = new Date()
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60))
    
    if (diffInMinutes < 1) return 'Ahora'
    if (diffInMinutes < 60) return `Hace ${diffInMinutes}m`
    if (diffInMinutes < 1440) return `Hace ${Math.floor(diffInMinutes / 60)}h`
    return date.toLocaleDateString()
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-7xl">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <div className="h-16 w-16 rounded-2xl bg-blue-500 flex items-center justify-center">
              <MessageSquare className="h-8 w-8 text-white" />
            </div>
          </div>
          <h1 className="text-3xl font-bold tracking-tight mb-4">
            💬 Foro de Desarrolladores
          </h1>
          <p className="text-lg text-muted-foreground">
            Comparte conocimientos, haz preguntas y conecta con otros desarrolladores
          </p>
        </div>

        {/* Stats */}
        {stats && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1, duration: 0.6 }}
            className="mb-8"
          >
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Card>
                <CardContent className="p-6 text-center">
                  <div className="flex items-center justify-center mb-2">
                    <MessageSquare className="h-6 w-6 text-blue-500" />
                  </div>
                  <div className="text-2xl font-bold">{stats.totalTopics}</div>
                  <div className="text-sm text-muted-foreground">Temas</div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6 text-center">
                  <div className="flex items-center justify-center mb-2">
                    <TrendingUp className="h-6 w-6 text-green-500" />
                  </div>
                  <div className="text-2xl font-bold">{stats.totalPosts}</div>
                  <div className="text-sm text-muted-foreground">Mensajes</div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6 text-center">
                  <div className="flex items-center justify-center mb-2">
                    <Users className="h-6 w-6 text-purple-500" />
                  </div>
                  <div className="text-2xl font-bold">{stats.totalUsers}</div>
                  <div className="text-sm text-muted-foreground">Miembros</div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6 text-center">
                  <div className="flex items-center justify-center mb-2">
                    <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
                  </div>
                  <div className="text-2xl font-bold">{stats.onlineUsers}</div>
                  <div className="text-sm text-muted-foreground">En línea</div>
                </CardContent>
              </Card>
            </div>
          </motion.div>
        )}

        {/* Search and Create */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2, duration: 0.6 }}
          className="mb-8"
        >
          <Card>
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row gap-4">
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Buscar temas, categorías o usuarios..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <Button asChild>
                  <Link href="/forum/create">
                    <Plus className="mr-2 h-4 w-4" />
                    Crear Tema
                  </Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Categories */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.6 }}
        >
          <div className="space-y-6">
            {categories.map((category, index) => (
              <motion.div
                key={category.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05, duration: 0.4 }}
              >
                <Card className="hover:shadow-lg transition-shadow duration-300">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div 
                          className="w-4 h-4 rounded-full"
                          style={{ backgroundColor: category.color }}
                        />
                        <div>
                          <CardTitle className="text-lg">
                            <Link 
                              href={`/forum/category/${category.id}`}
                              className="hover:text-primary transition-colors"
                            >
                              {category.name}
                            </Link>
                          </CardTitle>
                          <CardDescription className="mt-1">
                            {category.description}
                          </CardDescription>
                        </div>
                      </div>
                      <Badge variant="outline">
                        {category.topicCount} temas
                      </Badge>
                    </div>
                  </CardHeader>
                  
                  {category.recentTopics.length > 0 && (
                    <CardContent>
                      <div className="space-y-3">
                        <h4 className="font-medium text-sm text-muted-foreground">
                          Temas Recientes
                        </h4>
                        {category.recentTopics.map((topic) => (
                          <div key={topic.id} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                            <div className="flex-1">
                              <Link 
                                href={`/forum/topic/${topic.id}`}
                                className="font-medium hover:text-primary transition-colors line-clamp-1"
                              >
                                {topic.title}
                              </Link>
                              <div className="flex items-center gap-2 mt-1 text-xs text-muted-foreground">
                                <User className="h-3 w-3" />
                                <span>{topic.author}</span>
                                <div className="flex items-center gap-1">
                                  <MessageSquare className="h-3 w-3" />
                                  <span>{topic.postCount}</span>
                                </div>
                                <div className="flex items-center gap-1">
                                  <Clock className="h-3 w-3" />
                                  <span>{formatDate(topic.updatedAt)}</span>
                                </div>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  )}
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Quick Tips */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.6 }}
          className="mt-12"
        >
          <Card>
            <CardHeader>
              <CardTitle>Reglas y Consejos del Foro</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-semibold mb-2">✅ Buenas Prácticas</h4>
                  <ul className="space-y-1 text-sm text-muted-foreground">
                    <li>• Usa títulos descriptivos para tus temas</li>
                    <li>• Busca antes de crear un tema duplicado</li>
                    <li>• Sé respetuoso con otros miembros</li>
                    <li>• Comparte código usando bloques de código</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">🚫 Evita</h4>
                  <ul className="space-y-1 text-sm text-muted-foreground">
                    <li>• Spam o publicaciones repetitivas</li>
                    <li>• Lenguaje ofensivo o discriminatorio</li>
                    <li>• Temas fuera del contexto de programación</li>
                    <li>• Solicitar ayuda sin mostrar tu esfuerzo</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </motion.div>
    </div>
  )
}
