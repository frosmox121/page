
'use client'

import { ChatInterface } from '@/components/chat-interface'
import { useEffect, useState } from 'react'

export function ClientChatInterface() {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return (
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        <div className="mb-8">
          <h1 className="text-3xl font-bold tracking-tight mb-4">
            💬 Chat con IA
          </h1>
          <p className="text-lg text-muted-foreground">
            Cargando chat...
          </p>
        </div>
        <div className="flex items-center justify-center h-96">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
        </div>
      </div>
    )
  }

  return <ChatInterface />
}
