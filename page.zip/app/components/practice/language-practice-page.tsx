
'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { 
  Trophy, 
  Target, 
  Code2, 
  Star, 
  Clock, 
  TrendingUp,
  Play,
  CheckCircle,
  XCircle,
  Award,
  Zap,
  BookOpen,
  Users
} from 'lucide-react'
import { motion } from 'framer-motion'
import Link from 'next/link'

interface Exercise {
  id: string
  title: string
  description: string
  language: string
  difficulty: string
  points: number
  category: string
  isCompleted?: boolean
  userScore?: number
}

interface LanguageStats {
  totalExercises: number
  completedExercises: number
  totalPoints: number
  averageScore: number
  streak: number
  rank: number
}

interface LanguagePracticePageProps {
  language: 'python' | 'csharp' | 'cpp'
}

export function LanguagePracticePage({ language }: LanguagePracticePageProps) {
  const { data: session } = useSession()
  const [exercises, setExercises] = useState<Exercise[]>([])
  const [languageStats, setLanguageStats] = useState<LanguageStats | null>(null)
  const [selectedDifficulty, setSelectedDifficulty] = useState('all')
  const [selectedCategory, setSelectedCategory] = useState('all')
  const [isLoading, setIsLoading] = useState(true)

  const languageConfig = {
    python: {
      name: 'Python',
      icon: Code2,
      color: 'bg-blue-500',
      description: 'Aprende Python, el lenguaje más versátil y fácil de usar'
    },
    csharp: {
      name: 'C#',
      icon: Zap,
      color: 'bg-purple-500',
      description: 'Domina C# y la programación orientada a objetos'
    },
    cpp: {
      name: 'C++',
      icon: Trophy,
      color: 'bg-red-500',
      description: 'Conquista C++, el lenguaje de sistemas de alto rendimiento'
    }
  }

  const difficulties = [
    { value: 'all', label: 'Todas las dificultades' },
    { value: 'beginner', label: 'Principiante' },
    { value: 'intermediate', label: 'Intermedio' },
    { value: 'advanced', label: 'Avanzado' }
  ]

  const categories = [
    { value: 'all', label: 'Todas las categorías' },
    { value: 'basic-syntax', label: 'Sintaxis Básica' },
    { value: 'algorithms', label: 'Algoritmos' },
    { value: 'data-structures', label: 'Estructuras de Datos' },
    { value: 'math', label: 'Matemáticas' },
    { value: 'strings', label: 'Cadenas' }
  ]

  useEffect(() => {
    fetchData()
  }, [language])

  const fetchData = async () => {
    try {
      setIsLoading(true)
      
      // Fetch exercises for this language
      const exercisesResponse = await fetch(`/api/practice/exercises?language=${language}`)
      if (exercisesResponse.ok) {
        const exercisesData = await exercisesResponse.json()
        setExercises(exercisesData.exercises || [])
      }

      // Fetch language-specific stats
      const statsResponse = await fetch(`/api/practice/stats?language=${language}`)
      if (statsResponse.ok) {
        const statsData = await statsResponse.json()
        setLanguageStats(statsData.languageStats || null)
      }
    } catch (error) {
      console.error('Error fetching data:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const filteredExercises = exercises.filter(exercise => {
    const difficultyMatch = selectedDifficulty === 'all' || exercise.difficulty === selectedDifficulty
    const categoryMatch = selectedCategory === 'all' || exercise.category === selectedCategory
    
    return difficultyMatch && categoryMatch
  })

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'beginner': return 'bg-green-500'
      case 'intermediate': return 'bg-yellow-500'  
      case 'advanced': return 'bg-red-500'
      default: return 'bg-gray-500'
    }
  }

  const getDifficultyLabel = (difficulty: string) => {
    switch (difficulty) {
      case 'beginner': return 'Principiante'
      case 'intermediate': return 'Intermedio'
      case 'advanced': return 'Avanzado'
      default: return difficulty
    }
  }

  const getCategoryLabel = (category: string) => {
    switch (category) {
      case 'basic-syntax': return 'Sintaxis Básica'
      case 'algorithms': return 'Algoritmos'
      case 'data-structures': return 'Estructuras de Datos'  
      case 'math': return 'Matemáticas'
      case 'strings': return 'Cadenas'
      default: return category
    }
  }

  const config = languageConfig[language]
  const IconComponent = config.icon

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-7xl">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <div className={`h-16 w-16 rounded-2xl ${config.color} flex items-center justify-center`}>
              <IconComponent className="h-8 w-8 text-white" />
            </div>
          </div>
          <h1 className="text-3xl font-bold tracking-tight mb-4">
            Práctica de {config.name}
          </h1>
          <p className="text-lg text-muted-foreground">
            {config.description}
          </p>
        </div>

        {/* Language Stats */}
        {languageStats && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1, duration: 0.6 }}
            className="mb-8"
          >
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-4">
              <Card>
                <CardContent className="p-6 text-center">
                  <div className="flex items-center justify-center mb-2">
                    <Target className="h-6 w-6 text-blue-500" />
                  </div>
                  <div className="text-2xl font-bold">{languageStats.totalExercises}</div>
                  <div className="text-sm text-muted-foreground">Total</div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6 text-center">
                  <div className="flex items-center justify-center mb-2">
                    <CheckCircle className="h-6 w-6 text-green-500" />
                  </div>
                  <div className="text-2xl font-bold">{languageStats.completedExercises}</div>
                  <div className="text-sm text-muted-foreground">Completados</div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6 text-center">
                  <div className="flex items-center justify-center mb-2">
                    <Star className="h-6 w-6 text-yellow-500" />
                  </div>
                  <div className="text-2xl font-bold">{languageStats.totalPoints}</div>
                  <div className="text-sm text-muted-foreground">Puntos</div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6 text-center">
                  <div className="flex items-center justify-center mb-2">
                    <TrendingUp className="h-6 w-6 text-purple-500" />
                  </div>
                  <div className="text-2xl font-bold">{languageStats.averageScore}%</div>
                  <div className="text-sm text-muted-foreground">Promedio</div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6 text-center">
                  <div className="flex items-center justify-center mb-2">
                    <Zap className="h-6 w-6 text-orange-500" />
                  </div>
                  <div className="text-2xl font-bold">{languageStats.streak}</div>
                  <div className="text-sm text-muted-foreground">Racha</div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6 text-center">
                  <div className="flex items-center justify-center mb-2">
                    <Award className="h-6 w-6 text-indigo-500" />
                  </div>
                  <div className="text-2xl font-bold">#{languageStats.rank}</div>
                  <div className="text-sm text-muted-foreground">Ranking</div>
                </CardContent>
              </Card>
            </div>
          </motion.div>
        )}

        {/* Progress */}
        {languageStats && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2, duration: 0.6 }}
            className="mb-8"
          >
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="h-5 w-5" />
                  Progreso en {config.name}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Ejercicios completados</span>
                    <span>{languageStats.completedExercises}/{languageStats.totalExercises}</span>
                  </div>
                  <Progress 
                    value={(languageStats.completedExercises / languageStats.totalExercises) * 100} 
                    className="h-3"
                  />
                  <p className="text-sm text-muted-foreground">
                    {Math.round((languageStats.completedExercises / languageStats.totalExercises) * 100)}% completado
                  </p>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}

        {/* Filters */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.6 }}
          className="mb-8"
        >
          <Card>
            <CardHeader>
              <CardTitle>Filtros</CardTitle>
              <CardDescription>
                Filtra ejercicios por dificultad y categoría
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Dificultad</label>
                  <Select value={selectedDifficulty} onValueChange={setSelectedDifficulty}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {difficulties.map(diff => (
                        <SelectItem key={diff.value} value={diff.value}>
                          {diff.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium">Categoría</label>
                  <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map(cat => (
                        <SelectItem key={cat.value} value={cat.value}>
                          {cat.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Exercise List */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.6 }}
        >
          {filteredExercises.length === 0 ? (
            <Card>
              <CardContent className="text-center py-12">
                <Target className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                <h3 className="text-lg font-semibold mb-2">No hay ejercicios</h3>
                <p className="text-muted-foreground">
                  No se encontraron ejercicios con los filtros seleccionados
                </p>
                <Button className="mt-4" asChild>
                  <Link href="/practice">
                    <BookOpen className="mr-2 h-4 w-4" />
                    Ver Todos los Ejercicios
                  </Link>
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredExercises.map((exercise, index) => (
                <motion.div
                  key={exercise.id}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.05, duration: 0.3 }}
                  whileHover={{ y: -5, transition: { duration: 0.2 } }}
                >
                  <Card className="h-full hover:shadow-lg transition-all duration-300">
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <CardTitle className="text-lg mb-2 line-clamp-2">
                            {exercise.title}
                          </CardTitle>
                          <div className="flex items-center gap-2 mb-2">
                            <Badge className={`${getDifficultyColor(exercise.difficulty)} text-white text-xs`}>
                              {getDifficultyLabel(exercise.difficulty)}
                            </Badge>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge variant="secondary" className="text-xs">
                              {getCategoryLabel(exercise.category)}
                            </Badge>
                            <Badge variant="secondary" className="text-xs">
                              <Star className="w-3 h-3 mr-1" />
                              {exercise.points}
                            </Badge>
                          </div>
                        </div>
                        {exercise.isCompleted && (
                          <CheckCircle className="h-6 w-6 text-green-500 flex-shrink-0" />
                        )}
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-muted-foreground mb-4 line-clamp-3">
                        {exercise.description}
                      </p>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          {exercise.userScore !== undefined && (
                            <span className="flex items-center gap-1">
                              <Trophy className="h-4 w-4" />
                              {exercise.userScore}%
                            </span>
                          )}
                        </div>
                        <Button asChild size="sm">
                          <Link href={`/practice/exercise/${exercise.id}`}>
                            <Play className="mr-2 h-4 w-4" />
                            {exercise.isCompleted ? 'Revisar' : 'Resolver'}
                          </Link>
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          )}
        </motion.div>
      </motion.div>
    </div>
  )
}
